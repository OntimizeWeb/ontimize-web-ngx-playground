import * as i0 from "@angular/core";
import * as i1 from "./o-image-editor.component";
export declare class OImageEditorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OImageEditorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OImageEditorModule, never, [typeof i1.OImageEditorComponent], [typeof i1.OImageEditorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OImageEditorModule>;
}
//# sourceMappingURL=o-image-editor.module.d.ts.map