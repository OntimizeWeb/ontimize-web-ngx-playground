export * from './translate-extra-components.service';
//# sourceMappingURL=index.d.ts.map