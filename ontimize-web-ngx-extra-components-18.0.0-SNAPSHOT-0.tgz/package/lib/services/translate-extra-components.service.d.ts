import { OTranslateService } from 'ontimize-web-ngx';
import * as i0 from "@angular/core";
export declare class TranslateExtraComponentsService {
    private readonly oTranslate;
    private currentLang;
    private readonly loadedLangs;
    constructor(oTranslate: OTranslateService);
    private loadTranslations;
    get(key: string, values?: any[]): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<TranslateExtraComponentsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TranslateExtraComponentsService>;
}
//# sourceMappingURL=translate-extra-components.service.d.ts.map