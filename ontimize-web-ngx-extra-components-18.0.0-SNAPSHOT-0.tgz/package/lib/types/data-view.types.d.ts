export type ODataViewMode = 'table' | 'grid';
export type CustomBoolean = 'no' | 'false' | 'yes' | 'true';
//# sourceMappingURL=data-view.types.d.ts.map