import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
import * as i2 from "ontimize-web-ngx";
import * as i3 from "./components/o-skeleton/o-skeleton.component";
import * as i4 from "./components/o-data-view/o-data-view.module";
import * as i5 from "./components/o-image-editor/o-image-editor.module";
export declare class OExtraComponentsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OExtraComponentsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OExtraComponentsModule, never, [typeof i1.CommonModule, typeof i2.OntimizeWebModule, typeof i3.OSkeletonComponent], [typeof i3.OSkeletonComponent, typeof i4.ODataViewModule, typeof i5.OImageEditorModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OExtraComponentsModule>;
}
//# sourceMappingURL=ontimize-web-ngx-extra-components.module.d.ts.map