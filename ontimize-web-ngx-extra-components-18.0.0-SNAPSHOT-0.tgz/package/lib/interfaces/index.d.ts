export * from './grid-config.interface';
export * from './table-config.interface';
//# sourceMappingURL=index.d.ts.map