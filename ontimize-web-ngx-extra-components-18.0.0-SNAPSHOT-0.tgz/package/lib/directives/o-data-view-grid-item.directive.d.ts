import { TemplateRef } from '@angular/core';
import * as i0 from "@angular/core";
export declare class ODataViewGridItemDirective {
    template: TemplateRef<any>;
    constructor(template: TemplateRef<any>);
    static ɵfac: i0.ɵɵFactoryDeclaration<ODataViewGridItemDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ODataViewGridItemDirective, "[oDataViewGridItem]", never, {}, {}, never, never, true, never>;
}
//# sourceMappingURL=o-data-view-grid-item.directive.d.ts.map