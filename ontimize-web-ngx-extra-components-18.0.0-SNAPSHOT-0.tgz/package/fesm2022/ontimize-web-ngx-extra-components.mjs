import * as i0 from '@angular/core';
import { Component, Directive, ViewEncapsulation, Optional, Inject, ViewChild, ContentChild, Input, NgModule, Injectable, EventEmitter, Output } from '@angular/core';
import * as i2 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i1 from 'ngx-skeleton-loader';
import { NgxSkeletonLoaderModule } from 'ngx-skeleton-loader';
import * as i1$1 from 'ontimize-web-ngx';
import { Codes, O_TABLE_GLOBAL_CONFIG, OTableModule, OGridModule, OButtonToggleModule, BooleanInputConverter, OntimizeWebModule } from 'ontimize-web-ngx';
import { __decorate } from 'tslib';
import { base64ToFile, ImageCropperComponent } from 'ngx-image-cropper';
import { take } from 'rxjs';
import * as i3 from '@angular/forms';
import * as i4 from '@angular/material/button';
import * as i5 from '@angular/material/button-toggle';
import * as i6 from '@angular/material/icon';
import * as i7 from '@angular/material/input';
import * as i8 from '@angular/material/form-field';
import * as i9 from '@angular/material/progress-spinner';
import * as i10 from '@angular/material/tooltip';

const _c0$2 = () => ({ width: "80px", height: "80px" });
const _c1$2 = () => ({ width: "200px", "border-radius": "0", height: "15px", "margin-bottom": "10px" });
const _c2$2 = () => ({ width: "170px", "border-radius": "0", height: "15px" });
const _c3$2 = () => ({ width: "80%", "border-radius": "0", height: "15px", "margin-bottom": "10px" });
const _c4 = () => ({ width: "90%", "border-radius": "0", height: "15px", "margin-bottom": "10px" });
const _c5 = () => ({ width: "60%", "border-radius": "0", height: "15px", "margin-bottom": "10px" });
class OSkeletonComponent {
    static { this.ɵfac = function OSkeletonComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || OSkeletonComponent)(); }; }
    static { this.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: OSkeletonComponent, selectors: [["o-skeleton"]], hostVars: 2, hostBindings: function OSkeletonComponent_HostBindings(rf, ctx) { if (rf & 2) {
            i0.ɵɵclassProp("o-skeleton", true);
        } }, standalone: true, features: [i0.ɵɵStandaloneFeature], decls: 46, vars: 42, consts: [[1, "fb-item"], [1, "first-section-wrapper"], [1, "gravatar"], ["appearance", "circle", 3, "theme"], [1, "gravatar-title"], [3, "theme"], [1, "second-section-wrapper"], [1, "wrapper"]], template: function OSkeletonComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "div", 1)(2, "div", 2);
            i0.ɵɵelement(3, "ngx-skeleton-loader", 3);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(4, "div", 4)(5, "div");
            i0.ɵɵelement(6, "ngx-skeleton-loader", 5);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(7, "div");
            i0.ɵɵelement(8, "ngx-skeleton-loader", 5);
            i0.ɵɵelementEnd()()();
            i0.ɵɵelementStart(9, "div", 6)(10, "div", 7);
            i0.ɵɵelement(11, "ngx-skeleton-loader", 5);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(12, "div", 7);
            i0.ɵɵelement(13, "ngx-skeleton-loader", 5);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(14, "div", 7);
            i0.ɵɵelement(15, "ngx-skeleton-loader", 5);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(16, "div", 7);
            i0.ɵɵelement(17, "ngx-skeleton-loader", 5);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(18, "div", 7);
            i0.ɵɵelement(19, "ngx-skeleton-loader", 5);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(20, "div", 7);
            i0.ɵɵelement(21, "ngx-skeleton-loader", 5);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(22, "div", 7);
            i0.ɵɵelement(23, "ngx-skeleton-loader", 5);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(24, "div", 7);
            i0.ɵɵelement(25, "ngx-skeleton-loader", 5);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(26, "div", 7);
            i0.ɵɵelement(27, "ngx-skeleton-loader", 5);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(28, "div", 7);
            i0.ɵɵelement(29, "ngx-skeleton-loader", 5);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(30, "div", 7);
            i0.ɵɵelement(31, "ngx-skeleton-loader", 5);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(32, "div", 7);
            i0.ɵɵelement(33, "ngx-skeleton-loader", 5);
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(34, "div", 7);
            i0.ɵɵelement(35, "ngx-skeleton-loader", 5);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(36, "div", 7);
            i0.ɵɵelement(37, "ngx-skeleton-loader", 5);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(38, "div", 7);
            i0.ɵɵelement(39, "ngx-skeleton-loader", 5);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(40, "div", 7);
            i0.ɵɵelement(41, "ngx-skeleton-loader", 5);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(42, "div", 7);
            i0.ɵɵelement(43, "ngx-skeleton-loader", 5);
            i0.ɵɵelementEnd();
            i0.ɵɵelementStart(44, "div", 7);
            i0.ɵɵelement(45, "ngx-skeleton-loader", 5);
            i0.ɵɵelementEnd()();
        } if (rf & 2) {
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("theme", i0.ɵɵpureFunction0(21, _c0$2));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("theme", i0.ɵɵpureFunction0(22, _c1$2));
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("theme", i0.ɵɵpureFunction0(23, _c2$2));
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("theme", i0.ɵɵpureFunction0(24, _c3$2));
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("theme", i0.ɵɵpureFunction0(25, _c4));
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("theme", i0.ɵɵpureFunction0(26, _c5));
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("theme", i0.ɵɵpureFunction0(27, _c3$2));
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("theme", i0.ɵɵpureFunction0(28, _c4));
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("theme", i0.ɵɵpureFunction0(29, _c5));
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("theme", i0.ɵɵpureFunction0(30, _c3$2));
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("theme", i0.ɵɵpureFunction0(31, _c4));
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("theme", i0.ɵɵpureFunction0(32, _c5));
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("theme", i0.ɵɵpureFunction0(33, _c3$2));
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("theme", i0.ɵɵpureFunction0(34, _c4));
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("theme", i0.ɵɵpureFunction0(35, _c5));
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("theme", i0.ɵɵpureFunction0(36, _c3$2));
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("theme", i0.ɵɵpureFunction0(37, _c4));
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("theme", i0.ɵɵpureFunction0(38, _c5));
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("theme", i0.ɵɵpureFunction0(39, _c3$2));
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("theme", i0.ɵɵpureFunction0(40, _c4));
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("theme", i0.ɵɵpureFunction0(41, _c5));
        } }, dependencies: [NgxSkeletonLoaderModule, i1.NgxSkeletonLoaderComponent], styles: [".item[_ngcontent-%COMP%], .fb-item[_ngcontent-%COMP%]{width:auto;height:auto;margin:10px auto;border:1px solid #eaeaea;padding:10px}.gravatar[_ngcontent-%COMP%]{width:100px;height:90px}.gravatar-title[_ngcontent-%COMP%]{width:500px;padding:10px;height:80px}.first-section-wrapper[_ngcontent-%COMP%], .second-section-wrapper[_ngcontent-%COMP%]{width:100%;height:auto;flex:1}.first-section-wrapper[_ngcontent-%COMP%]{display:inline-flex}"] }); }
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(OSkeletonComponent, [{
        type: Component,
        args: [{ selector: 'o-skeleton', standalone: true, imports: [NgxSkeletonLoaderModule], host: {
                    '[class.o-skeleton]': 'true'
                }, template: "<div class=\"fb-item\">\r\n  <div class=\"first-section-wrapper\">\r\n    <div class=\"gravatar\">\r\n      <ngx-skeleton-loader appearance=\"circle\" [theme]=\"{ width: '80px', height: '80px' }\">\r\n      </ngx-skeleton-loader>\r\n    </div>\r\n    <div class=\"gravatar-title\">\r\n      <div>\r\n        <ngx-skeleton-loader [theme]=\"{\r\n            width: '200px',\r\n            'border-radius': '0',\r\n            height: '15px',\r\n            'margin-bottom': '10px'\r\n          }\"></ngx-skeleton-loader>\r\n      </div>\r\n      <div>\r\n        <ngx-skeleton-loader [theme]=\"{ width: '170px', 'border-radius': '0', height: '15px' }\">\r\n        </ngx-skeleton-loader>\r\n      </div>\r\n    </div>\r\n  </div>\r\n  <div class=\"second-section-wrapper\">\r\n    <div class=\"wrapper\">\r\n      <ngx-skeleton-loader [theme]=\"{\r\n          width: '80%',\r\n          'border-radius': '0',\r\n          height: '15px',\r\n          'margin-bottom': '10px'\r\n        }\"></ngx-skeleton-loader>\r\n    </div>\r\n    <div class=\"wrapper\">\r\n      <ngx-skeleton-loader [theme]=\"{\r\n          width: '90%',\r\n          'border-radius': '0',\r\n          height: '15px',\r\n          'margin-bottom': '10px'\r\n        }\"></ngx-skeleton-loader>\r\n    </div>\r\n    <div class=\"wrapper\">\r\n      <ngx-skeleton-loader [theme]=\"{\r\n          width: '60%',\r\n          'border-radius': '0',\r\n          height: '15px',\r\n          'margin-bottom': '10px'\r\n        }\"></ngx-skeleton-loader>\r\n    </div>\r\n    <div class=\"wrapper\">\r\n      <ngx-skeleton-loader [theme]=\"{\r\n                width: '80%',\r\n                'border-radius': '0',\r\n                height: '15px',\r\n                'margin-bottom': '10px'\r\n              }\"></ngx-skeleton-loader>\r\n    </div>\r\n    <div class=\"wrapper\">\r\n      <ngx-skeleton-loader [theme]=\"{\r\n                width: '90%',\r\n                'border-radius': '0',\r\n                height: '15px',\r\n                'margin-bottom': '10px'\r\n              }\"></ngx-skeleton-loader>\r\n    </div>\r\n    <div class=\"wrapper\">\r\n      <ngx-skeleton-loader [theme]=\"{\r\n                width: '60%',\r\n                'border-radius': '0',\r\n                height: '15px',\r\n                'margin-bottom': '10px'\r\n              }\"></ngx-skeleton-loader>\r\n    </div>\r\n    <div class=\"wrapper\">\r\n      <ngx-skeleton-loader [theme]=\"{\r\n                width: '80%',\r\n                'border-radius': '0',\r\n                height: '15px',\r\n                'margin-bottom': '10px'\r\n              }\"></ngx-skeleton-loader>\r\n    </div>\r\n    <div class=\"wrapper\">\r\n      <ngx-skeleton-loader [theme]=\"{\r\n                width: '90%',\r\n                'border-radius': '0',\r\n                height: '15px',\r\n                'margin-bottom': '10px'\r\n              }\"></ngx-skeleton-loader>\r\n    </div>\r\n    <div class=\"wrapper\">\r\n      <ngx-skeleton-loader [theme]=\"{\r\n                width: '60%',\r\n                'border-radius': '0',\r\n                height: '15px',\r\n                'margin-bottom': '10px'\r\n              }\"></ngx-skeleton-loader>\r\n    </div>\r\n    <div class=\"wrapper\">\r\n      <ngx-skeleton-loader [theme]=\"{\r\n                width: '80%',\r\n                'border-radius': '0',\r\n                height: '15px',\r\n                'margin-bottom': '10px'\r\n              }\"></ngx-skeleton-loader>\r\n    </div>\r\n    <div class=\"wrapper\">\r\n      <ngx-skeleton-loader [theme]=\"{\r\n                width: '90%',\r\n                'border-radius': '0',\r\n                height: '15px',\r\n                'margin-bottom': '10px'\r\n              }\"></ngx-skeleton-loader>\r\n    </div>\r\n    <div class=\"wrapper\">\r\n      <ngx-skeleton-loader [theme]=\"{\r\n                width: '60%',\r\n                'border-radius': '0',\r\n                height: '15px',\r\n                'margin-bottom': '10px'\r\n              }\"></ngx-skeleton-loader>\r\n    </div>\r\n  </div>\r\n  <div class=\"wrapper\">\r\n    <ngx-skeleton-loader [theme]=\"{\r\n              width: '80%',\r\n              'border-radius': '0',\r\n              height: '15px',\r\n              'margin-bottom': '10px'\r\n            }\"></ngx-skeleton-loader>\r\n  </div>\r\n  <div class=\"wrapper\">\r\n    <ngx-skeleton-loader [theme]=\"{\r\n              width: '90%',\r\n              'border-radius': '0',\r\n              height: '15px',\r\n              'margin-bottom': '10px'\r\n            }\"></ngx-skeleton-loader>\r\n  </div>\r\n  <div class=\"wrapper\">\r\n    <ngx-skeleton-loader [theme]=\"{\r\n              width: '60%',\r\n              'border-radius': '0',\r\n              height: '15px',\r\n              'margin-bottom': '10px'\r\n            }\"></ngx-skeleton-loader>\r\n  </div>\r\n  <div class=\"wrapper\">\r\n    <ngx-skeleton-loader [theme]=\"{\r\n              width: '80%',\r\n              'border-radius': '0',\r\n              height: '15px',\r\n              'margin-bottom': '10px'\r\n            }\"></ngx-skeleton-loader>\r\n  </div>\r\n  <div class=\"wrapper\">\r\n    <ngx-skeleton-loader [theme]=\"{\r\n              width: '90%',\r\n              'border-radius': '0',\r\n              height: '15px',\r\n              'margin-bottom': '10px'\r\n            }\"></ngx-skeleton-loader>\r\n  </div>\r\n  <div class=\"wrapper\">\r\n    <ngx-skeleton-loader [theme]=\"{\r\n              width: '60%',\r\n              'border-radius': '0',\r\n              height: '15px',\r\n              'margin-bottom': '10px'\r\n            }\"></ngx-skeleton-loader>\r\n  </div>\r\n</div>\r\n", styles: [".item,.fb-item{width:auto;height:auto;margin:10px auto;border:1px solid #eaeaea;padding:10px}.gravatar{width:100px;height:90px}.gravatar-title{width:500px;padding:10px;height:80px}.first-section-wrapper,.second-section-wrapper{width:100%;height:auto;flex:1}.first-section-wrapper{display:inline-flex}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(OSkeletonComponent, { className: "OSkeletonComponent", filePath: "lib\\components\\o-skeleton\\o-skeleton.component.ts", lineNumber: 14 }); })();

class ODataViewGridItemDirective {
    constructor(template) {
        this.template = template;
    }
    static { this.ɵfac = function ODataViewGridItemDirective_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ODataViewGridItemDirective)(i0.ɵɵdirectiveInject(i0.TemplateRef)); }; }
    static { this.ɵdir = /*@__PURE__*/ i0.ɵɵdefineDirective({ type: ODataViewGridItemDirective, selectors: [["", "oDataViewGridItem", ""]], standalone: true }); }
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ODataViewGridItemDirective, [{
        type: Directive,
        args: [{
                selector: '[oDataViewGridItem]',
                standalone: true
            }]
    }], () => [{ type: i0.TemplateRef }], null); })();

class ODataViewTableColumnsDirective {
    constructor(templateRef) {
        this.templateRef = templateRef;
    }
    static { this.ɵfac = function ODataViewTableColumnsDirective_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ODataViewTableColumnsDirective)(i0.ɵɵdirectiveInject(i0.TemplateRef)); }; }
    static { this.ɵdir = /*@__PURE__*/ i0.ɵɵdefineDirective({ type: ODataViewTableColumnsDirective, selectors: [["ng-template", "oDataViewTableColumns", ""]], standalone: true }); }
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ODataViewTableColumnsDirective, [{
        type: Directive,
        args: [{
                selector: 'ng-template[oDataViewTableColumns]',
                standalone: true
            }]
    }], () => [{ type: i0.TemplateRef }], null); })();

const _c0$1 = ["table"];
const _c1$1 = ["grid"];
const _c2$1 = ["toggleGroup"];
const _c3$1 = (a0, a1, a2) => ({ $implicit: a0, row: a1, index: a2 });
function ODataViewComponent_o_button_toggle_group_1_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "o-button-toggle-group", 9, 0);
    i0.ɵɵlistener("onChange", function ODataViewComponent_o_button_toggle_group_1_Template_o_button_toggle_group_onChange_0_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.changeView($event)); });
    i0.ɵɵelement(2, "o-button-toggle", 10)(3, "o-button-toggle", 11);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("value", ctx_r1.defaultView);
} }
function ODataViewComponent_o_table_3_o_button_toggle_group_2_Template(rf, ctx) { if (rf & 1) {
    const _r3 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "o-button-toggle-group", 14, 0);
    i0.ɵɵlistener("onChange", function ODataViewComponent_o_table_3_o_button_toggle_group_2_Template_o_button_toggle_group_onChange_0_listener($event) { i0.ɵɵrestoreView(_r3); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.changeView($event)); });
    i0.ɵɵelement(2, "o-button-toggle", 10)(3, "o-button-toggle", 11);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("value", ctx_r1.defaultView);
} }
function ODataViewComponent_o_table_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "o-table", 12, 1);
    i0.ɵɵtemplate(2, ODataViewComponent_o_table_3_o_button_toggle_group_2_Template, 4, 1, "o-button-toggle-group", 13);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("attr", "table_" + ctx_r1.attr)("columns", ctx_r1.columns)("configure-service-args", ctx_r1.configureServiceArgs)("entity", ctx_r1.entity)("keys", ctx_r1.keys)("pageable", ctx_r1.pageable)("paginated-query-method", ctx_r1.paginatedQueryMethod)("parent-keys", ctx_r1.parentKeys)("query-fallback-function", ctx_r1.queryFallbackFunction)("query-method", ctx_r1.queryMethod)("query-on-bind", ctx_r1.queryOnBind)("query-on-init", ctx_r1.queryOnInit)("query-rows", ctx_r1.queryRows)("query-with-null-parent-keys", ctx_r1.queryWithNullParentKeys)("service", ctx_r1.service)("service-type", ctx_r1.serviceType)("static-data", ctx_r1.staticData)("store-state", ctx_r1.storeState)("delete-method", ctx_r1.deleteMethod)("insert-method", ctx_r1.insertMethod)("update-method", ctx_r1.updateMethod)("controls", ctx_r1.controls)("detail-button-in-row", ctx_r1.r_table_detailButtonInRow)("detail-button-in-row-icon", ctx_r1.r_table_detailButtonInRowIcon)("detail-form-route", ctx_r1.detailFormRoute)("detail-mode", ctx_r1.r_table_detailMode)("edit-button-in-row", ctx_r1.r_table_editButtonInRow)("edit-button-in-row-icon", ctx_r1.r_table_editButtonInRowIcon)("edit-form-route", ctx_r1.r_table_editFormRoute)("enabled", ctx_r1.r_table_enabled)("filter-case-sensitive", ctx_r1.filterCaseSensitive)("insert-button", ctx_r1.insertButton)("insert-form-route", ctx_r1.insertFormRoute)("page-size-options", ctx_r1.r_table_pageSizeOptions)("pagination-controls", ctx_r1.paginationControls)("quick-filter", ctx_r1.quickFilter)("quick-filter-placeholder", ctx_r1.quickFilterPlaceholder)("recursive-detail", ctx_r1.recursiveDetail)("recursive-edit", ctx_r1.recursiveEdit)("recursive-insert", ctx_r1.recursiveInsert)("row-height", ctx_r1.r_table_rowHeight)("title", ctx_r1.title)("visible", ctx_r1.r_table_visible)("auto-adjust", ctx_r1.r_table_autoAdjust)("auto-align-titles", ctx_r1.r_table_autoAlignTitles)("collapse-grouped-columns", ctx_r1.r_table_collapseGroupedColumns)("columns-visibility-button", ctx_r1.r_table_columnsVisibilityButton)("default-visible-columns", ctx_r1.r_table_defaultVisibleColumns)("delete-button", ctx_r1.deleteButton)("disable-selection-function", ctx_r1.r_table_disableSelectionFunction)("edition-mode", ctx_r1.r_table_editionMode)("export-button", ctx_r1.r_table_exportButton)("export-service-type", ctx_r1.r_table_exportServiceType)("filter-column-active-by-default", ctx_r1.r_table_filterColumnActiveByDefault)("fixed-header", ctx_r1.fixedHeader)("groupable", ctx_r1.r_table_groupable)("grouped-columns", ctx_r1.r_table_groupedColumns)("horizontal-scroll", ctx_r1.r_table_horizontalScroll)("keep-selected-items", ctx_r1.r_table_keepSelectedItems)("multiple-sort", ctx_r1.r_table_multipleSort)("non-hidable-columns", ctx_r1.r_table_nonHidableColumns)("quick-filter-function", ctx_r1.r_table_quickFilterFunction)("refresh-button", ctx_r1.refreshButton)("resizable", ctx_r1.r_table_resizable)("row-class", ctx_r1.r_table_rowClass)("select-all-checkbox", ctx_r1.r_table_selectAllCheckbox)("select-all-checkbox-visible", ctx_r1.r_table_selectAllCheckboxVisible)("selection-mode", ctx_r1.r_table_selectionMode)("show-buttons-text", ctx_r1.showButtonsText)("show-configuration-option", ctx_r1.r_table_showConfigurationOption)("show-expandable-icon-function", ctx_r1.r_table_showExpandableIconFunction)("show-filter-option", ctx_r1.r_table_showFilterOption)("show-paginator-first-last-buttons", ctx_r1.r_table_showPaginatorFirstLastButtons)("show-report-on-demand-option", ctx_r1.r_table_showReportOnDemandOption)("show-reset-width-option", ctx_r1.r_table_showResetWidthOption)("sort-columns", ctx_r1.r_table_sortColumns)("virtual-scroll", ctx_r1.r_table_virtualScroll)("visible-columns", ctx_r1.r_table_visibleColumns)("visible-export-dialog-buttons", ctx_r1.r_table_visibleExportDialogButtons)("show-charts-on-demand-option", ctx_r1.r_table_showChartsOnDemandOption);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", ctx_r1.toggleButton && !ctx_r1.toggleFloatable && ctx_r1.toggleOnToolbar);
} }
function ODataViewComponent_o_grid_4_o_button_toggle_group_2_Template(rf, ctx) { if (rf & 1) {
    const _r4 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "o-button-toggle-group", 18, 0);
    i0.ɵɵlistener("onChange", function ODataViewComponent_o_grid_4_o_button_toggle_group_2_Template_o_button_toggle_group_onChange_0_listener($event) { i0.ɵɵrestoreView(_r4); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.changeView($event)); });
    i0.ɵɵelement(2, "o-button-toggle", 10)(3, "o-button-toggle", 11);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵproperty("value", ctx_r1.defaultView);
} }
function ODataViewComponent_o_grid_4_o_grid_item_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "o-grid-item");
    i0.ɵɵelementContainer(1, 19);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const row_r5 = ctx.$implicit;
    const i_r6 = ctx.index;
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngTemplateOutlet", ctx_r1.gridItemTpl == null ? null : ctx_r1.gridItemTpl.template)("ngTemplateOutletContext", i0.ɵɵpureFunction3(2, _c3$1, row_r5, row_r5, i_r6));
} }
function ODataViewComponent_o_grid_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "o-grid", 15, 2);
    i0.ɵɵtemplate(2, ODataViewComponent_o_grid_4_o_button_toggle_group_2_Template, 4, 1, "o-button-toggle-group", 16)(3, ODataViewComponent_o_grid_4_o_grid_item_3_Template, 2, 6, "o-grid-item", 17);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const grid_r7 = i0.ɵɵreference(1);
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("attr", "grid_" + ctx_r1.attr)("columns", ctx_r1.columns)("configure-service-args", ctx_r1.configureServiceArgs)("entity", ctx_r1.entity)("keys", ctx_r1.keys)("pageable", ctx_r1.pageable)("paginated-query-method", ctx_r1.paginatedQueryMethod)("parent-keys", ctx_r1.parentKeys)("query-fallback-function", ctx_r1.queryFallbackFunction)("query-method", ctx_r1.queryMethod)("query-on-bind", ctx_r1.queryOnBind)("query-on-init", ctx_r1.queryOnInit)("query-rows", ctx_r1.queryRows)("query-with-null-parent-keys", ctx_r1.queryWithNullParentKeys)("service", ctx_r1.service)("service-type", ctx_r1.serviceType)("static-data", ctx_r1.staticData)("store-state", ctx_r1.storeState)("controls", ctx_r1.controls)("detail-form-route", ctx_r1.detailFormRoute)("detail-mode", ctx_r1.r_grid_detailMode)("enabled", ctx_r1.r_grid_enabled)("quick-filter", ctx_r1.quickFilter)("quick-filter-placeholder", ctx_r1.quickFilterPlaceholder)("quick-filter-appearance", ctx_r1.quickFilterAppearance)("recursive-detail", ctx_r1.recursiveDetail)("title", ctx_r1.title)("visible", ctx_r1.r_grid_visible)("cols", ctx_r1.r_grid_cols)("fixed-header", ctx_r1.fixedHeader)("grid-item-height", ctx_r1.r_grid_gridItemHeight)("gutter-size", ctx_r1.r_grid_gutterSize)("insert-button", ctx_r1.insertButton)("insert-button-floatable", ctx_r1.r_grid_insertButtonFloatable)("insert-button-position", ctx_r1.r_grid_insertButtonPosition)("orderable", ctx_r1.r_grid_orderable)("page-size-options", ctx_r1.r_grid_pageSizeOptions)("pagination-controls", ctx_r1.paginationControls)("quick-filter-columns", ctx_r1.r_grid_quickFilterColumns)("refresh-button", ctx_r1.refreshButton)("show-buttons-text", ctx_r1.showButtonsText)("show-footer", ctx_r1.r_grid_showFooter)("show-page-size", ctx_r1.r_grid_showPageSize)("sort-column", ctx_r1.r_grid_sortColumn)("sortable-columns", ctx_r1.r_grid_sortableColumns);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", ctx_r1.toggleButton && !ctx_r1.toggleFloatable && ctx_r1.toggleOnToolbar);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngForOf", grid_r7.dataArray);
} }
function ODataViewComponent_o_button_toggle_group_5_Template(rf, ctx) { if (rf & 1) {
    const _r8 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "o-button-toggle-group", 20, 0);
    i0.ɵɵlistener("onChange", function ODataViewComponent_o_button_toggle_group_5_Template_o_button_toggle_group_onChange_0_listener($event) { i0.ɵɵrestoreView(_r8); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.changeView($event)); });
    i0.ɵɵelement(2, "o-button-toggle", 10)(3, "o-button-toggle", 11);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("value", ctx_r1.defaultView);
} }
class ODataViewComponent {
    constructor(vcr, tableGlobalConfig) {
        this.vcr = vcr;
        this.tableGlobalConfig = tableGlobalConfig;
        this.toggleButton = true;
        this.toggleOnToolbar = false;
        this.toggleFloatable = false;
        this.deleteMethod = Codes.DELETE_METHOD;
        this.insertMethod = Codes.INSERT_METHOD;
        this.pageable = false;
        this.paginatedQueryMethod = Codes.PAGINATED_QUERY_METHOD;
        this.queryMethod = Codes.QUERY_METHOD;
        this.queryOnBind = true;
        this.queryOnInit = true;
        this.queryRows = Codes.DEFAULT_QUERY_ROWS;
        this.queryWithNullParentKeys = false;
        this.storeState = true;
        this.updateMethod = Codes.UPDATE_METHOD;
        this.showButtonsText = true;
        this.quickFilterPlaceholder = "";
        this.insertButton = true;
        this.refreshButton = true;
        this.fixedHeader = true;
        this.controls = true;
        this.quickFilter = true;
        this.quickFilterAppearance = 'outline';
        this.recursiveDetail = false;
        this.recursiveEdit = false;
        this.recursiveInsert = false;
        this.paginationControls = true;
        this.insertFormRoute = Codes.DEFAULT_INSERT_ROUTE;
        this.filterCaseSensitive = false;
        this.deleteButton = true;
        this.columnsView = null;
    }
    ngOnInit() {
        if (!this.defaultView)
            this.defaultView = 'table';
    }
    ngAfterViewInit() {
        if (this.tableTpl && this.table) {
            this.syncTableColumnsWithTable();
        }
    }
    ngOnDestroy() {
        if (this.columnsView) {
            this.columnsView.destroy();
            this.columnsView = null;
        }
    }
    syncTableColumnsWithTable() {
        if (!this.tableTpl || !this.table?.injector) {
            return;
        }
        try {
            // Create the embedded view with the correct injector
            this.columnsView = this.vcr.createEmbeddedView(this.tableTpl.templateRef, {}, { injector: this.table.injector });
            // Detect changes to ensure nodes are fully initialized
            this.columnsView.detectChanges();
            setTimeout(() => {
                this.table.initializeParams();
                this.table.parseVisibleColumns();
                this.table.parseGroupedColumns();
                this.table.setFiltersConfiguration();
            }, 0);
        }
        catch (error) {
            console.error('Error registering table columns:', error);
        }
    }
    changeView(value) {
        const previousView = this.defaultView;
        if (this.toggleGroup) {
            this.defaultView = this.toggleGroup.getValue();
        }
        else {
            this.defaultView = value;
        }
        this.defaultView === 'grid' ? this.table.updateStateStorage() : this.grid.updateStateStorage();
        // If switching to table and columns aren't registered, register them
        if (this.defaultView === 'table' && previousView !== 'table') {
            setTimeout(() => this.syncTableColumnsWithTable(), 0);
        }
    }
    ngOnChanges() {
        this.resolveTableInputs();
        this.resolveGridInputs();
    }
    resolveTableInputs() {
        const cfg = this.tableConfig ?? {};
        const g = this.tableGlobalConfig;
        this.r_table_detailButtonInRow = this.setDefaultValue(cfg.detailButtonInRow, 'no');
        this.r_table_detailButtonInRowIcon = this.setDefaultValue(cfg.detailButtonInRowIcon, Codes.DETAIL_ICON);
        this.r_table_editButtonInRow = this.setDefaultValue(cfg.editButtonInRow, 'no');
        this.r_table_editButtonInRowIcon = this.setDefaultValue(cfg.editButtonInRowIcon, Codes.EDIT_ICON);
        this.r_table_editFormRoute = this.setDefaultValue(cfg.editFormRoute, '');
        this.r_table_enabled = this.setDefaultValue(cfg.enabled, 'yes');
        this.r_table_rowHeight = this.resolveStringWithGlobal(cfg.rowHeight, g?.rowHeight, Codes.DEFAULT_ROW_HEIGHT);
        this.r_table_visible = this.setDefaultValue(cfg.visible, 'yes');
        this.r_table_autoAdjust = this.resolveYesNoWithGlobal(cfg.autoAdjust, g?.autoAdjust, 'yes');
        this.r_table_autoAlignTitles = this.resolveYesNoWithGlobal(cfg.autoAlignTitles, g?.autoAlignTitles, 'yes');
        this.r_table_collapseGroupedColumns = this.setDefaultValue(cfg.collapseGroupedColumns, 'no');
        this.r_table_columnsVisibilityButton = this.setDefaultValue(cfg.columnsVisibilityButton, 'yes');
        this.r_table_defaultVisibleColumns = this.optionalString(cfg.defaultVisibleColumns);
        this.r_table_editionMode = this.resolveStringWithGlobal(cfg.editionMode, g?.editionMode, Codes.EDITION_MODE_NONE);
        this.r_table_exportButton = this.setDefaultValue(cfg.exportButton, 'yes');
        this.r_table_exportServiceType = this.setDefaultValue(cfg.exportServiceType, 'OntimizeExportService');
        this.r_table_filterColumnActiveByDefault = this.resolveYesNoWithGlobal(cfg.filterColumnActiveByDefault, g?.filterColumnActiveByDefault, 'yes');
        this.r_table_groupable = this.setDefaultValue(cfg.groupable, 'yes');
        this.r_table_groupedColumns = this.optionalString(cfg.groupedColumns);
        this.r_table_horizontalScroll = this.setDefaultValue(cfg.horizontalScroll, 'no');
        this.r_table_multipleSort = this.setDefaultValue(cfg.multipleSort, 'yes');
        this.r_table_nonHidableColumns = this.optionalString(cfg.nonHidableColumns);
        this.r_table_pageSizeOptions = this.setDefaultArray(cfg.pageSizeOptions, Codes.PAGE_SIZE_OPTIONS);
        this.r_table_resizable = this.setDefaultValue(cfg.resizable, 'yes');
        this.r_table_selectAllCheckbox = this.setDefaultValue(cfg.selectAllCheckbox, 'no');
        this.r_table_selectAllCheckboxVisible = this.setDefaultValue(cfg.selectAllCheckboxVisible, 'no');
        this.r_table_selectionMode = this.setDefaultValue(cfg.selectionMode, Codes.SELECTION_MODE_MULTIPLE);
        this.r_table_showConfigurationOption = this.setDefaultValue(cfg.showConfigurationOption, 'yes');
        this.r_table_showFilterOption = this.setDefaultValue(cfg.showFilterOption, 'yes');
        this.r_table_showPaginatorFirstLastButtons = this.setDefaultValue(cfg.showPaginatorFirstLastButtons, 'yes');
        this.r_table_showChartsOnDemandOption = this.setDefaultValue(cfg.showChartsOnDemandOption, 'yes');
        this.r_table_showReportOnDemandOption = this.setDefaultValue(cfg.showReportOnDemandOption, 'yes');
        this.r_table_showResetWidthOption = this.setDefaultValue(cfg.showResetWidthOption, 'yes');
        this.r_table_sortColumns = this.optionalString(cfg.sortColumns);
        this.r_table_virtualScroll = this.setDefaultValue(cfg.virtualScroll, 'yes');
        this.r_table_visibleColumns = this.optionalString(cfg.visibleColumns);
        this.r_table_visibleExportDialogButtons = this.setDefaultValue(cfg.visibleExportDialogButtons, '');
        this.r_table_selectionOnRowClick = this.resolveYesNoWithGlobal(cfg.selectionOnRowClick, g?.selectionOnRowClick, 'yes');
        this.r_table_detailMode = this.resolveStringWithGlobal(cfg.detailMode, g?.detailMode, Codes.DETAIL_MODE_CLICK);
        this.r_table_disableSelectionFunction = cfg.disableSelectionFunction;
        this.r_table_quickFilterFunction = cfg.quickFilterFunction;
        this.r_table_rowClass = cfg.rowClass;
        this.r_table_showExpandableIconFunction = cfg.showExpandableIconFunction;
    }
    resolveGridInputs() {
        const cfg = this.gridConfig ?? {};
        this.r_grid_enabled = this.setDefaultValue(cfg.enabled, 'yes');
        this.r_grid_visible = this.setDefaultValue(cfg.visible, 'yes');
        this.r_grid_cols = cfg.cols;
        this.r_grid_gridItemHeight = this.setDefaultValueAny(cfg?.gridItemHeight, '1:1');
        this.r_grid_gutterSize = this.setDefaultValue(cfg.gutterSize, '1px');
        this.r_grid_insertButtonFloatable = this.setDefaultValue(cfg.insertButtonFloatable, 'yes');
        this.r_grid_insertButtonPosition = this.setDefaultValue(cfg.insertButtonPosition, 'bottom');
        this.r_grid_orderable = this.setDefaultValue(cfg.orderable, 'no');
        this.r_grid_showFooter = this.setDefaultValue(cfg.showFooter, 'yes');
        this.r_grid_showPageSize = this.setDefaultValue(cfg.showPageSize, 'no');
        this.r_grid_sortColumn = this.optionalString(cfg.sortColumn);
        this.r_grid_sortableColumns = this.optionalString(cfg.sortableColumns);
        this.r_grid_detailMode = this.setDefaultValue(cfg.detailMode, Codes.DETAIL_MODE_CLICK);
        this.r_grid_pageSizeOptions = this.setDefaultArray(cfg.pageSizeOptions, [8, 16, 24, 32, 64]);
        this.r_grid_quickFilterColumns = this.setDefaultValue(cfg.quickFilterColumns, this.columns);
    }
    setDefaultValue(v, def) {
        if (v === undefined || v === null || v === '')
            return def;
        return v;
    }
    setDefaultValueAny(v, def) {
        if (v === undefined || v === null)
            return def;
        if (typeof v === 'string' && v === '')
            return def;
        return v;
    }
    setDefaultNumber(v, def) {
        if (v === undefined || v === null)
            return def;
        return v;
    }
    setDefaultArray(v, def) {
        if (v === undefined || v === null)
            return def;
        return v;
    }
    resolveYesNoWithGlobal(inputVal, globalVal, defaultVal) {
        const inputResolved = this.setDefaultValue(inputVal, defaultVal);
        if (inputResolved !== undefined)
            return inputResolved;
        if (globalVal !== undefined && globalVal !== null) {
            return globalVal ? 'yes' : 'no';
        }
        return defaultVal;
    }
    resolveStringWithGlobal(inputVal, globalVal, defaultVal) {
        const inputResolved = this.setDefaultValue(inputVal, defaultVal);
        if (inputResolved !== undefined)
            return inputResolved;
        const globalResolved = this.setDefaultValue(globalVal, defaultVal);
        if (globalResolved !== undefined)
            return globalResolved;
        return defaultVal;
    }
    optionalString(v) {
        if (v === undefined || v === null)
            return undefined;
        const s = String(v).trim();
        return s.length ? s : undefined;
    }
    static { this.ɵfac = function ODataViewComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ODataViewComponent)(i0.ɵɵdirectiveInject(i0.ViewContainerRef), i0.ɵɵdirectiveInject(O_TABLE_GLOBAL_CONFIG, 8)); }; }
    static { this.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: ODataViewComponent, selectors: [["o-data-view"]], contentQueries: function ODataViewComponent_ContentQueries(rf, ctx, dirIndex) { if (rf & 1) {
            i0.ɵɵcontentQuery(dirIndex, ODataViewGridItemDirective, 7);
            i0.ɵɵcontentQuery(dirIndex, ODataViewTableColumnsDirective, 7);
        } if (rf & 2) {
            let _t;
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.gridItemTpl = _t.first);
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.tableTpl = _t.first);
        } }, viewQuery: function ODataViewComponent_Query(rf, ctx) { if (rf & 1) {
            i0.ɵɵviewQuery(_c0$1, 5);
            i0.ɵɵviewQuery(_c1$1, 5);
            i0.ɵɵviewQuery(_c2$1, 5);
        } if (rf & 2) {
            let _t;
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.table = _t.first);
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.grid = _t.first);
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.toggleGroup = _t.first);
        } }, inputs: { defaultView: [0, "default-view", "defaultView"], toggleButton: [0, "toggle-button", "toggleButton"], toggleOnToolbar: [0, "toggle-on-toolbar", "toggleOnToolbar"], toggleFloatable: [0, "toggle-floatable", "toggleFloatable"], attr: "attr", columns: "columns", configureServiceArgs: [0, "configure-service-args", "configureServiceArgs"], deleteMethod: [0, "delete-method", "deleteMethod"], entity: "entity", insertMethod: [0, "insert-method", "insertMethod"], keys: "keys", pageable: "pageable", paginatedQueryMethod: [0, "paginated-query-method", "paginatedQueryMethod"], parentKeys: [0, "parent-keys", "parentKeys"], queryFallbackFunction: [0, "query-fallback-function", "queryFallbackFunction"], queryMethod: [0, "query-method", "queryMethod"], queryOnBind: [0, "query-on-bind", "queryOnBind"], queryOnInit: [0, "query-on-init", "queryOnInit"], queryRows: [0, "query-rows", "queryRows"], queryWithNullParentKeys: [0, "query-with-null-parent-keys", "queryWithNullParentKeys"], service: "service", serviceType: [0, "service-type", "serviceType"], staticData: [0, "static-data", "staticData"], storeState: [0, "store-state", "storeState"], updateMethod: [0, "update-method", "updateMethod"], showButtonsText: [0, "show-buttons-text", "showButtonsText"], quickFilterPlaceholder: [0, "quick-filter-placeholder", "quickFilterPlaceholder"], insertButton: [0, "insert-button", "insertButton"], refreshButton: [0, "refresh-button", "refreshButton"], fixedHeader: [0, "fixed-header", "fixedHeader"], controls: "controls", title: "title", quickFilter: [0, "quick-filter", "quickFilter"], quickFilterAppearance: [0, "quick-filter-appearance", "quickFilterAppearance"], recursiveDetail: [0, "recursive-detail", "recursiveDetail"], recursiveEdit: [0, "recursive-edit", "recursiveEdit"], recursiveInsert: [0, "recursive-insert", "recursiveInsert"], detailFormRoute: [0, "detail-form-route", "detailFormRoute"], paginationControls: [0, "pagination-controls", "paginationControls"], insertFormRoute: [0, "insert-form-route", "insertFormRoute"], filterCaseSensitive: [0, "filter-case-sensitive", "filterCaseSensitive"], deleteButton: [0, "delete-button", "deleteButton"], tableConfig: [0, "table-config", "tableConfig"], gridConfig: [0, "grid-config", "gridConfig"] }, standalone: true, features: [i0.ɵɵNgOnChangesFeature, i0.ɵɵStandaloneFeature], decls: 6, vars: 4, consts: [["toggleGroup", ""], ["table", ""], ["grid", ""], [1, "o-data-view-container", "bg-level-1"], ["class", "button-toggle-group", "attr", "toggleGroup", "multiple", "no", 3, "value", "onChange", 4, "ngIf"], [1, "o-data-view-component"], ["show-title", "yes", 3, "attr", "columns", "configure-service-args", "entity", "keys", "pageable", "paginated-query-method", "parent-keys", "query-fallback-function", "query-method", "query-on-bind", "query-on-init", "query-rows", "query-with-null-parent-keys", "service", "service-type", "static-data", "store-state", "delete-method", "insert-method", "update-method", "controls", "detail-button-in-row", "detail-button-in-row-icon", "detail-form-route", "detail-mode", "edit-button-in-row", "edit-button-in-row-icon", "edit-form-route", "enabled", "filter-case-sensitive", "insert-button", "insert-form-route", "page-size-options", "pagination-controls", "quick-filter", "quick-filter-placeholder", "recursive-detail", "recursive-edit", "recursive-insert", "row-height", "title", "visible", "auto-adjust", "auto-align-titles", "collapse-grouped-columns", "columns-visibility-button", "default-visible-columns", "delete-button", "disable-selection-function", "edition-mode", "export-button", "export-service-type", "filter-column-active-by-default", "fixed-header", "groupable", "grouped-columns", "horizontal-scroll", "keep-selected-items", "multiple-sort", "non-hidable-columns", "quick-filter-function", "refresh-button", "resizable", "row-class", "select-all-checkbox", "select-all-checkbox-visible", "selection-mode", "show-buttons-text", "show-configuration-option", "show-expandable-icon-function", "show-filter-option", "show-paginator-first-last-buttons", "show-report-on-demand-option", "show-reset-width-option", "sort-columns", "virtual-scroll", "visible-columns", "visible-export-dialog-buttons", "show-charts-on-demand-option", 4, "ngIf"], ["class", "data-view-grid", 3, "attr", "columns", "configure-service-args", "entity", "keys", "pageable", "paginated-query-method", "parent-keys", "query-fallback-function", "query-method", "query-on-bind", "query-on-init", "query-rows", "query-with-null-parent-keys", "service", "service-type", "static-data", "store-state", "controls", "detail-form-route", "detail-mode", "enabled", "quick-filter", "quick-filter-placeholder", "quick-filter-appearance", "recursive-detail", "title", "visible", "cols", "fixed-header", "grid-item-height", "gutter-size", "insert-button", "insert-button-floatable", "insert-button-position", "orderable", "page-size-options", "pagination-controls", "quick-filter-columns", "refresh-button", "show-buttons-text", "show-footer", "show-page-size", "sort-column", "sortable-columns", 4, "ngIf"], ["class", "button-toggle-group toggle-floatable", "attr", "toggleGroup", "multiple", "no", 3, "value", "onChange", 4, "ngIf"], ["attr", "toggleGroup", "multiple", "no", 1, "button-toggle-group", 3, "onChange", "value"], ["attr", "toggle1", "value", "table", "icon", "storage"], ["attr", "toggle2", "value", "grid", "icon", "view_module"], ["show-title", "yes", 3, "attr", "columns", "configure-service-args", "entity", "keys", "pageable", "paginated-query-method", "parent-keys", "query-fallback-function", "query-method", "query-on-bind", "query-on-init", "query-rows", "query-with-null-parent-keys", "service", "service-type", "static-data", "store-state", "delete-method", "insert-method", "update-method", "controls", "detail-button-in-row", "detail-button-in-row-icon", "detail-form-route", "detail-mode", "edit-button-in-row", "edit-button-in-row-icon", "edit-form-route", "enabled", "filter-case-sensitive", "insert-button", "insert-form-route", "page-size-options", "pagination-controls", "quick-filter", "quick-filter-placeholder", "recursive-detail", "recursive-edit", "recursive-insert", "row-height", "title", "visible", "auto-adjust", "auto-align-titles", "collapse-grouped-columns", "columns-visibility-button", "default-visible-columns", "delete-button", "disable-selection-function", "edition-mode", "export-button", "export-service-type", "filter-column-active-by-default", "fixed-header", "groupable", "grouped-columns", "horizontal-scroll", "keep-selected-items", "multiple-sort", "non-hidable-columns", "quick-filter-function", "refresh-button", "resizable", "row-class", "select-all-checkbox", "select-all-checkbox-visible", "selection-mode", "show-buttons-text", "show-configuration-option", "show-expandable-icon-function", "show-filter-option", "show-paginator-first-last-buttons", "show-report-on-demand-option", "show-reset-width-option", "sort-columns", "virtual-scroll", "visible-columns", "visible-export-dialog-buttons", "show-charts-on-demand-option"], ["class", "button-toggle-group toggle-toolbar", "attr", "toggleGroup", "o-table-toolbar", "", "position", "end", "multiple", "no", 3, "value", "onChange", 4, "ngIf"], ["attr", "toggleGroup", "o-table-toolbar", "", "position", "end", "multiple", "no", 1, "button-toggle-group", "toggle-toolbar", 3, "onChange", "value"], [1, "data-view-grid", 3, "attr", "columns", "configure-service-args", "entity", "keys", "pageable", "paginated-query-method", "parent-keys", "query-fallback-function", "query-method", "query-on-bind", "query-on-init", "query-rows", "query-with-null-parent-keys", "service", "service-type", "static-data", "store-state", "controls", "detail-form-route", "detail-mode", "enabled", "quick-filter", "quick-filter-placeholder", "quick-filter-appearance", "recursive-detail", "title", "visible", "cols", "fixed-header", "grid-item-height", "gutter-size", "insert-button", "insert-button-floatable", "insert-button-position", "orderable", "page-size-options", "pagination-controls", "quick-filter-columns", "refresh-button", "show-buttons-text", "show-footer", "show-page-size", "sort-column", "sortable-columns"], ["class", "button-toggle-group toggle-toolbar", "attr", "toggleGroup", "o-grid-toolbar", "", "position", "end", "multiple", "no", 3, "value", "onChange", 4, "ngIf"], [4, "ngFor", "ngForOf"], ["attr", "toggleGroup", "o-grid-toolbar", "", "position", "end", "multiple", "no", 1, "button-toggle-group", "toggle-toolbar", 3, "onChange", "value"], [3, "ngTemplateOutlet", "ngTemplateOutletContext"], ["attr", "toggleGroup", "multiple", "no", 1, "button-toggle-group", "toggle-floatable", 3, "onChange", "value"]], template: function ODataViewComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 3);
            i0.ɵɵtemplate(1, ODataViewComponent_o_button_toggle_group_1_Template, 4, 1, "o-button-toggle-group", 4);
            i0.ɵɵelementStart(2, "div", 5);
            i0.ɵɵtemplate(3, ODataViewComponent_o_table_3_Template, 3, 81, "o-table", 6)(4, ODataViewComponent_o_grid_4_Template, 4, 47, "o-grid", 7)(5, ODataViewComponent_o_button_toggle_group_5_Template, 4, 1, "o-button-toggle-group", 8);
            i0.ɵɵelementEnd()();
        } if (rf & 2) {
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.toggleButton && !ctx.toggleFloatable && !ctx.toggleOnToolbar);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", ctx.defaultView === "table");
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.defaultView === "grid");
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.toggleButton && ctx.toggleFloatable);
        } }, dependencies: [CommonModule, i2.NgForOf, i2.NgIf, i2.NgTemplateOutlet, OTableModule, i1$1.OTableComponent, OGridModule, i1$1.OGridComponent, i1$1.OGridItemComponent, OButtonToggleModule, i1$1.OButtonToggleComponent, i1$1.OButtonToggleGroupComponent], styles: [".button-toggle-group{display:flex;flex-direction:row;justify-content:flex-end;margin-bottom:8px;margin-right:8px;margin-top:8px}.button-toggle-group .mat-button-toggle-standalone,.button-toggle-group .mat-button-toggle-group{height:30px}.button-toggle-group .mat-button-toggle-standalone .o-button-toggle .mat-button-toggle,.button-toggle-group .mat-button-toggle-group .o-button-toggle .mat-button-toggle{height:30px;width:32px}.button-toggle-group .mat-button-toggle-standalone .o-button-toggle .mat-button-toggle span.mat-button-toggle-label-content,.button-toggle-group .mat-button-toggle-group .o-button-toggle .mat-button-toggle span.mat-button-toggle-label-content{display:flex;padding:0;justify-content:center}.toggle-floatable{position:absolute;left:calc(50% - 32px);bottom:10px;z-index:1000}.toggle-toolbar{margin-bottom:0;margin-top:0}:host{display:flex;flex-direction:column;height:100%}.o-data-view-container{flex:1 1 auto;display:flex;flex-direction:column;height:100%}.o-data-view-component{flex:1 1 auto;min-height:0;overflow:hidden;display:flex;flex-direction:column;position:relative}.data-view-grid{overflow:auto}.data-view-grid .o-grid-container{padding:0 .5%}\n"], encapsulation: 2 }); }
}
__decorate([
    BooleanInputConverter()
], ODataViewComponent.prototype, "toggleButton", void 0);
__decorate([
    BooleanInputConverter()
], ODataViewComponent.prototype, "toggleOnToolbar", void 0);
__decorate([
    BooleanInputConverter()
], ODataViewComponent.prototype, "toggleFloatable", void 0);
__decorate([
    BooleanInputConverter()
], ODataViewComponent.prototype, "pageable", void 0);
__decorate([
    BooleanInputConverter()
], ODataViewComponent.prototype, "queryOnBind", void 0);
__decorate([
    BooleanInputConverter()
], ODataViewComponent.prototype, "queryOnInit", void 0);
__decorate([
    BooleanInputConverter()
], ODataViewComponent.prototype, "queryWithNullParentKeys", void 0);
__decorate([
    BooleanInputConverter()
], ODataViewComponent.prototype, "storeState", void 0);
__decorate([
    BooleanInputConverter()
], ODataViewComponent.prototype, "showButtonsText", void 0);
__decorate([
    BooleanInputConverter()
], ODataViewComponent.prototype, "insertButton", void 0);
__decorate([
    BooleanInputConverter()
], ODataViewComponent.prototype, "refreshButton", void 0);
__decorate([
    BooleanInputConverter()
], ODataViewComponent.prototype, "fixedHeader", void 0);
__decorate([
    BooleanInputConverter()
], ODataViewComponent.prototype, "controls", void 0);
__decorate([
    BooleanInputConverter()
], ODataViewComponent.prototype, "quickFilter", void 0);
__decorate([
    BooleanInputConverter()
], ODataViewComponent.prototype, "recursiveDetail", void 0);
__decorate([
    BooleanInputConverter()
], ODataViewComponent.prototype, "recursiveEdit", void 0);
__decorate([
    BooleanInputConverter()
], ODataViewComponent.prototype, "recursiveInsert", void 0);
__decorate([
    BooleanInputConverter()
], ODataViewComponent.prototype, "paginationControls", void 0);
__decorate([
    BooleanInputConverter()
], ODataViewComponent.prototype, "filterCaseSensitive", void 0);
__decorate([
    BooleanInputConverter()
], ODataViewComponent.prototype, "deleteButton", void 0);
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ODataViewComponent, [{
        type: Component,
        args: [{ selector: 'o-data-view', standalone: true, imports: [CommonModule, OTableModule, OGridModule, OButtonToggleModule, ODataViewTableColumnsDirective, ODataViewGridItemDirective], encapsulation: ViewEncapsulation.None, template: "<div class=\"o-data-view-container bg-level-1\">\r\n\r\n  <o-button-toggle-group #toggleGroup *ngIf=\"toggleButton && !toggleFloatable && !toggleOnToolbar\" class=\"button-toggle-group\"\r\n    attr=\"toggleGroup\" multiple=\"no\" [value]=\"defaultView\" (onChange)=\"changeView($event)\">\r\n    <o-button-toggle attr=\"toggle1\" value=\"table\" icon=\"storage\"></o-button-toggle>\r\n    <o-button-toggle attr=\"toggle2\" value=\"grid\" icon=\"view_module\"></o-button-toggle>\r\n  </o-button-toggle-group>\r\n\r\n  <div class=\"o-data-view-component\">\r\n\r\n    <o-table #table *ngIf=\"defaultView === 'table'\" [attr]=\"'table_'+attr\" [columns]=\"columns\" [configure-service-args]=\"configureServiceArgs\"\r\n      [entity]=\"entity\" [keys]=\"keys\" [pageable]=\"pageable\" [paginated-query-method]=\"paginatedQueryMethod\" [parent-keys]=\"parentKeys\"\r\n      [query-fallback-function]=\"queryFallbackFunction\" [query-method]=\"queryMethod\" [query-on-bind]=\"queryOnBind\"\r\n      [query-on-init]=\"queryOnInit\" [query-rows]=\"queryRows\" [query-with-null-parent-keys]=\"queryWithNullParentKeys\" [service]=\"service\"\r\n      [service-type]=\"serviceType\" [static-data]=\"staticData\" [store-state]=\"storeState\" [delete-method]=\"deleteMethod\"\r\n      [insert-method]=\"insertMethod\" [update-method]=\"updateMethod\" [controls]=\"controls\"\r\n      [detail-button-in-row]=\"r_table_detailButtonInRow\" [detail-button-in-row-icon]=\"r_table_detailButtonInRowIcon\"\r\n      [detail-form-route]=\"detailFormRoute\" [detail-mode]=\"r_table_detailMode\" [edit-button-in-row]=\"r_table_editButtonInRow\"\r\n      [edit-button-in-row-icon]=\"r_table_editButtonInRowIcon\" [edit-form-route]=\"r_table_editFormRoute\" [enabled]=\"r_table_enabled\"\r\n      [filter-case-sensitive]=\"filterCaseSensitive\" [insert-button]=\"insertButton\" [insert-form-route]=\"insertFormRoute\"\r\n      [page-size-options]=\"r_table_pageSizeOptions\" [pagination-controls]=\"paginationControls\" [quick-filter]=\"quickFilter\"\r\n      [quick-filter-placeholder]=\"quickFilterPlaceholder\" [recursive-detail]=\"recursiveDetail\" [recursive-edit]=\"recursiveEdit\"\r\n      [recursive-insert]=\"recursiveInsert\" [row-height]=\"r_table_rowHeight\" [title]=\"title\" [visible]=\"r_table_visible\"\r\n      [auto-adjust]=\"r_table_autoAdjust\" [auto-align-titles]=\"r_table_autoAlignTitles\" [collapse-grouped-columns]=\"r_table_collapseGroupedColumns\"\r\n      [columns-visibility-button]=\"r_table_columnsVisibilityButton\" [default-visible-columns]=\"r_table_defaultVisibleColumns\"\r\n      [delete-button]=\"deleteButton\" [disable-selection-function]=\"r_table_disableSelectionFunction\" [edition-mode]=\"r_table_editionMode\"\r\n      [export-button]=\"r_table_exportButton\" [export-service-type]=\"r_table_exportServiceType\"\r\n      [filter-column-active-by-default]=\"r_table_filterColumnActiveByDefault\" [fixed-header]=\"fixedHeader\" [groupable]=\"r_table_groupable\"\r\n      [grouped-columns]=\"r_table_groupedColumns\" [horizontal-scroll]=\"r_table_horizontalScroll\" [keep-selected-items]=\"r_table_keepSelectedItems\"\r\n      [multiple-sort]=\"r_table_multipleSort\" [non-hidable-columns]=\"r_table_nonHidableColumns\" [quick-filter-function]=\"r_table_quickFilterFunction\"\r\n      [refresh-button]=\"refreshButton\" [resizable]=\"r_table_resizable\" [row-class]=\"r_table_rowClass\"\r\n      [select-all-checkbox]=\"r_table_selectAllCheckbox\" [select-all-checkbox-visible]=\"r_table_selectAllCheckboxVisible\"\r\n      [selection-mode]=\"r_table_selectionMode\" [show-buttons-text]=\"showButtonsText\" [show-configuration-option]=\"r_table_showConfigurationOption\"\r\n      [show-expandable-icon-function]=\"r_table_showExpandableIconFunction\" [show-filter-option]=\"r_table_showFilterOption\"\r\n      [show-paginator-first-last-buttons]=\"r_table_showPaginatorFirstLastButtons\" [show-report-on-demand-option]=\"r_table_showReportOnDemandOption\"\r\n      [show-reset-width-option]=\"r_table_showResetWidthOption\" [sort-columns]=\"r_table_sortColumns\"\r\n      [virtual-scroll]=\"r_table_virtualScroll\" [visible-columns]=\"r_table_visibleColumns\"\r\n      [visible-export-dialog-buttons]=\"r_table_visibleExportDialogButtons\" [show-charts-on-demand-option]=\"r_table_showChartsOnDemandOption\" show-title=\"yes\">\r\n\r\n      <o-button-toggle-group #toggleGroup *ngIf=\"toggleButton && !toggleFloatable && toggleOnToolbar\" class=\"button-toggle-group toggle-toolbar\" attr=\"toggleGroup\" o-table-toolbar position=\"end\"\r\n        multiple=\"no\" [value]=\"defaultView\" (onChange)=\"changeView($event)\">\r\n        <o-button-toggle attr=\"toggle1\" value=\"table\" icon=\"storage\"></o-button-toggle>\r\n        <o-button-toggle attr=\"toggle2\" value=\"grid\" icon=\"view_module\"></o-button-toggle>\r\n      </o-button-toggle-group>\r\n\r\n    </o-table>\r\n\r\n    <o-grid #grid class=\"data-view-grid\" *ngIf=\"defaultView === 'grid'\" [attr]=\"'grid_'+attr\" [columns]=\"columns\" [configure-service-args]=\"configureServiceArgs\"\r\n      [entity]=\"entity\" [keys]=\"keys\" [pageable]=\"pageable\" [paginated-query-method]=\"paginatedQueryMethod\" [parent-keys]=\"parentKeys\"\r\n      [query-fallback-function]=\"queryFallbackFunction\" [query-method]=\"queryMethod\" [query-on-bind]=\"queryOnBind\"\r\n      [query-on-init]=\"queryOnInit\" [query-rows]=\"queryRows\" [query-with-null-parent-keys]=\"queryWithNullParentKeys\" [service]=\"service\"\r\n      [service-type]=\"serviceType\" [static-data]=\"staticData\" [store-state]=\"storeState\" [controls]=\"controls\"\r\n      [detail-form-route]=\"detailFormRoute\" [detail-mode]=\"r_grid_detailMode\" [enabled]=\"r_grid_enabled\" [quick-filter]=\"quickFilter\"\r\n      [quick-filter-placeholder]=\"quickFilterPlaceholder\" [quick-filter-appearance]=\"quickFilterAppearance\"\r\n      [recursive-detail]=\"recursiveDetail\" [title]=\"title\" [visible]=\"r_grid_visible\" [cols]=\"r_grid_cols\"\r\n      [fixed-header]=\"fixedHeader\" [grid-item-height]=\"r_grid_gridItemHeight\" [gutter-size]=\"r_grid_gutterSize\"\r\n      [insert-button]=\"insertButton\" [insert-button-floatable]=\"r_grid_insertButtonFloatable\" [insert-button-position]=\"r_grid_insertButtonPosition\"\r\n      [orderable]=\"r_grid_orderable\" [page-size-options]=\"r_grid_pageSizeOptions\" [pagination-controls]=\"paginationControls\"\r\n      [quick-filter-columns]=\"r_grid_quickFilterColumns\" [refresh-button]=\"refreshButton\" [show-buttons-text]=\"showButtonsText\"\r\n      [show-footer]=\"r_grid_showFooter\" [show-page-size]=\"r_grid_showPageSize\" [sort-column]=\"r_grid_sortColumn\"\r\n      [sortable-columns]=\"r_grid_sortableColumns\">\r\n\r\n      <o-button-toggle-group #toggleGroup *ngIf=\"toggleButton && !toggleFloatable && toggleOnToolbar\" class=\"button-toggle-group toggle-toolbar\" attr=\"toggleGroup\" o-grid-toolbar position=\"end\"\r\n        multiple=\"no\" [value]=\"defaultView\" (onChange)=\"changeView($event)\">\r\n        <o-button-toggle attr=\"toggle1\" value=\"table\" icon=\"storage\"></o-button-toggle>\r\n        <o-button-toggle attr=\"toggle2\" value=\"grid\" icon=\"view_module\"></o-button-toggle>\r\n      </o-button-toggle-group>\r\n\r\n      <o-grid-item *ngFor=\"let row of grid.dataArray; let i = index\">\r\n        <ng-container [ngTemplateOutlet]=\"gridItemTpl?.template\" [ngTemplateOutletContext]=\"{ $implicit: row, row: row, index: i }\">\r\n        </ng-container>\r\n      </o-grid-item>\r\n\r\n    </o-grid>\r\n\r\n    <o-button-toggle-group #toggleGroup *ngIf=\"toggleButton && toggleFloatable\" class=\"button-toggle-group toggle-floatable\" attr=\"toggleGroup\" multiple=\"no\"\r\n      [value]=\"defaultView\" (onChange)=\"changeView($event)\">\r\n      <o-button-toggle attr=\"toggle1\" value=\"table\" icon=\"storage\"></o-button-toggle>\r\n      <o-button-toggle attr=\"toggle2\" value=\"grid\" icon=\"view_module\"></o-button-toggle>\r\n    </o-button-toggle-group>\r\n\r\n  </div>\r\n\r\n</div>\r\n", styles: [".button-toggle-group{display:flex;flex-direction:row;justify-content:flex-end;margin-bottom:8px;margin-right:8px;margin-top:8px}.button-toggle-group .mat-button-toggle-standalone,.button-toggle-group .mat-button-toggle-group{height:30px}.button-toggle-group .mat-button-toggle-standalone .o-button-toggle .mat-button-toggle,.button-toggle-group .mat-button-toggle-group .o-button-toggle .mat-button-toggle{height:30px;width:32px}.button-toggle-group .mat-button-toggle-standalone .o-button-toggle .mat-button-toggle span.mat-button-toggle-label-content,.button-toggle-group .mat-button-toggle-group .o-button-toggle .mat-button-toggle span.mat-button-toggle-label-content{display:flex;padding:0;justify-content:center}.toggle-floatable{position:absolute;left:calc(50% - 32px);bottom:10px;z-index:1000}.toggle-toolbar{margin-bottom:0;margin-top:0}:host{display:flex;flex-direction:column;height:100%}.o-data-view-container{flex:1 1 auto;display:flex;flex-direction:column;height:100%}.o-data-view-component{flex:1 1 auto;min-height:0;overflow:hidden;display:flex;flex-direction:column;position:relative}.data-view-grid{overflow:auto}.data-view-grid .o-grid-container{padding:0 .5%}\n"] }]
    }], () => [{ type: i0.ViewContainerRef }, { type: undefined, decorators: [{
                type: Optional
            }, {
                type: Inject,
                args: [O_TABLE_GLOBAL_CONFIG]
            }] }], { table: [{
            type: ViewChild,
            args: ['table', { static: false }]
        }], grid: [{
            type: ViewChild,
            args: ['grid']
        }], toggleGroup: [{
            type: ViewChild,
            args: ['toggleGroup']
        }], gridItemTpl: [{
            type: ContentChild,
            args: [ODataViewGridItemDirective, { static: true }]
        }], tableTpl: [{
            type: ContentChild,
            args: [ODataViewTableColumnsDirective, { static: true }]
        }], defaultView: [{
            type: Input,
            args: ['default-view']
        }], toggleButton: [{
            type: Input,
            args: ['toggle-button']
        }], toggleOnToolbar: [{
            type: Input,
            args: ['toggle-on-toolbar']
        }], toggleFloatable: [{
            type: Input,
            args: ['toggle-floatable']
        }], attr: [{
            type: Input
        }], columns: [{
            type: Input
        }], configureServiceArgs: [{
            type: Input,
            args: ['configure-service-args']
        }], deleteMethod: [{
            type: Input,
            args: ['delete-method']
        }], entity: [{
            type: Input
        }], insertMethod: [{
            type: Input,
            args: ['insert-method']
        }], keys: [{
            type: Input
        }], pageable: [{
            type: Input
        }], paginatedQueryMethod: [{
            type: Input,
            args: ['paginated-query-method']
        }], parentKeys: [{
            type: Input,
            args: ['parent-keys']
        }], queryFallbackFunction: [{
            type: Input,
            args: ['query-fallback-function']
        }], queryMethod: [{
            type: Input,
            args: ['query-method']
        }], queryOnBind: [{
            type: Input,
            args: ['query-on-bind']
        }], queryOnInit: [{
            type: Input,
            args: ['query-on-init']
        }], queryRows: [{
            type: Input,
            args: ['query-rows']
        }], queryWithNullParentKeys: [{
            type: Input,
            args: ['query-with-null-parent-keys']
        }], service: [{
            type: Input
        }], serviceType: [{
            type: Input,
            args: ['service-type']
        }], staticData: [{
            type: Input,
            args: ['static-data']
        }], storeState: [{
            type: Input,
            args: ['store-state']
        }], updateMethod: [{
            type: Input,
            args: ['update-method']
        }], showButtonsText: [{
            type: Input,
            args: ['show-buttons-text']
        }], quickFilterPlaceholder: [{
            type: Input,
            args: ['quick-filter-placeholder']
        }], insertButton: [{
            type: Input,
            args: ['insert-button']
        }], refreshButton: [{
            type: Input,
            args: ['refresh-button']
        }], fixedHeader: [{
            type: Input,
            args: ['fixed-header']
        }], controls: [{
            type: Input
        }], title: [{
            type: Input
        }], quickFilter: [{
            type: Input,
            args: ['quick-filter']
        }], quickFilterAppearance: [{
            type: Input,
            args: ['quick-filter-appearance']
        }], recursiveDetail: [{
            type: Input,
            args: ['recursive-detail']
        }], recursiveEdit: [{
            type: Input,
            args: ['recursive-edit']
        }], recursiveInsert: [{
            type: Input,
            args: ['recursive-insert']
        }], detailFormRoute: [{
            type: Input,
            args: ['detail-form-route']
        }], paginationControls: [{
            type: Input,
            args: ['pagination-controls']
        }], insertFormRoute: [{
            type: Input,
            args: ['insert-form-route']
        }], filterCaseSensitive: [{
            type: Input,
            args: ['filter-case-sensitive']
        }], deleteButton: [{
            type: Input,
            args: ['delete-button']
        }], tableConfig: [{
            type: Input,
            args: ['table-config']
        }], gridConfig: [{
            type: Input,
            args: ['grid-config']
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(ODataViewComponent, { className: "ODataViewComponent", filePath: "lib\\components\\o-data-view\\o-data-view.component.ts", lineNumber: 18 }); })();

class ODataViewModule {
    static { this.ɵfac = function ODataViewModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || ODataViewModule)(); }; }
    static { this.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: ODataViewModule }); }
    static { this.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [ODataViewComponent] }); }
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(ODataViewModule, [{
        type: NgModule,
        args: [{
                imports: [ODataViewComponent, ODataViewGridItemDirective, ODataViewTableColumnsDirective],
                exports: [ODataViewComponent, ODataViewGridItemDirective, ODataViewTableColumnsDirective]
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(ODataViewModule, { imports: [ODataViewComponent, ODataViewGridItemDirective, ODataViewTableColumnsDirective], exports: [ODataViewComponent, ODataViewGridItemDirective, ODataViewTableColumnsDirective] }); })();

const MAP = {
    // English
    'en': {
        'WIDTH': 'Width',
        'HEIGHT': 'Height',
        'DRAG_MESSAGE': 'Drag and drop here',
        'OR': 'or',
        'UPLOAD_IMAGE': 'Upload image',
        'UPLOAD': 'Upload',
        'ROTATION': 'Rotation',
        'SCALE': 'Scale',
        'CROP': 'Convert',
        'RESIZE': 'Resize',
        'RESET': 'Reset',
        'SAVE': 'Save',
        'NOT_IMAGE': 'No cropped image to save',
        'UPLOAD_NEW': 'Upload new',
        'KEEP_EDITING': 'Keep editing',
        'SAVE_CONFIRM': 'Image saved',
        'QUESTION': 'Upload a new image or keep editing?',
        'FLIP': 'Flip horizontal',
        'ROTATE_90': 'Rotate 90°',
        'HORIZONTAL': 'Horizontal',
        'VERTICAL': 'Vertical',
        'AVATAR': 'Avatar',
        'CUSTOM': 'Custom'
    },
    // Spanish
    'es': {
        'WIDTH': 'Ancho',
        'HEIGHT': 'Altura',
        'DRAG_MESSAGE': 'Arrastra y suelta aquí',
        'OR': 'o',
        'UPLOAD_IMAGE': 'Subir imagen',
        'UPLOAD': 'Subir',
        'ROTATION': 'Rotar',
        'SCALE': 'Escalar',
        'CROP': 'Convertir',
        'RESIZE': 'Aspecto',
        'RESET': 'Reestablecer',
        'SAVE': 'Guardar',
        'NOT_IMAGE': 'No hay imagen recortada para guardar',
        'UPLOAD_NEW': 'Cargar nueva',
        'KEEP_EDITING': 'Seguir editando',
        'SAVE_CONFIRM': 'Imagen guardada',
        'QUESTION': '¿Quieres seguir editando esta o subir una nueva imagen?',
        'FLIP': 'Voltear horizontal',
        'ROTATE_90': 'Rotar 90°',
        'HORIZONTAL': 'Horizontal',
        'VERTICAL': 'Vertical',
        'AVATAR': 'Avatar',
        'CUSTOM': 'Custom'
    }
};

class TranslateExtraComponentsService {
    constructor(oTranslate) {
        this.oTranslate = oTranslate;
        this.currentLang = 'en';
        this.loadedLangs = new Set();
        this.loadTranslations();
        this.oTranslate.onLanguageChanged.subscribe(() => {
            this.loadTranslations();
        });
    }
    loadTranslations() {
        const lang = this.oTranslate.getCurrentLang() || 'en';
        this.currentLang = lang;
        if (this.loadedLangs.has(lang))
            return;
        const dict = MAP[lang] ?? MAP['en'];
        if (dict) {
            this.oTranslate.getNgxTranslateService().setTranslation(lang, dict, true);
            this.loadedLangs.add(lang);
        }
    }
    get(key, values = []) {
        this.loadTranslations();
        const translated = this.oTranslate.get(key, values);
        if (translated && translated !== key)
            return translated;
        const dict = MAP[this.currentLang] ?? MAP['en'];
        return dict?.[key] ?? key;
    }
    static { this.ɵfac = function TranslateExtraComponentsService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || TranslateExtraComponentsService)(i0.ɵɵinject(i1$1.OTranslateService)); }; }
    static { this.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: TranslateExtraComponentsService, factory: TranslateExtraComponentsService.ɵfac, providedIn: 'root' }); }
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(TranslateExtraComponentsService, [{
        type: Injectable,
        args: [{
                providedIn: 'root'
            }]
    }], () => [{ type: i1$1.OTranslateService }], null); })();

const _c0 = ["fileInput"];
const _c1 = ["cropper"];
const _c2 = () => ({ "width": "120px" });
const _c3 = () => ({ standalone: true });
function OImageEditorComponent_ng_template_0_div_0_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 12)(1, "o-button", 13);
    i0.ɵɵlistener("onClick", function OImageEditorComponent_ng_template_0_div_0_Template_o_button_onClick_1_listener() { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.reset()); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(2, "o-button", 14);
    i0.ɵɵlistener("onClick", function OImageEditorComponent_ng_template_0_div_0_Template_o_button_onClick_2_listener() { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.save()); });
    i0.ɵɵelementEnd()();
} }
function OImageEditorComponent_ng_template_0_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵtemplate(0, OImageEditorComponent_ng_template_0_div_0_Template, 3, 0, "div", 11);
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("ngIf", ctx_r1.selectedFile);
} }
function OImageEditorComponent_ng_container_3_ng_container_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainer(0);
} }
function OImageEditorComponent_ng_container_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtemplate(1, OImageEditorComponent_ng_container_3_ng_container_1_Template, 1, 0, "ng-container", 15);
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    i0.ɵɵnextContext();
    const actionsTpl_r3 = i0.ɵɵreference(1);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngTemplateOutlet", actionsTpl_r3);
} }
function OImageEditorComponent_div_5_Template(rf, ctx) { if (rf & 1) {
    const _r4 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 16)(1, "mat-button-toggle-group", 17);
    i0.ɵɵlistener("change", function OImageEditorComponent_div_5_Template_mat_button_toggle_group_change_1_listener($event) { i0.ɵɵrestoreView(_r4); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.onToolChange($event.value)); });
    i0.ɵɵelementStart(2, "mat-button-toggle", 18);
    i0.ɵɵpipe(3, "oTranslate");
    i0.ɵɵelementStart(4, "div", 19)(5, "mat-icon");
    i0.ɵɵtext(6, "upload");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(7, "span");
    i0.ɵɵtext(8);
    i0.ɵɵpipe(9, "oTranslate");
    i0.ɵɵelementEnd()()();
    i0.ɵɵelementStart(10, "mat-button-toggle", 20);
    i0.ɵɵpipe(11, "oTranslate");
    i0.ɵɵelementStart(12, "div", 19)(13, "mat-icon");
    i0.ɵɵtext(14, "crop");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(15, "span");
    i0.ɵɵtext(16);
    i0.ɵɵpipe(17, "oTranslate");
    i0.ɵɵelementEnd()()();
    i0.ɵɵelementStart(18, "mat-button-toggle", 21);
    i0.ɵɵpipe(19, "oTranslate");
    i0.ɵɵelementStart(20, "div", 19)(21, "mat-icon");
    i0.ɵɵtext(22, "photo_size_select_large");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(23, "span");
    i0.ɵɵtext(24);
    i0.ɵɵpipe(25, "oTranslate");
    i0.ɵɵelementEnd()()()()();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵproperty("value", ctx_r1.toolsValue);
    i0.ɵɵadvance();
    i0.ɵɵpropertyInterpolate("matTooltip", i0.ɵɵpipeBind1(3, 7, "UPLOAD_IMAGE"));
    i0.ɵɵadvance(6);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(9, 9, "UPLOAD"));
    i0.ɵɵadvance(2);
    i0.ɵɵpropertyInterpolate("matTooltip", i0.ɵɵpipeBind1(11, 11, "CROP"));
    i0.ɵɵadvance(6);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(17, 13, "CROP"));
    i0.ɵɵadvance(2);
    i0.ɵɵpropertyInterpolate("matTooltip", i0.ɵɵpipeBind1(19, 15, "RESIZE"));
    i0.ɵɵadvance(6);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(25, 17, "RESIZE"));
} }
function OImageEditorComponent_ng_container_7_div_2_Template(rf, ctx) { if (rf & 1) {
    const _r6 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 28)(1, "o-button", 29);
    i0.ɵɵlistener("onClick", function OImageEditorComponent_ng_container_7_div_2_Template_o_button_onClick_1_listener() { i0.ɵɵrestoreView(_r6); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.flip()); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(2, "o-button", 30);
    i0.ɵɵlistener("onClick", function OImageEditorComponent_ng_container_7_div_2_Template_o_button_onClick_2_listener() { i0.ɵɵrestoreView(_r6); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.rotate()); });
    i0.ɵɵelementEnd()();
} }
function OImageEditorComponent_ng_container_7_div_3_Template(rf, ctx) { if (rf & 1) {
    const _r7 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 31)(1, "div", 32)(2, "button", 33);
    i0.ɵɵlistener("click", function OImageEditorComponent_ng_container_7_div_3_Template_button_click_2_listener() { i0.ɵɵrestoreView(_r7); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.setResizePreset("horizontal")); });
    i0.ɵɵelementStart(3, "mat-icon");
    i0.ɵɵtext(4, "crop_landscape");
    i0.ɵɵelementEnd();
    i0.ɵɵtext(5);
    i0.ɵɵpipe(6, "oTranslate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(7, "button", 33);
    i0.ɵɵlistener("click", function OImageEditorComponent_ng_container_7_div_3_Template_button_click_7_listener() { i0.ɵɵrestoreView(_r7); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.setResizePreset("vertical")); });
    i0.ɵɵelementStart(8, "mat-icon");
    i0.ɵɵtext(9, "crop_portrait");
    i0.ɵɵelementEnd();
    i0.ɵɵtext(10);
    i0.ɵɵpipe(11, "oTranslate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(12, "button", 33);
    i0.ɵɵlistener("click", function OImageEditorComponent_ng_container_7_div_3_Template_button_click_12_listener() { i0.ɵɵrestoreView(_r7); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.setResizePreset("avatar")); });
    i0.ɵɵelementStart(13, "mat-icon", 34);
    i0.ɵɵtext(14, "circle");
    i0.ɵɵelementEnd();
    i0.ɵɵtext(15);
    i0.ɵɵpipe(16, "oTranslate");
    i0.ɵɵelementEnd()()();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance(2);
    i0.ɵɵclassProp("is-active", ctx_r1.resizePreset === "horizontal");
    i0.ɵɵproperty("disabled", ctx_r1.resizeLocked);
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(6, 12, "HORIZONTAL"), " ");
    i0.ɵɵadvance(2);
    i0.ɵɵclassProp("is-active", ctx_r1.resizePreset === "vertical");
    i0.ɵɵproperty("disabled", ctx_r1.resizeLocked);
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(11, 14, "VERTICAL"), " ");
    i0.ɵɵadvance(2);
    i0.ɵɵclassProp("is-active", ctx_r1.resizePreset === "avatar");
    i0.ɵɵproperty("disabled", ctx_r1.resizeLocked);
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(16, 16, "AVATAR"), " ");
} }
function OImageEditorComponent_ng_container_7_div_6_div_2_span_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "span", 49);
} if (rf & 2) {
    const i_r9 = ctx.index;
    const ctx_r1 = i0.ɵɵnextContext(4);
    i0.ɵɵclassProp("oie-dot--big", ctx_r1.isBig(i_r9));
} }
function OImageEditorComponent_ng_container_7_div_6_div_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 48)(1, "div", 43);
    i0.ɵɵtemplate(2, OImageEditorComponent_ng_container_7_div_6_div_2_span_2_Template, 1, 2, "span", 44);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(3);
    i0.ɵɵadvance();
    i0.ɵɵstyleProp("transform", "translateX(" + ctx_r1.rotateDotsTranslatePx + "px)");
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngForOf", ctx_r1.dotsTape);
} }
function OImageEditorComponent_ng_container_7_div_6_div_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "div", 50);
} }
function OImageEditorComponent_ng_container_7_div_6_span_10_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "span", 49);
} if (rf & 2) {
    const i_r10 = ctx.index;
    const ctx_r1 = i0.ɵɵnextContext(3);
    i0.ɵɵclassProp("oie-dot--big", ctx_r1.isBig(i_r10));
} }
function OImageEditorComponent_ng_container_7_div_6_Template(rf, ctx) { if (rf & 1) {
    const _r8 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 35)(1, "div", 36);
    i0.ɵɵtemplate(2, OImageEditorComponent_ng_container_7_div_6_div_2_Template, 3, 3, "div", 37)(3, OImageEditorComponent_ng_container_7_div_6_div_3_Template, 1, 0, "div", 38);
    i0.ɵɵelementStart(4, "div", 39)(5, "span", 40);
    i0.ɵɵtext(6);
    i0.ɵɵelementEnd();
    i0.ɵɵelement(7, "span", 41);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(8, "div", 42)(9, "div", 43);
    i0.ɵɵtemplate(10, OImageEditorComponent_ng_container_7_div_6_span_10_Template, 1, 2, "span", 44);
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(11, "input", 45);
    i0.ɵɵlistener("input", function OImageEditorComponent_ng_container_7_div_6_Template_input_input_11_listener($event) { i0.ɵɵrestoreView(_r8); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.onAdjustInput($event.target.value)); });
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(12, "div", 46)(13, "button", 47);
    i0.ɵɵlistener("click", function OImageEditorComponent_ng_container_7_div_6_Template_button_click_13_listener() { i0.ɵɵrestoreView(_r8); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.cropAdjustMode = "rotation"); });
    i0.ɵɵtext(14);
    i0.ɵɵpipe(15, "oTranslate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(16, "button", 47);
    i0.ɵɵlistener("click", function OImageEditorComponent_ng_container_7_div_6_Template_button_click_16_listener() { i0.ɵɵrestoreView(_r8); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.cropAdjustMode = "scale"); });
    i0.ɵɵtext(17);
    i0.ɵɵpipe(18, "oTranslate");
    i0.ɵɵelementEnd()()();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance();
    i0.ɵɵclassProp("is-scale", ctx_r1.cropAdjustMode === "scale");
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r1.cropAdjustMode !== "scale");
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r1.cropAdjustMode === "scale");
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(ctx_r1.adjustLabel);
    i0.ɵɵadvance(3);
    i0.ɵɵstyleProp("transform", "translateX(" + (ctx_r1.cropAdjustMode === "scale" ? ctx_r1.scaleDotsTranslatePx : ctx_r1.rotateDotsTranslatePx) + "px)");
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngForOf", ctx_r1.dotsTape);
    i0.ɵɵadvance();
    i0.ɵɵclassProp("is-scale", ctx_r1.cropAdjustMode === "scale");
    i0.ɵɵproperty("min", ctx_r1.adjustMin)("max", ctx_r1.adjustMax)("step", ctx_r1.adjustStep)("value", ctx_r1.adjustValue);
    i0.ɵɵadvance(2);
    i0.ɵɵclassProp("is-active", ctx_r1.cropAdjustMode === "rotation");
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(15, 20, "ROTATION"), " ");
    i0.ɵɵadvance(2);
    i0.ɵɵclassProp("is-active", ctx_r1.cropAdjustMode === "scale");
    i0.ɵɵadvance();
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(18, 22, "SCALE"), " ");
} }
function OImageEditorComponent_ng_container_7_div_7_Template(rf, ctx) { if (rf & 1) {
    const _r11 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 19)(1, "div", 51)(2, "mat-form-field", 52)(3, "mat-label");
    i0.ɵɵtext(4);
    i0.ɵɵpipe(5, "oTranslate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(6, "input", 53);
    i0.ɵɵtwoWayListener("ngModelChange", function OImageEditorComponent_ng_container_7_div_7_Template_input_ngModelChange_6_listener($event) { i0.ɵɵrestoreView(_r11); const ctx_r1 = i0.ɵɵnextContext(2); i0.ɵɵtwoWayBindingSet(ctx_r1.resizeWidth, $event) || (ctx_r1.resizeWidth = $event); return i0.ɵɵresetView($event); });
    i0.ɵɵlistener("blur", function OImageEditorComponent_ng_container_7_div_7_Template_input_blur_6_listener() { i0.ɵɵrestoreView(_r11); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.onResizeBoxCommit("w")); })("keydown.enter", function OImageEditorComponent_ng_container_7_div_7_Template_input_keydown_enter_6_listener() { i0.ɵɵrestoreView(_r11); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.onResizeBoxCommit("w")); });
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(7, "button", 54);
    i0.ɵɵlistener("click", function OImageEditorComponent_ng_container_7_div_7_Template_button_click_7_listener() { i0.ɵɵrestoreView(_r11); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.toggleResizeLock()); });
    i0.ɵɵelementStart(8, "mat-icon");
    i0.ɵɵtext(9);
    i0.ɵɵelementEnd()();
    i0.ɵɵelementStart(10, "mat-form-field", 52)(11, "mat-label");
    i0.ɵɵtext(12);
    i0.ɵɵpipe(13, "oTranslate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(14, "input", 53);
    i0.ɵɵtwoWayListener("ngModelChange", function OImageEditorComponent_ng_container_7_div_7_Template_input_ngModelChange_14_listener($event) { i0.ɵɵrestoreView(_r11); const ctx_r1 = i0.ɵɵnextContext(2); i0.ɵɵtwoWayBindingSet(ctx_r1.resizeHeight, $event) || (ctx_r1.resizeHeight = $event); return i0.ɵɵresetView($event); });
    i0.ɵɵlistener("blur", function OImageEditorComponent_ng_container_7_div_7_Template_input_blur_14_listener() { i0.ɵɵrestoreView(_r11); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.onResizeBoxCommit("h")); })("keydown.enter", function OImageEditorComponent_ng_container_7_div_7_Template_input_keydown_enter_14_listener() { i0.ɵɵrestoreView(_r11); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.onResizeBoxCommit("h")); });
    i0.ɵɵelementEnd()()();
    i0.ɵɵelementStart(15, "div", 55)(16, "button", 33);
    i0.ɵɵlistener("click", function OImageEditorComponent_ng_container_7_div_7_Template_button_click_16_listener() { i0.ɵɵrestoreView(_r11); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.setResizeRatioPreset("custom")); });
    i0.ɵɵelementStart(17, "mat-icon");
    i0.ɵɵtext(18, "crop_free");
    i0.ɵɵelementEnd();
    i0.ɵɵtext(19);
    i0.ɵɵpipe(20, "oTranslate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(21, "button", 33);
    i0.ɵɵlistener("click", function OImageEditorComponent_ng_container_7_div_7_Template_button_click_21_listener() { i0.ɵɵrestoreView(_r11); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.setResizeRatioPreset("1:1")); });
    i0.ɵɵelementStart(22, "mat-icon");
    i0.ɵɵtext(23, "crop_square");
    i0.ɵɵelementEnd();
    i0.ɵɵtext(24, " 1:1 ");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(25, "button", 33);
    i0.ɵɵlistener("click", function OImageEditorComponent_ng_container_7_div_7_Template_button_click_25_listener() { i0.ɵɵrestoreView(_r11); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.setResizeRatioPreset("2:1")); });
    i0.ɵɵelementStart(26, "mat-icon");
    i0.ɵɵtext(27, "crop_16_9");
    i0.ɵɵelementEnd();
    i0.ɵɵtext(28, " 2:1 ");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(29, "button", 33);
    i0.ɵɵlistener("click", function OImageEditorComponent_ng_container_7_div_7_Template_button_click_29_listener() { i0.ɵɵrestoreView(_r11); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.setResizeRatioPreset("3:2")); });
    i0.ɵɵelementStart(30, "mat-icon");
    i0.ɵɵtext(31, "crop_3_2");
    i0.ɵɵelementEnd();
    i0.ɵɵtext(32, " 3:2 ");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(33, "button", 33);
    i0.ɵɵlistener("click", function OImageEditorComponent_ng_container_7_div_7_Template_button_click_33_listener() { i0.ɵɵrestoreView(_r11); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.setResizeRatioPreset("4:3")); });
    i0.ɵɵelementStart(34, "mat-icon");
    i0.ɵɵtext(35, "crop_landscape");
    i0.ɵɵelementEnd();
    i0.ɵɵtext(36, " 4:3 ");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(37, "button", 33);
    i0.ɵɵlistener("click", function OImageEditorComponent_ng_container_7_div_7_Template_button_click_37_listener() { i0.ɵɵrestoreView(_r11); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.setResizeRatioPreset("5:4")); });
    i0.ɵɵelementStart(38, "mat-icon");
    i0.ɵɵtext(39, "crop_5_4");
    i0.ɵɵelementEnd();
    i0.ɵɵtext(40, " 5:4 ");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(41, "button", 33);
    i0.ɵɵlistener("click", function OImageEditorComponent_ng_container_7_div_7_Template_button_click_41_listener() { i0.ɵɵrestoreView(_r11); const ctx_r1 = i0.ɵɵnextContext(2); return i0.ɵɵresetView(ctx_r1.setResizeRatioPreset("16:9")); });
    i0.ɵɵelementStart(42, "mat-icon");
    i0.ɵɵtext(43, "crop_16_9");
    i0.ɵɵelementEnd();
    i0.ɵɵtext(44, " 16:9 ");
    i0.ɵɵelementEnd()()();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngStyle", i0.ɵɵpureFunction0(40, _c2));
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(5, 34, "WIDTH"));
    i0.ɵɵadvance(2);
    i0.ɵɵtwoWayProperty("ngModel", ctx_r1.resizeWidth);
    i0.ɵɵproperty("ngModelOptions", i0.ɵɵpureFunction0(41, _c3))("disabled", ctx_r1.resizeLocked);
    i0.ɵɵadvance();
    i0.ɵɵattribute("aria-label", "LOCK_SIZE");
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(ctx_r1.resizeLocked ? "lock" : "lock_open");
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngStyle", i0.ɵɵpureFunction0(42, _c2));
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(13, 36, "HEIGHT"));
    i0.ɵɵadvance(2);
    i0.ɵɵtwoWayProperty("ngModel", ctx_r1.resizeHeight);
    i0.ɵɵproperty("ngModelOptions", i0.ɵɵpureFunction0(43, _c3))("disabled", ctx_r1.resizeLocked);
    i0.ɵɵadvance(2);
    i0.ɵɵclassProp("is-active", ctx_r1.resizeRatioPreset === "custom");
    i0.ɵɵproperty("disabled", ctx_r1.resizeLocked || ctx_r1.resizePreset === "avatar");
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate1(" ", i0.ɵɵpipeBind1(20, 38, "CUSTOM"), " ");
    i0.ɵɵadvance(2);
    i0.ɵɵclassProp("is-active", ctx_r1.resizeRatioPreset === "1:1");
    i0.ɵɵproperty("disabled", ctx_r1.resizeLocked || ctx_r1.resizePreset === "avatar");
    i0.ɵɵadvance(4);
    i0.ɵɵclassProp("is-active", ctx_r1.resizeRatioPreset === "2:1");
    i0.ɵɵproperty("disabled", ctx_r1.resizeLocked || ctx_r1.resizePreset === "avatar");
    i0.ɵɵadvance(4);
    i0.ɵɵclassProp("is-active", ctx_r1.resizeRatioPreset === "3:2");
    i0.ɵɵproperty("disabled", ctx_r1.resizeLocked || ctx_r1.resizePreset === "avatar");
    i0.ɵɵadvance(4);
    i0.ɵɵclassProp("is-active", ctx_r1.resizeRatioPreset === "4:3");
    i0.ɵɵproperty("disabled", ctx_r1.resizeLocked || ctx_r1.resizePreset === "avatar");
    i0.ɵɵadvance(4);
    i0.ɵɵclassProp("is-active", ctx_r1.resizeRatioPreset === "5:4");
    i0.ɵɵproperty("disabled", ctx_r1.resizeLocked || ctx_r1.resizePreset === "avatar");
    i0.ɵɵadvance(4);
    i0.ɵɵclassProp("is-active", ctx_r1.resizeRatioPreset === "16:9");
    i0.ɵɵproperty("disabled", ctx_r1.resizeLocked || ctx_r1.resizePreset === "avatar");
} }
function OImageEditorComponent_ng_container_7_Template(rf, ctx) { if (rf & 1) {
    const _r5 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵelementStart(1, "div", 22);
    i0.ɵɵtemplate(2, OImageEditorComponent_ng_container_7_div_2_Template, 3, 0, "div", 23)(3, OImageEditorComponent_ng_container_7_div_3_Template, 17, 18, "div", 24);
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "image-cropper", 25, 1);
    i0.ɵɵtwoWayListener("transformChange", function OImageEditorComponent_ng_container_7_Template_image_cropper_transformChange_4_listener($event) { i0.ɵɵrestoreView(_r5); const ctx_r1 = i0.ɵɵnextContext(); i0.ɵɵtwoWayBindingSet(ctx_r1.transform, $event) || (ctx_r1.transform = $event); return i0.ɵɵresetView($event); });
    i0.ɵɵlistener("imageCropped", function OImageEditorComponent_ng_container_7_Template_image_cropper_imageCropped_4_listener($event) { i0.ɵɵrestoreView(_r5); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.onImageCropped($event)); })("imageLoaded", function OImageEditorComponent_ng_container_7_Template_image_cropper_imageLoaded_4_listener($event) { i0.ɵɵrestoreView(_r5); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.onImageLoaded($event)); })("loadImageFailed", function OImageEditorComponent_ng_container_7_Template_image_cropper_loadImageFailed_4_listener() { i0.ɵɵrestoreView(_r5); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.onLoadImageFailed()); })("cropperReady", function OImageEditorComponent_ng_container_7_Template_image_cropper_cropperReady_4_listener($event) { i0.ɵɵrestoreView(_r5); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.onCropperReady($event)); })("cropperChange", function OImageEditorComponent_ng_container_7_Template_image_cropper_cropperChange_4_listener($event) { i0.ɵɵrestoreView(_r5); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.onCropperChange($event)); });
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(6, OImageEditorComponent_ng_container_7_div_6_Template, 19, 24, "div", 26)(7, OImageEditorComponent_ng_container_7_div_7_Template, 45, 44, "div", 27);
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", ctx_r1.activeTool === "crop" && !ctx_r1.cropperLoading);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r1.activeTool === "resize" && !ctx_r1.cropperLoading);
    i0.ɵɵadvance();
    i0.ɵɵproperty("imageFile", ctx_r1.selectedFile)("maintainAspectRatio", ctx_r1.maintainAspectRatio)("aspectRatio", ctx_r1.aspectRatio || 1)("canvasRotation", ctx_r1.canvasRotation);
    i0.ɵɵtwoWayProperty("transform", ctx_r1.transform);
    i0.ɵɵproperty("imageQuality", 95)("containWithinAspectRatio", true)("resetCropOnAspectRatioChange", true)("roundCropper", ctx_r1.roundCropper)("cropperStaticWidth", ctx_r1.cropperStaticWidth)("cropperStaticHeight", ctx_r1.cropperStaticHeight)("hideResizeSquares", ctx_r1.resizeLocked)("cropper", ctx_r1.cropperPosition)("imageBase64", ctx_r1.cropperImageBase64);
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngIf", ctx_r1.activeTool === "crop" && !ctx_r1.cropperLoading);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r1.activeTool === "resize" && !ctx_r1.cropperLoading);
} }
function OImageEditorComponent_div_8_Template(rf, ctx) { if (rf & 1) {
    const _r12 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 56);
    i0.ɵɵlistener("dragover", function OImageEditorComponent_div_8_Template_div_dragover_0_listener($event) { i0.ɵɵrestoreView(_r12); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.onDragOver($event)); })("dragleave", function OImageEditorComponent_div_8_Template_div_dragleave_0_listener($event) { i0.ɵɵrestoreView(_r12); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.onDragLeave($event)); })("drop", function OImageEditorComponent_div_8_Template_div_drop_0_listener($event) { i0.ɵɵrestoreView(_r12); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.onDrop($event)); });
    i0.ɵɵelementStart(1, "span");
    i0.ɵɵtext(2);
    i0.ɵɵpipe(3, "oTranslate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "span");
    i0.ɵɵtext(5);
    i0.ɵɵpipe(6, "oTranslate");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(7, "o-button", 57);
    i0.ɵɵlistener("onClick", function OImageEditorComponent_div_8_Template_o_button_onClick_7_listener($event) { i0.ɵɵrestoreView(_r12); const ctx_r1 = i0.ɵɵnextContext(); $event.stopPropagation(); return i0.ɵɵresetView(ctx_r1.openFilePicker()); });
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(8, "input", 58, 2);
    i0.ɵɵlistener("change", function OImageEditorComponent_div_8_Template_input_change_8_listener($event) { i0.ɵɵrestoreView(_r12); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.onFileInputChange($event)); });
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵclassProp("is-overlay", ctx_r1.uploadOverlay)("o-image-editor-load-zone--dragover", ctx_r1.dragOver);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(3, 6, "DRAG_MESSAGE"));
    i0.ɵɵadvance(3);
    i0.ɵɵtextInterpolate(i0.ɵɵpipeBind1(6, 8, "OR"));
} }
function OImageEditorComponent_div_9_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 59);
    i0.ɵɵelement(1, "mat-spinner", 60);
    i0.ɵɵelementEnd();
} }
function OImageEditorComponent_div_10_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "div", 61);
} }
function OImageEditorComponent_ng_container_11_ng_container_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainer(0);
} }
function OImageEditorComponent_ng_container_11_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementContainerStart(0);
    i0.ɵɵtemplate(1, OImageEditorComponent_ng_container_11_ng_container_1_Template, 1, 0, "ng-container", 15);
    i0.ɵɵelementContainerEnd();
} if (rf & 2) {
    i0.ɵɵnextContext();
    const actionsTpl_r3 = i0.ɵɵreference(1);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngTemplateOutlet", actionsTpl_r3);
} }
class OImageEditorComponent {
    set imageBase64(value) {
        this._imageBase64 = value ?? null;
        this.loadFromBase64(this._imageBase64);
    }
    get imageBase64() {
        return this._imageBase64;
    }
    constructor(dialogService, injector, cdr, ngZone) {
        this.dialogService = dialogService;
        this.injector = injector;
        this.cdr = cdr;
        this.ngZone = ngZone;
        this.saveTarget = 'download';
        this.actionsPosition = 'top';
        this.onSaveBase64 = new EventEmitter();
        /* ----------------------PUBLIC STATE (TEMPLATE)-----------------------*/
        this.activeTool = 'crop';
        this.uploadOverlay = false;
        this.selectedFile = null;
        this.dragOver = false;
        this.cropperLoading = false;
        this.maintainAspectRatio = false;
        this.aspectRatio = null;
        this.canvasRotation = 0;
        this.transform = { scale: 1, rotate: 0, flipH: false, flipV: false };
        this.rotationDeg = 0;
        this.cropAdjustMode = 'rotation';
        this.resizeLocked = false;
        this.resizePreset = null;
        this.resizeRatioPreset = 'custom';
        this.roundCropper = false;
        this.scalePercent = 0;
        this.minScale = 1;
        this.maxScale = 3;
        this.dotsTape = Array.from({ length: 80 });
        this.resizeWidth = null;
        this.resizeHeight = null;
        this.cropperPosition = { x1: 0, y1: 0, x2: 10_000_000, y2: 10_000_000 };
        /* ----------------------PRIVATE STATE / CONSTANTS----------------------*/
        this.lockedW = null;
        this.lockedH = null;
        this.VIEWPORT_W = 135;
        this.GAP = 4;
        this.SMALL = 4;
        this.BIG = 6;
        this.INIT_CROPPER = {
            x1: 0,
            y1: 0,
            x2: 10_000_000,
            y2: 10_000_000
        };
        this.cropperIsReady = false;
        // OJO: estas dos variables parecen “stubs” (siempre false / null). No las toco para no cambiar comportamiento.
        this.commitTarget = null;
        this.commitTry = 0;
        this.committingResize = false;
        this.maxSizeW = null;
        this.maxSizeH = null;
        this.applyingCropperFromInputs = false;
        this.hasManualResizeTarget = false;
        this.naturalWidth = null;
        this.naturalHeight = null;
        this.ALLOWED_MIMES = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
        this.translateService = this.injector.get(TranslateExtraComponentsService);
        // Garantiza INIT_CROPPER como estado inicial real (sin cambiar nada)
        this.cropperPosition = { ...this.INIT_CROPPER };
    }
    /* ----------------------GETTERS (TEMPLATE)----------------------------*/
    get cropperStaticWidth() {
        return this.resizeLocked && this.lockedW ? this.lockedW : 0;
    }
    get cropperStaticHeight() {
        return this.resizeLocked && this.lockedH ? this.lockedH : 0;
    }
    get toolsValue() {
        return this.uploadOverlay ? 'upload' : this.activeTool;
    }
    get rotateDotsTranslatePx() {
        if (this.cropAdjustMode === 'scale')
            return 0;
        const min = Number(this.adjustMin);
        const max = Number(this.adjustMax);
        const val = Number(this.adjustValue);
        if (!Number.isFinite(min) || !Number.isFinite(max) || max === min || !Number.isFinite(val))
            return 0;
        const t = (this.clamp(val, min, max) - min) / (max - min);
        const tapeW = this.tapeWidthPx(this.dotsTape.length);
        const extra = Math.max(0, tapeW - this.VIEWPORT_W);
        return (0.5 - t) * extra;
    }
    get scaleDotsTranslatePx() {
        if (this.cropAdjustMode !== 'scale')
            return 0;
        const min = Number(this.adjustMin);
        const max = Number(this.adjustMax);
        const val = Number(this.adjustValue);
        if (!Number.isFinite(min) || !Number.isFinite(max) || max === min || !Number.isFinite(val))
            return 0;
        const t = (this.clamp(val, min, max) - min) / (max - min);
        const tapeW = this.tapeWidthPx(this.dotsTape.length);
        const extra = Math.max(0, tapeW - this.VIEWPORT_W);
        return -t * extra;
    }
    get adjustMin() {
        return this.cropAdjustMode === 'rotation' ? -180 : 0;
    }
    get adjustMax() {
        return this.cropAdjustMode === 'rotation' ? 180 : 100;
    }
    get adjustStep() {
        return 1;
    }
    get adjustValue() {
        return this.cropAdjustMode === 'rotation' ? this.rotationDeg : this.scalePercent;
    }
    get adjustPercent() {
        if (this.cropAdjustMode === 'scale') {
            return 50 + (this.scalePercent / 100) * 50;
        }
        return ((this.rotationDeg + 180) / 360) * 100;
    }
    get adjustLabel() {
        return this.cropAdjustMode === 'rotation'
            ? `${this.rotationDeg}°`
            : `${this.scalePercent}%`;
    }
    /* ----------------------TOOL ACTIONS (CROP/RESIZE/TRANSFORM)----------*/
    setResizePreset(preset) {
        if (this.resizeLocked)
            return;
        this.resizePreset = preset;
        if (preset === 'avatar') {
            this.resizeRatioPreset = '1:1';
        }
        else if (!this.resizeRatioPreset) {
            this.resizeRatioPreset = '16:9';
        }
        this.applyResizeAspectFromState();
    }
    setResizeRatioPreset(preset) {
        if (this.resizeLocked)
            return;
        this.resizeRatioPreset = preset;
        if (!this.resizePreset) {
            this.resizePreset = 'horizontal';
        }
        this.applyResizeAspectFromState();
    }
    toggleResizeLock() {
        this.resizeLocked = !this.resizeLocked;
        if (this.resizeLocked) {
            const w = this.resizeWidth ?? this.lastCropped?.width ?? this.naturalWidth;
            const h = this.resizeHeight ?? this.lastCropped?.height ?? this.naturalHeight;
            this.lockedW = w ?? null;
            this.lockedH = h ?? null;
        }
        else {
            this.lockedW = null;
            this.lockedH = null;
        }
    }
    onResizeBoxCommit(changed) {
        if (this.resizeLocked)
            return;
        if (this.activeTool !== 'resize')
            return;
        const w0 = this.toPx(this.resizeWidth);
        const h0 = this.toPx(this.resizeHeight);
        if (w0 == null || h0 == null)
            return;
        let w = w0;
        let h = h0;
        const enforceRatio = this.resizePreset === 'avatar' ||
            this.resizeRatioPreset === '1:1' ||
            (this.resizeRatioPreset !== 'custom' && this.maintainAspectRatio && !!this.aspectRatio);
        if (enforceRatio && this.aspectRatio) {
            if (changed === 'w') {
                h = Math.max(1, Math.round(w / this.aspectRatio));
                this.resizeHeight = h;
            }
            else {
                w = Math.max(1, Math.round(h * this.aspectRatio));
                this.resizeWidth = w;
            }
        }
        this.hasManualResizeTarget = true;
    }
    onAdjustInput(raw) {
        const v = Number(raw);
        if (this.cropAdjustMode === 'rotation') {
            this.applyRotation(v);
        }
        else {
            this.applyScalePercent(v);
        }
    }
    rotate() {
        this.canvasRotation = (this.canvasRotation + 1) % 4;
    }
    flip() {
        this.transform = { ...this.transform, flipH: !this.transform.flipH };
    }
    setCropRatio(ratio) {
        if (ratio == null) {
            this.aspectRatio = null;
            this.maintainAspectRatio = false;
        }
        else {
            this.aspectRatio = ratio;
            this.maintainAspectRatio = true;
        }
    }
    /* ----------------------UPLOAD (INPUT/DRAG&DROP)----------------------*/
    openFilePicker() {
        this.fileInput?.nativeElement.click();
    }
    onToolChange(value) {
        if (value === 'upload') {
            this.uploadOverlay = true;
            this.dragOver = false;
            return;
        }
        this.uploadOverlay = false;
        this.activeTool = value;
        if (value === 'resize') {
            this.syncResizeInputsFromCurrent();
        }
        this.refreshCropperLayout();
    }
    onFileInputChange(event) {
        const input = event.target;
        const file = input.files?.[0] ?? null;
        input.value = '';
        if (!file)
            return;
        const ok = this.loadFile(file);
        if (ok) {
            this.uploadOverlay = false;
            this.activeTool = 'crop';
        }
    }
    onDragOver(ev) {
        ev.preventDefault();
        this.dragOver = true;
    }
    onDragLeave(ev) {
        ev.preventDefault();
        this.dragOver = false;
    }
    onDrop(ev) {
        ev.preventDefault();
        this.dragOver = false;
        const file = ev.dataTransfer?.files?.[0] ?? null;
        if (!file)
            return;
        const ok = this.loadFile(file);
        if (ok) {
            this.uploadOverlay = false;
            this.activeTool = 'crop';
        }
    }
    loadFile(file) {
        if (!file.type?.startsWith('image/'))
            return false;
        if (!this.ALLOWED_MIMES.includes(file.type))
            return false;
        this.resetEditorState();
        this.selectedFile = file;
        this.cropperLoading = true;
        return true;
    }
    loadFromBase64(base64) {
        // Reset “suave” para forzar recarga del cropper cuando cambie la imagen
        this.cropperImageBase64 = undefined;
        if (!base64) {
            // si quieres volver a la zona de carga cuando no haya imagen:
            this.selectedFile = null;
            return;
        }
        // Si al setear base64 quieres “pisar” cualquier imagen previa (upload):
        this.selectedFile = this.selectedFile ?? {}; // o pon tu flag hasImage=true
        // En el siguiente tick para que el cropper detecte el cambio siempre
        queueMicrotask(() => {
            this.cropperImageBase64 = base64;
        });
    }
    /* ----------------------CROPPER EVENTS (NGX-IMAGE-CROPPER)------------*/
    onCropperReady(dim) {
        this.cropperIsReady = true;
        this.maxSizeW = typeof dim?.width === 'number' ? dim.width : null;
        this.maxSizeH = typeof dim?.height === 'number' ? dim.height : null;
    }
    onCropperChange(pos) {
        if (this.applyingCropperFromInputs)
            return;
        this.cropperPosition = pos;
        if (this.activeTool === 'resize' && !this.resizeLocked) {
            this.resizeWidth = Math.round(pos.x2 - pos.x1);
            this.resizeHeight = Math.round(pos.y2 - pos.y1);
        }
    }
    onImageCropped(e) {
        this.lastCropped = e;
        const hasSize = typeof e.width === 'number' && typeof e.height === 'number';
        if (!hasSize) {
            return;
        }
        if (this.committingResize && this.commitTarget) {
            const tw = this.commitTarget.w;
            const th = this.commitTarget.h;
            const dw = tw - e.width;
            const dh = th - e.height;
            if (dw === 0 && dh === 0) {
                this.committingResize = false;
                this.resizeWidth = tw;
                this.resizeHeight = th;
                return;
            }
            if (this.commitTry >= 2) {
                this.committingResize = false;
                this.resizeWidth = e.width;
                this.resizeHeight = e.height;
                return;
            }
            if (!this.getScreenToOutputRatios()) {
                this.committingResize = false;
                return;
            }
            this.commitTry++;
            this.applyCropperForOutput(Math.max(1, tw), Math.max(1, th));
            return;
        }
        if (!this.resizeLocked && this.activeTool === 'resize' && !this.hasManualResizeTarget) {
            this.resizeWidth = e.width;
            this.resizeHeight = e.height;
            this.syncResizeInputsFromCurrent();
        }
    }
    onImageLoaded(img) {
        this.cropperLoading = false;
        this.loadedImg = img;
        const w = img?.original?.size?.width ?? img?.width;
        const h = img?.original?.size?.height ?? img?.height;
        if (typeof w === 'number' && typeof h === 'number') {
            this.naturalWidth = w;
            this.naturalHeight = h;
        }
        this.syncResizeInputsFromCurrent();
        this.refreshCropperLayout();
    }
    onLoadImageFailed() {
        this.cropperLoading = false;
        console.error('[o-image-editor] loadImageFailed');
    }
    /* ----------------------SAVE METHODS----------------------------------*/
    async save() {
        const blob = await this.getFinalBlob();
        if (!blob) {
            this.dialogService.warn('SAVE', 'NOT_IMAGE');
            return;
        }
        if (this.saveTarget === 'base64') {
            await this.emitBase64(blob);
            return;
        }
        await this.persistAndConfirm(blob);
    }
    async persistAndConfirm(blob) {
        const suggestedName = this.buildSuggestedFileName(blob.type || 'image/png');
        const saved = await this.persistBlobToDisk(blob, suggestedName);
        if (!saved)
            return;
        this.askLoadNewOrContinue();
    }
    async emitBase64(blob) {
        const dataUrl = await this.blobToDataUrl(blob);
        this.onSaveBase64.emit(dataUrl);
    }
    getCroppedBlob() {
        const fromBlob = this.lastCropped?.blob;
        if (fromBlob instanceof Blob)
            return fromBlob;
        const b64 = this.lastCropped?.base64;
        if (typeof b64 === 'string' && b64.length) {
            return base64ToFile(b64);
        }
        return null;
    }
    async getFinalBlob() {
        let base = this.getCroppedBlob();
        if (!base)
            return null;
        if (this.hasManualResizeTarget && this.resizeWidth && this.resizeHeight) {
            base = await this.resizeBlobToExact(base, this.resizeWidth, this.resizeHeight);
        }
        if (!this.roundCropper)
            return base;
        try {
            return await this.makeCircularPng(base);
        }
        catch (e) {
            console.error('[o-image-editor] makeCircularPng failed', e);
            return base;
        }
    }
    async makeCircularPng(src) {
        const img = await this.blobToHtmlImage(src);
        const w = img.naturalWidth || img.width;
        const h = img.naturalHeight || img.height;
        const size = Math.min(w, h);
        const sx = Math.max(0, (w - size) / 2);
        const sy = Math.max(0, (h - size) / 2);
        const canvas = document.createElement('canvas');
        canvas.width = size;
        canvas.height = size;
        const ctx = canvas.getContext('2d');
        if (!ctx)
            throw new Error('Canvas 2D context not available');
        ctx.clearRect(0, 0, size, size);
        ctx.save();
        ctx.beginPath();
        ctx.arc(size / 2, size / 2, size / 2, 0, Math.PI * 2);
        ctx.closePath();
        ctx.clip();
        ctx.drawImage(img, sx, sy, size, size, 0, 0, size, size);
        ctx.restore();
        return await new Promise((resolve, reject) => {
            canvas.toBlob((b) => (b ? resolve(b) : reject(new Error('canvas.toBlob returned null'))), 'image/png', 0.95);
        });
    }
    buildSuggestedFileName(mime) {
        let ext = 'png';
        if (mime.includes('jpeg')) {
            ext = 'jpg';
        }
        else if (mime.includes('webp')) {
            ext = 'webp';
        }
        return `image_edited.${ext}`;
    }
    async persistBlobToDisk(blob, suggestedName) {
        const g = globalThis;
        if (typeof g.showSaveFilePicker === 'function') {
            try {
                const handle = await g.showSaveFilePicker({
                    suggestedName,
                    types: [
                        { description: 'PNG image', accept: { 'image/png': ['.png'] } },
                        { description: 'JPEG image', accept: { 'image/jpeg': ['.jpg', '.jpeg'] } },
                        { description: 'WebP image', accept: { 'image/webp': ['.webp'] } }
                    ]
                });
                const targetMime = this.mimeFromFilename(handle?.name) ?? (blob.type || 'image/png');
                const finalBlob = await this.convertBlobToMime(blob, targetMime, {
                    background: (this.roundCropper && targetMime === 'image/jpeg') ? '#ffffff' : null
                });
                const writable = await handle.createWritable();
                await writable.write(finalBlob);
                await writable.close();
                return true;
            }
            catch (e) {
                if (e?.name === 'AbortError')
                    return false;
                const action = this.getText('SAVE');
                const message = this.getText('NOT_IMAGE');
                this.dialogService.error(action, message);
                return false;
            }
        }
        this.downloadBlob(blob, suggestedName);
        return true;
    }
    askLoadNewOrContinue() {
        const actionNew = this.getText('UPLOAD_NEW');
        const actionEdit = this.getText('KEEP_EDITING');
        const saveMessage = this.getText('SAVE_CONFIRM');
        const question = this.getText('QUESTION');
        const config = {
            icon: 'save',
            okButtonText: actionNew,
            cancelButtonText: actionEdit
        };
        this.dialogService.confirm(saveMessage, question, config);
        this.dialogService.dialogRef.afterClosed().pipe(take(1)).subscribe((loadNew) => {
            if (loadNew) {
                this.resetEditorState();
                this.selectedFile = null;
            }
        });
    }
    /* ----------------------RESET METHODS---------------------------------*/
    reset() {
        this.resetEditsState();
        this.cdr.detectChanges();
        this.ngZone.onStable.pipe(take(1)).subscribe(() => {
            this.cropperComp?.resetCropperPosition();
        });
    }
    resetEditorState() {
        this.lastCropped = undefined;
        this.canvasRotation = 0;
        this.transform = { scale: 1, rotate: 0, flipH: false, flipV: false };
        this.aspectRatio = null;
        this.maintainAspectRatio = false;
        this.rotationDeg = 0;
        this.scalePercent = 0;
        this.resizeWidth = null;
        this.resizeHeight = null;
        this.naturalWidth = null;
        this.naturalHeight = null;
        this.roundCropper = false;
        this.resizePreset = null;
        this.resizeLocked = false;
        this.lockedW = null;
        this.lockedH = null;
        this.resizeRatioPreset = 'custom';
        this.cropperPosition = { ...this.INIT_CROPPER };
        this.cropperIsReady = false;
        this.hasManualResizeTarget = false;
    }
    resetEditsState() {
        this.lastCropped = undefined;
        this.canvasRotation = 0;
        this.transform = { scale: 1, rotate: 0, flipH: false, flipV: false };
        this.rotationDeg = 0;
        this.scalePercent = 0;
        this.resizeLocked = false;
        this.lockedW = null;
        this.lockedH = null;
        this.resizePreset = null;
        this.resizeRatioPreset = 'custom';
        this.roundCropper = false;
        this.applyResizeAspectFromState();
        if (this.naturalWidth && this.naturalHeight) {
            this.resizeWidth = this.naturalWidth;
            this.resizeHeight = this.naturalHeight;
        }
        else {
            this.resizeWidth = null;
            this.resizeHeight = null;
        }
        this.cropperPosition = { ...this.INIT_CROPPER };
        this.cropperIsReady = false;
        this.hasManualResizeTarget = false;
    }
    /* ----------------------LAYOUT / CD HELPERS---------------------------*/
    refreshCropperLayout() {
        this.cdr.detectChanges();
        this.ngZone.onStable.pipe(take(1)).subscribe(() => {
            this.cropperComp?.onResize();
            globalThis.dispatchEvent(new Event('resize'));
        });
    }
    /* ----------------------CROPPER / RESIZE INTERNAL HELPERS-------------*/
    syncResizeInputsFromCurrent() {
        if (this.resizeLocked)
            return;
        if (this.hasManualResizeTarget)
            return;
        const w = this.lastCropped?.width ?? this.naturalWidth;
        const h = this.lastCropped?.height ?? this.naturalHeight;
        if (!w || !h)
            return;
        this.resizeWidth ??= w;
        this.resizeHeight ??= h;
    }
    getScreenToOutputRatios() {
        const maxW = this.maxSizeW;
        const maxH = this.maxSizeH;
        const tW = this.loadedImg?.transformed?.size?.width ?? this.naturalWidth;
        const tH = this.loadedImg?.transformed?.size?.height ?? this.naturalHeight;
        if (!maxW || !maxH || !tW || !tH)
            return null;
        return { rx: tW / maxW, ry: tH / maxH };
    }
    applyCropperForOutput(targetOutW, targetOutH) {
        if (!this.cropperIsReady)
            return;
        const ratios = this.getScreenToOutputRatios();
        if (!ratios)
            return;
        const { rx, ry } = ratios;
        const desiredScreenW = Math.max(1, Math.round(targetOutW / rx));
        const desiredScreenH = Math.max(1, Math.round(targetOutH / ry));
        const cur = this.cropperPosition;
        const imgW = this.maxSizeW;
        const imgH = this.maxSizeH;
        const isInit = cur.x2 > 1_000_000 || cur.y2 > 1_000_000;
        const cx = isInit ? imgW / 2 : (cur.x1 + cur.x2) / 2;
        const cy = isInit ? imgH / 2 : (cur.y1 + cur.y2) / 2;
        const w = Math.min(desiredScreenW, imgW);
        const h = Math.min(desiredScreenH, imgH);
        let x1 = cx - w / 2;
        let y1 = cy - h / 2;
        x1 = Math.max(0, Math.min(x1, imgW - w));
        y1 = Math.max(0, Math.min(y1, imgH - h));
        const x1i = Math.round(x1);
        const y1i = Math.round(y1);
        this.cropperPosition = {
            x1: x1i,
            y1: y1i,
            x2: x1i + w,
            y2: y1i + h
        };
        this.refreshCropperLayout();
    }
    /* ----------------------IMAGE/FILE HELPERS----------------------------*/
    async resizeBlobToExact(src, targetW, targetH, opts) {
        const img = await this.blobToHtmlImage(src);
        const srcW = img.naturalWidth || img.width;
        const srcH = img.naturalHeight || img.height;
        let w = Math.max(1, Math.round(targetW));
        let h = Math.max(1, Math.round(targetH));
        if (opts?.onlyScaleDown) {
            w = Math.min(w, srcW);
            h = Math.min(h, srcH);
        }
        const canvas = document.createElement('canvas');
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        if (!ctx)
            throw new Error('Canvas 2D context not available');
        ctx.clearRect(0, 0, w, h);
        ctx.drawImage(img, 0, 0, w, h);
        const mime = src.type || 'image/png';
        const quality = (mime === 'image/jpeg' || mime === 'image/webp') ? 0.95 : undefined;
        return await new Promise((resolve, reject) => {
            canvas.toBlob(b => (b ? resolve(b) : reject(new Error('canvas.toBlob returned null'))), mime, quality);
        });
    }
    mimeFromFilename(name) {
        if (!name)
            return null;
        const ext = name.split('.').pop()?.toLowerCase();
        switch (ext) {
            case 'png': return 'image/png';
            case 'jpg':
            case 'jpeg': return 'image/jpeg';
            case 'webp': return 'image/webp';
            default: return null;
        }
    }
    blobToDataUrl(blob) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onerror = () => reject(reader.error);
            reader.onload = () => {
                const result = reader.result;
                if (typeof result === 'string') {
                    resolve(result);
                }
                else {
                    reject(new Error('Failed to convert blob to data URL'));
                }
            };
            reader.readAsDataURL(blob);
        });
    }
    blobToHtmlImage(blob) {
        return new Promise((resolve, reject) => {
            const url = URL.createObjectURL(blob);
            const img = new Image();
            img.onload = () => {
                URL.revokeObjectURL(url);
                resolve(img);
            };
            img.onerror = (err) => {
                URL.revokeObjectURL(url);
                const error = err instanceof Error ? err : new Error('Failed to load image from Blob');
                reject(error);
            };
            img.src = url;
        });
    }
    async convertBlobToMime(src, targetMime, opts) {
        const normalized = targetMime === 'image/jpg' ? 'image/jpeg' : targetMime;
        if ((src.type || '') === normalized)
            return src;
        const img = await this.blobToHtmlImage(src);
        const w = img.naturalWidth || img.width;
        const h = img.naturalHeight || img.height;
        const canvas = document.createElement('canvas');
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        if (!ctx)
            throw new Error('Canvas 2D context not available');
        if (opts?.background) {
            ctx.fillStyle = opts.background;
            ctx.fillRect(0, 0, w, h);
        }
        else {
            ctx.clearRect(0, 0, w, h);
        }
        ctx.drawImage(img, 0, 0, w, h);
        const quality = (normalized === 'image/jpeg' || normalized === 'image/webp') ? 0.95 : undefined;
        return await new Promise((resolve, reject) => {
            canvas.toBlob(b => (b ? resolve(b) : reject(new Error('canvas.toBlob returned null'))), normalized, quality);
        });
    }
    downloadBlob(blob, filename) {
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        a.click();
        URL.revokeObjectURL(url);
    }
    /* ----------------------MATH / UI HELPERS-----------------------------*/
    isBig(i) {
        return (i + 1) % 5 === 0;
    }
    dotWidth(i) {
        return this.isBig(i) ? this.BIG : this.SMALL;
    }
    tapeWidthPx(count) {
        let w = 0;
        for (let i = 0; i < count; i++)
            w += this.dotWidth(i);
        w += (count - 1) * this.GAP;
        return w;
    }
    clamp(v, min, max) {
        return Math.max(min, Math.min(max, v));
    }
    toPx(v) {
        const n = Number(v);
        if (!Number.isFinite(n))
            return null;
        const r = Math.round(n);
        return r > 0 ? r : null;
    }
    /* ----------------------INTERNAL STATE HELPERS------------------------*/
    getBaseRatio(preset) {
        switch (preset) {
            case '1:1': return 1;
            case '2:1': return 2;
            case '3:2': return 3 / 2;
            case '4:3': return 4 / 3;
            case '5:4': return 5 / 4;
            case '16:9': return 16 / 9;
        }
    }
    applyResizeAspectFromState() {
        if (this.resizePreset == null || this.resizeRatioPreset == null) {
            this.roundCropper = false;
            this.setCropRatio(null);
            return;
        }
        if (this.resizePreset === 'avatar') {
            this.roundCropper = true;
            this.setCropRatio(1);
            return;
        }
        this.roundCropper = false;
        if (this.resizeRatioPreset === 'custom') {
            this.setCropRatio(null);
            return;
        }
        const base = this.getBaseRatio(this.resizeRatioPreset);
        if (base == null)
            return;
        const ratio = this.resizePreset === 'vertical' ? (1 / base) : base;
        this.setCropRatio(ratio);
    }
    normalizeDeg(v) {
        while (v > 180)
            v -= 360;
        while (v < -180)
            v += 360;
        return v;
    }
    applyRotation(deg) {
        this.canvasRotation = 0;
        this.rotationDeg = this.normalizeDeg(deg);
        this.transform = { ...this.transform, rotate: this.rotationDeg };
    }
    applyScalePercent(p) {
        const pct = Math.min(100, Math.max(0, Math.round(p)));
        this.scalePercent = pct;
        const scale = this.minScale + (this.maxScale - this.minScale) * (pct / 100);
        this.transform = { ...this.transform, scale: Number(scale.toFixed(3)) };
    }
    /* ----------------------I18N------------------------------------------*/
    getText(key) {
        return this.translateService?.get(key) ?? key;
    }
    static { this.ɵfac = function OImageEditorComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || OImageEditorComponent)(i0.ɵɵdirectiveInject(i1$1.DialogService), i0.ɵɵdirectiveInject(i0.Injector), i0.ɵɵdirectiveInject(i0.ChangeDetectorRef), i0.ɵɵdirectiveInject(i0.NgZone)); }; }
    static { this.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: OImageEditorComponent, selectors: [["o-image-editor"]], viewQuery: function OImageEditorComponent_Query(rf, ctx) { if (rf & 1) {
            i0.ɵɵviewQuery(_c0, 5);
            i0.ɵɵviewQuery(_c1, 5);
        } if (rf & 2) {
            let _t;
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.fileInput = _t.first);
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.cropperComp = _t.first);
        } }, inputs: { imageBase64: [0, "image", "imageBase64"], saveTarget: [0, "save-target", "saveTarget"], actionsPosition: [0, "actions-position", "actionsPosition"] }, outputs: { onSaveBase64: "onSaveBase64" }, standalone: true, features: [i0.ɵɵStandaloneFeature], decls: 12, vars: 7, consts: [["actionsTpl", ""], ["cropper", ""], ["fileInput", ""], ["fxLayout", "column", "fxFlexFill", "", 1, "o-image-editor", "bg-level-1"], [4, "ngIf"], ["fxLayout", "row", "fxFlex", "1 1 auto", "fxLayoutAlign", "space-between", 1, "o-image-editor-content"], ["class", "tools", "fxLayout", "column", "fxLayoutAlign", "center center", 4, "ngIf"], ["fxLayout", "column", "fxFlex", "1 1 auto", "fxLayoutGap", "6px", 1, "o-image-editor-body"], ["class", "o-image-editor-load-zone", "fxLayout", "column", "fxLayoutAlign", "center center", "fxLayoutGap", "32px", "fxFlex", "100", 3, "is-overlay", "o-image-editor-load-zone--dragover", "dragover", "dragleave", "drop", 4, "ngIf"], ["fxLayout", "column", "fxLayoutAlign", "center center", "fxFlex", "100", 4, "ngIf"], ["fxLayout", "column", "fxFlex", "82px", 4, "ngIf"], ["fxLayout", "row", "fxFlex", "32px", "fxLayoutGap", "16px", "fxLayoutAlign", "end end", 4, "ngIf"], ["fxLayout", "row", "fxFlex", "32px", "fxLayoutGap", "16px", "fxLayoutAlign", "end end"], ["attr", "reset", "type", "STROKED", "icon", "undo", "label", "RESET", 3, "onClick"], ["attr", "save", "type", "STROKED", "color", "primary", "icon", "save", "label", "SAVE", 3, "onClick"], [4, "ngTemplateOutlet"], ["fxLayout", "column", "fxLayoutAlign", "center center", 1, "tools"], ["fxLayout", "column", "fxLayoutAlign", "center center", "fxLayoutGap", "8px", 1, "tools-toggle", 3, "change", "value"], ["value", "upload", 3, "matTooltip"], ["fxLayout", "column", "fxLayoutAlign", "center center"], ["value", "crop", 3, "matTooltip"], ["value", "resize", 3, "matTooltip"], ["fxLayout", "row", "fxLayoutAlign", "center center"], ["fxLayout", "row", "fxLayoutGap", "6px", "fxLayoutAlign", "center", 4, "ngIf"], ["fxLayout", "row", "fxLayoutGap", "16px", "fxLayoutAlign", "center", 4, "ngIf"], ["format", "jpeg", 3, "transformChange", "imageCropped", "imageLoaded", "loadImageFailed", "cropperReady", "cropperChange", "imageFile", "maintainAspectRatio", "aspectRatio", "canvasRotation", "transform", "imageQuality", "containWithinAspectRatio", "resetCropOnAspectRatioChange", "roundCropper", "cropperStaticWidth", "cropperStaticHeight", "hideResizeSquares", "cropper", "imageBase64"], ["class", "oie-adjust-bar", 4, "ngIf"], ["fxLayout", "column", "fxLayoutAlign", "center center", 4, "ngIf"], ["fxLayout", "row", "fxLayoutGap", "6px", "fxLayoutAlign", "center"], ["attr", "flip", "type", "BASIC", "icon", "flip", "label", "FLIP", 3, "onClick"], ["attr", "rotate", "type", "BASIC", "icon", "rotate_90_degrees_cw", "label", "ROTATE_90", 3, "onClick"], ["fxLayout", "row", "fxLayoutGap", "16px", "fxLayoutAlign", "center"], [1, "oie-selector", "ratio"], ["mat-button", "", "type", "button", 3, "click", "disabled"], [1, "material-symbols-outlined"], [1, "oie-adjust-bar"], ["fxLayout", "row", "fxLayoutAlign", "center center", 1, "oie-dot-track"], ["fxLayout", "row", "fxFlex", "135px", "class", "oie-dots oie-dots--left", 4, "ngIf"], ["fxFlex", "135px", 4, "ngIf"], ["fxLayout", "column", "fxFlex", "55px", "aria-hidden", "true", 1, "oie-center"], [1, "oie-dot-value"], [1, "oie-dot-indicator"], ["fxLayout", "row", "fxFlex", "135px", 1, "oie-dots", "oie-dots--right"], [1, "oie-dots-track"], ["class", "oie-dot", 3, "oie-dot--big", 4, "ngFor", "ngForOf"], ["type", "range", 1, "oie-dot-input", 3, "input", "min", "max", "step", "value"], [1, "oie-selector"], ["mat-button", "", "type", "button", 3, "click"], ["fxLayout", "row", "fxFlex", "135px", 1, "oie-dots", "oie-dots--left"], [1, "oie-dot"], ["fxFlex", "135px"], ["fxLayout", "row", "fxLayoutGap", "6px", "fxLayoutAlign", "center baseline"], [3, "ngStyle"], ["matInput", "", "type", "number", "min", "1", 3, "ngModelChange", "blur", "keydown.enter", "ngModel", "ngModelOptions", "disabled"], ["mat-icon-button", "", "type", "button", 3, "click"], ["fxLayout", "row", "fxLayoutGap", "24px", "fxLayoutAlign", "center", 1, "oie-selector", "ratio"], ["fxLayout", "column", "fxLayoutAlign", "center center", "fxLayoutGap", "32px", "fxFlex", "100", 1, "o-image-editor-load-zone", 3, "dragover", "dragleave", "drop"], ["attr", "select_image", "type", "RAISED", "icon", "upload", "label", "UPLOAD_IMAGE", 3, "onClick"], ["type", "file", "hidden", "", "accept", "image/jpeg,image/jpg,image/png,image/gif", 3, "change"], ["fxLayout", "column", "fxLayoutAlign", "center center", "fxFlex", "100"], ["diameter", "60"], ["fxLayout", "column", "fxFlex", "82px"]], template: function OImageEditorComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵtemplate(0, OImageEditorComponent_ng_template_0_Template, 1, 1, "ng-template", null, 0, i0.ɵɵtemplateRefExtractor);
            i0.ɵɵelementStart(2, "div", 3);
            i0.ɵɵtemplate(3, OImageEditorComponent_ng_container_3_Template, 2, 1, "ng-container", 4);
            i0.ɵɵelementStart(4, "div", 5);
            i0.ɵɵtemplate(5, OImageEditorComponent_div_5_Template, 26, 19, "div", 6);
            i0.ɵɵelementStart(6, "div", 7);
            i0.ɵɵtemplate(7, OImageEditorComponent_ng_container_7_Template, 8, 18, "ng-container", 4)(8, OImageEditorComponent_div_8_Template, 10, 10, "div", 8)(9, OImageEditorComponent_div_9_Template, 2, 0, "div", 9);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(10, OImageEditorComponent_div_10_Template, 1, 0, "div", 10);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(11, OImageEditorComponent_ng_container_11_Template, 2, 1, "ng-container", 4);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("ngIf", ctx.selectedFile && ctx.actionsPosition === "top");
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", ctx.selectedFile);
            i0.ɵɵadvance(2);
            i0.ɵɵproperty("ngIf", ctx.selectedFile);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", !ctx.selectedFile || ctx.uploadOverlay);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.cropperLoading);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.selectedFile);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.selectedFile && ctx.actionsPosition === "bottom");
        } }, dependencies: [CommonModule, i2.NgForOf, i2.NgIf, i2.NgTemplateOutlet, i2.NgStyle, ImageCropperComponent, OntimizeWebModule, i3.DefaultValueAccessor, i3.NumberValueAccessor, i3.NgControlStatus, i3.MinValidator, i3.NgModel, i1$1.OTranslatePipe, i4.MatButton, i4.MatIconButton, i5.MatButtonToggleGroup, i5.MatButtonToggle, i6.MatIcon, i7.MatInput, i8.MatFormField, i8.MatLabel, i9.MatProgressSpinner, i10.MatTooltip, i1$1.OButtonComponent], styles: ["@import\"https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined\";.o-image-editor{padding:32px;overflow:hidden}.o-image-editor-content{min-height:0;overflow:hidden}.o-image-editor-body{min-height:0;overflow:hidden;position:relative;justify-content:space-between}.o-image-editor-load-zone.is-overlay{position:absolute;inset:0;z-index:10;background:#ffffffbf;backdrop-filter:blur(2px);-webkit-backdrop-filter:blur(2px)}.oie-adjust-bar{display:flex;flex-direction:column;align-items:center;gap:10px;padding:10px 0 0 10px}.oie-dot-track{position:relative;width:328px;height:22px;overflow:visible}.oie-dots{height:100%;overflow:hidden;display:flex;align-items:center}.oie-dots-track{display:flex;align-items:center;gap:4px;will-change:transform}.oie-dots--left .oie-dots-track{flex-direction:row-reverse}.oie-dot{width:4px;height:4px;border-radius:50%;background:#00000029;flex:0 0 auto}.oie-dot--big{width:6px;height:6px;background:#0000007a}.oie-center{position:relative;height:100%;pointer-events:none;z-index:3}.oie-dot-value{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);font-size:14px;line-height:14px;white-space:nowrap;color:#000000a6}.oie-dot-indicator{position:absolute;left:50%;top:calc(50% - 8px);transform:translate(-50%,-100%);width:2px;height:10px;border-radius:2px;background:#0000007a}.oie-dot-input{position:absolute;inset:0;opacity:0;cursor:pointer;z-index:4}.oie-dot-input.is-scale{left:135px;width:193px;right:auto}.oie-selector{display:inline-flex;gap:16px}.oie-selector button.mat-button,.oie-selector button.mat-mdc-button{min-width:auto;width:80px;border-radius:4px;background:transparent;border:1px solid transparent;box-shadow:none}.oie-selector.ratio button.mat-button,.oie-selector.ratio button.mat-mdc-button{width:auto}.oie-selector button.is-active{background:#00000014;border-color:#00000029}.oie-selector button.mat-button[disabled],.oie-selector button.mat-mdc-button[disabled]{opacity:.45}.tools-toggle{border:0}.tools-toggle .mat-button-toggle{width:72px;height:64px;border-radius:4px;border:1px solid rgba(0,0,0,.16)}.tools-toggle .mat-button-toggle mat-icon{padding-top:10px}.tools-toggle .mat-button-toggle span{line-height:20px;padding-bottom:10px;font-size:13px}.tools-toggle.mat-button-toggle-group-appearance-standard .mat-button-toggle-appearance-standard .mat-button-toggle-label-content{padding:0}.tools-toggle .mat-button-toggle.mat-button-toggle-checked{background:var(--o-primary-500);color:var(--o-primary-contrast-500);border-color:transparent}\n"], encapsulation: 2 }); }
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(OImageEditorComponent, [{
        type: Component,
        args: [{ selector: 'o-image-editor', standalone: true, imports: [CommonModule, ImageCropperComponent, OntimizeWebModule], encapsulation: ViewEncapsulation.None, template: "<ng-template #actionsTpl>\r\n  <div *ngIf=\"selectedFile\" fxLayout=\"row\" fxFlex=\"32px\" fxLayoutGap=\"16px\" fxLayoutAlign=\"end end\">\r\n    <o-button attr=\"reset\" type=\"STROKED\" icon=\"undo\" label=\"RESET\" (onClick)=\"reset()\">\r\n    </o-button>\r\n    <o-button attr=\"save\" type=\"STROKED\" color=\"primary\" icon=\"save\" label=\"SAVE\" (onClick)=\"save()\">\r\n    </o-button>\r\n  </div>\r\n</ng-template>\r\n\r\n<div class=\"o-image-editor bg-level-1\" fxLayout=\"column\" fxFlexFill>\r\n\r\n  <ng-container *ngIf=\"selectedFile && actionsPosition === 'top'\">\r\n    <ng-container *ngTemplateOutlet=\"actionsTpl\"></ng-container>\r\n  </ng-container>\r\n\r\n  <div class=\"o-image-editor-content\" fxLayout=\"row\" fxFlex=\"1 1 auto\" fxLayoutAlign=\"space-between\">\r\n\r\n    <div *ngIf=\"selectedFile\" class=\"tools\" fxLayout=\"column\" fxLayoutAlign=\"center center\">\r\n      <mat-button-toggle-group class=\"tools-toggle\" fxLayout=\"column\" fxLayoutAlign=\"center center\" fxLayoutGap=\"8px\" [value]=\"toolsValue\"\r\n        (change)=\"onToolChange($event.value)\">\r\n\r\n        <mat-button-toggle value=\"upload\" matTooltip=\"{{ 'UPLOAD_IMAGE' | oTranslate }}\">\r\n          <div fxLayout=\"column\" fxLayoutAlign=\"center center\">\r\n            <mat-icon>upload</mat-icon>\r\n            <span>{{ 'UPLOAD' | oTranslate }}</span>\r\n          </div>\r\n        </mat-button-toggle>\r\n\r\n        <mat-button-toggle value=\"crop\" matTooltip=\"{{ 'CROP' | oTranslate }}\">\r\n          <div fxLayout=\"column\" fxLayoutAlign=\"center center\">\r\n            <mat-icon>crop</mat-icon>\r\n            <span>{{ 'CROP' | oTranslate }}</span>\r\n          </div>\r\n        </mat-button-toggle>\r\n\r\n        <mat-button-toggle value=\"resize\" matTooltip=\"{{ 'RESIZE' | oTranslate }}\">\r\n          <div fxLayout=\"column\" fxLayoutAlign=\"center center\">\r\n            <mat-icon>photo_size_select_large</mat-icon>\r\n            <span>{{ 'RESIZE' | oTranslate }}</span>\r\n          </div>\r\n        </mat-button-toggle>\r\n\r\n      </mat-button-toggle-group>\r\n    </div>\r\n\r\n    <div class=\"o-image-editor-body\" fxLayout=\"column\" fxFlex=\"1 1 auto\" fxLayoutGap=\"6px\">\r\n      <ng-container *ngIf=\"selectedFile\">\r\n\r\n        <div fxLayout=\"row\" fxLayoutAlign=\"center center\">\r\n          <div *ngIf=\"activeTool === 'crop' && !cropperLoading\" fxLayout=\"row\" fxLayoutGap=\"6px\" fxLayoutAlign=\"center\">\r\n            <o-button attr=\"flip\" type=\"BASIC\" icon=\"flip\" label=\"FLIP\" (onClick)=\"flip()\"></o-button>\r\n            <o-button attr=\"rotate\" type=\"BASIC\" icon=\"rotate_90_degrees_cw\" label=\"ROTATE_90\" (onClick)=\"rotate()\"></o-button>\r\n          </div>\r\n\r\n          <div *ngIf=\"activeTool === 'resize' && !cropperLoading\" fxLayout=\"row\" fxLayoutGap=\"16px\" fxLayoutAlign=\"center\">\r\n            <div class=\"oie-selector ratio\">\r\n              <button mat-button type=\"button\" [disabled]=\"resizeLocked\" [class.is-active]=\"resizePreset === 'horizontal'\"\r\n                (click)=\"setResizePreset('horizontal')\">\r\n                <mat-icon>crop_landscape</mat-icon>\r\n                {{ \"HORIZONTAL\" | oTranslate }}\r\n              </button>\r\n\r\n              <button mat-button type=\"button\" [disabled]=\"resizeLocked\" [class.is-active]=\"resizePreset === 'vertical'\"\r\n                (click)=\"setResizePreset('vertical')\">\r\n                <mat-icon>crop_portrait</mat-icon>\r\n                {{ \"VERTICAL\" | oTranslate }}\r\n              </button>\r\n\r\n              <button mat-button type=\"button\" [disabled]=\"resizeLocked\" [class.is-active]=\"resizePreset === 'avatar'\"\r\n                (click)=\"setResizePreset('avatar')\">\r\n                <mat-icon class=\"material-symbols-outlined\">circle</mat-icon>\r\n                {{ \"AVATAR\" | oTranslate }}\r\n              </button>\r\n            </div>\r\n          </div>\r\n\r\n        </div>\r\n\r\n        <image-cropper #cropper [imageFile]=\"selectedFile!\" [maintainAspectRatio]=\"maintainAspectRatio\" [aspectRatio]=\"aspectRatio || 1\"\r\n          [canvasRotation]=\"canvasRotation\" [(transform)]=\"transform\" [imageQuality]=\"95\" format=\"jpeg\" (imageCropped)=\"onImageCropped($event)\"\r\n          (imageLoaded)=\"onImageLoaded($event)\" (loadImageFailed)=\"onLoadImageFailed()\" [containWithinAspectRatio]=\"true\"\r\n          [resetCropOnAspectRatioChange]=\"true\" [roundCropper]=\"roundCropper\" [cropperStaticWidth]=\" cropperStaticWidth\"\r\n          [cropperStaticHeight]=\"cropperStaticHeight\" [hideResizeSquares]=\"resizeLocked\" [cropper]=\"cropperPosition\"\r\n          [imageBase64]=\"cropperImageBase64\" (cropperReady)=\"onCropperReady($event)\" (cropperChange)=\"onCropperChange($event)\">\r\n        </image-cropper>\r\n\r\n        <div *ngIf=\"activeTool === 'crop' && !cropperLoading\" class=\"oie-adjust-bar\">\r\n\r\n          <div class=\"oie-dot-track\" fxLayout=\"row\" fxLayoutAlign=\"center center\" [class.is-scale]=\"cropAdjustMode === 'scale'\">\r\n\r\n            <div fxLayout=\"row\" fxFlex=\"135px\" class=\"oie-dots oie-dots--left\" *ngIf=\"cropAdjustMode !== 'scale'\">\r\n              <div class=\"oie-dots-track\" [style.transform]=\"'translateX(' + rotateDotsTranslatePx + 'px)'\">\r\n                <span *ngFor=\"let _ of dotsTape; let i = index\" class=\"oie-dot\" [class.oie-dot--big]=\"isBig(i)\"></span>\r\n              </div>\r\n            </div>\r\n\r\n            <div *ngIf=\"cropAdjustMode === 'scale'\" fxFlex=\"135px\"></div>\r\n\r\n            <div fxLayout=\"column\" fxFlex=\"55px\" class=\"oie-center\" aria-hidden=\"true\">\r\n              <span class=\"oie-dot-value\">{{ adjustLabel }}</span>\r\n              <span class=\"oie-dot-indicator\"></span>\r\n            </div>\r\n\r\n            <div fxLayout=\"row\" fxFlex=\"135px\" class=\"oie-dots oie-dots--right\">\r\n              <div class=\"oie-dots-track\"\r\n                [style.transform]=\"'translateX(' + (cropAdjustMode === 'scale' ? scaleDotsTranslatePx : rotateDotsTranslatePx) + 'px)'\">\r\n                <span *ngFor=\"let _ of dotsTape; let i = index\" class=\"oie-dot\" [class.oie-dot--big]=\"isBig(i)\"></span>\r\n              </div>\r\n            </div>\r\n\r\n            <input class=\"oie-dot-input\" [class.is-scale]=\"cropAdjustMode === 'scale'\" type=\"range\" [min]=\"adjustMin\" [max]=\"adjustMax\"\r\n              [step]=\"adjustStep\" [value]=\"adjustValue\" (input)=\"onAdjustInput($event.target.value)\" />\r\n          </div>\r\n\r\n          <div class=\"oie-selector\">\r\n            <button mat-button type=\"button\" [class.is-active]=\"cropAdjustMode === 'rotation'\" (click)=\"cropAdjustMode = 'rotation'\">\r\n              {{ \"ROTATION\" | oTranslate }}\r\n            </button>\r\n\r\n            <button mat-button type=\"button\" [class.is-active]=\"cropAdjustMode === 'scale'\" (click)=\"cropAdjustMode = 'scale'\">\r\n              {{ \"SCALE\" | oTranslate }}\r\n            </button>\r\n          </div>\r\n\r\n        </div>\r\n\r\n        <div *ngIf=\"activeTool === 'resize' && !cropperLoading\" fxLayout=\"column\" fxLayoutAlign=\"center center\">\r\n          <div fxLayout=\"row\" fxLayoutGap=\"6px\" fxLayoutAlign=\"center baseline\">\r\n            <mat-form-field [ngStyle]=\"{'width': '120px'}\">\r\n              <mat-label>{{ \"WIDTH\" | oTranslate}}</mat-label>\r\n              <input matInput type=\"number\" min=\"1\" [(ngModel)]=\"resizeWidth\" [ngModelOptions]=\"{ standalone: true }\" [disabled]=\"resizeLocked\"\r\n                (blur)=\"onResizeBoxCommit('w')\" (keydown.enter)=\"onResizeBoxCommit('w')\">\r\n            </mat-form-field>\r\n            <button mat-icon-button type=\"button\" (click)=\"toggleResizeLock()\" [attr.aria-label]=\"'LOCK_SIZE'\">\r\n              <mat-icon>{{ resizeLocked ? 'lock' : 'lock_open' }}</mat-icon>\r\n            </button>\r\n            <mat-form-field [ngStyle]=\"{'width': '120px'}\">\r\n              <mat-label>{{ \"HEIGHT\" | oTranslate}}</mat-label>\r\n              <input matInput type=\"number\" min=\"1\" [(ngModel)]=\"resizeHeight\" [ngModelOptions]=\"{ standalone: true }\" [disabled]=\"resizeLocked\"\r\n                (blur)=\"onResizeBoxCommit('h')\" (keydown.enter)=\"onResizeBoxCommit('h')\">\r\n            </mat-form-field>\r\n          </div>\r\n          <div class=\"oie-selector ratio\" fxLayout=\"row\" fxLayoutGap=\"24px\" fxLayoutAlign=\"center\">\r\n            <button mat-button type=\"button\" [disabled]=\"resizeLocked || resizePreset === 'avatar'\" [class.is-active]=\"resizeRatioPreset === 'custom'\"\r\n              (click)=\"setResizeRatioPreset('custom')\">\r\n              <mat-icon>crop_free</mat-icon>\r\n              {{ 'CUSTOM' | oTranslate}}\r\n            </button>\r\n\r\n            <button mat-button type=\"button\" [disabled]=\"resizeLocked || resizePreset === 'avatar'\" [class.is-active]=\"resizeRatioPreset === '1:1'\"\r\n              (click)=\"setResizeRatioPreset('1:1')\">\r\n              <mat-icon>crop_square</mat-icon>\r\n              1:1\r\n            </button>\r\n\r\n            <button mat-button type=\"button\" [disabled]=\"resizeLocked || resizePreset === 'avatar'\" [class.is-active]=\"resizeRatioPreset === '2:1'\"\r\n              (click)=\"setResizeRatioPreset('2:1')\">\r\n              <mat-icon>crop_16_9</mat-icon>\r\n              2:1\r\n            </button>\r\n\r\n            <button mat-button type=\"button\" [disabled]=\"resizeLocked || resizePreset === 'avatar'\" [class.is-active]=\"resizeRatioPreset === '3:2'\"\r\n              (click)=\"setResizeRatioPreset('3:2')\">\r\n              <mat-icon>crop_3_2</mat-icon>\r\n              3:2\r\n            </button>\r\n\r\n            <button mat-button type=\"button\" [disabled]=\"resizeLocked || resizePreset === 'avatar'\" [class.is-active]=\"resizeRatioPreset === '4:3'\"\r\n              (click)=\"setResizeRatioPreset('4:3')\">\r\n              <mat-icon>crop_landscape</mat-icon>\r\n              4:3\r\n            </button>\r\n\r\n            <button mat-button type=\"button\" [disabled]=\"resizeLocked || resizePreset === 'avatar'\" [class.is-active]=\"resizeRatioPreset === '5:4'\"\r\n              (click)=\"setResizeRatioPreset('5:4')\">\r\n              <mat-icon>crop_5_4</mat-icon>\r\n              5:4\r\n            </button>\r\n\r\n            <button mat-button type=\"button\" [disabled]=\"resizeLocked || resizePreset === 'avatar'\" [class.is-active]=\"resizeRatioPreset === '16:9'\"\r\n              (click)=\"setResizeRatioPreset('16:9')\">\r\n              <mat-icon>crop_16_9</mat-icon>\r\n              16:9\r\n            </button>\r\n          </div>\r\n        </div>\r\n      </ng-container>\r\n\r\n      <div class=\"o-image-editor-load-zone\" *ngIf=\"!selectedFile || uploadOverlay\" [class.is-overlay]=\"uploadOverlay\" fxLayout=\"column\"\r\n        fxLayoutAlign=\"center center\" fxLayoutGap=\"32px\" fxFlex=\"100\" [class.o-image-editor-load-zone--dragover]=\"dragOver\"\r\n        (dragover)=\"onDragOver($event)\" (dragleave)=\"onDragLeave($event)\" (drop)=\"onDrop($event)\">\r\n        <span>{{ \"DRAG_MESSAGE\" | oTranslate }}</span>\r\n        <span>{{ \"OR\" | oTranslate }}</span>\r\n        <o-button attr=\"select_image\" type=\"RAISED\" icon=\"upload\" label=\"UPLOAD_IMAGE\" (onClick)=\"$event.stopPropagation(); openFilePicker()\">\r\n        </o-button>\r\n        <input #fileInput type=\"file\" hidden accept=\"image/jpeg,image/jpg,image/png,image/gif\" (change)=\"onFileInputChange($event)\">\r\n      </div>\r\n\r\n      <div *ngIf=\"cropperLoading\" fxLayout=\"column\" fxLayoutAlign=\"center center\" fxFlex=\"100\">\r\n        <mat-spinner diameter=\"60\"></mat-spinner>\r\n      </div>\r\n\r\n    </div>\r\n    <div *ngIf=\"selectedFile\" fxLayout=\"column\" fxFlex=\"82px\"></div>\r\n  </div>\r\n  <ng-container *ngIf=\"selectedFile && actionsPosition === 'bottom'\">\r\n    <ng-container *ngTemplateOutlet=\"actionsTpl\"></ng-container>\r\n  </ng-container>\r\n</div>\r\n", styles: ["@import\"https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined\";.o-image-editor{padding:32px;overflow:hidden}.o-image-editor-content{min-height:0;overflow:hidden}.o-image-editor-body{min-height:0;overflow:hidden;position:relative;justify-content:space-between}.o-image-editor-load-zone.is-overlay{position:absolute;inset:0;z-index:10;background:#ffffffbf;backdrop-filter:blur(2px);-webkit-backdrop-filter:blur(2px)}.oie-adjust-bar{display:flex;flex-direction:column;align-items:center;gap:10px;padding:10px 0 0 10px}.oie-dot-track{position:relative;width:328px;height:22px;overflow:visible}.oie-dots{height:100%;overflow:hidden;display:flex;align-items:center}.oie-dots-track{display:flex;align-items:center;gap:4px;will-change:transform}.oie-dots--left .oie-dots-track{flex-direction:row-reverse}.oie-dot{width:4px;height:4px;border-radius:50%;background:#00000029;flex:0 0 auto}.oie-dot--big{width:6px;height:6px;background:#0000007a}.oie-center{position:relative;height:100%;pointer-events:none;z-index:3}.oie-dot-value{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);font-size:14px;line-height:14px;white-space:nowrap;color:#000000a6}.oie-dot-indicator{position:absolute;left:50%;top:calc(50% - 8px);transform:translate(-50%,-100%);width:2px;height:10px;border-radius:2px;background:#0000007a}.oie-dot-input{position:absolute;inset:0;opacity:0;cursor:pointer;z-index:4}.oie-dot-input.is-scale{left:135px;width:193px;right:auto}.oie-selector{display:inline-flex;gap:16px}.oie-selector button.mat-button,.oie-selector button.mat-mdc-button{min-width:auto;width:80px;border-radius:4px;background:transparent;border:1px solid transparent;box-shadow:none}.oie-selector.ratio button.mat-button,.oie-selector.ratio button.mat-mdc-button{width:auto}.oie-selector button.is-active{background:#00000014;border-color:#00000029}.oie-selector button.mat-button[disabled],.oie-selector button.mat-mdc-button[disabled]{opacity:.45}.tools-toggle{border:0}.tools-toggle .mat-button-toggle{width:72px;height:64px;border-radius:4px;border:1px solid rgba(0,0,0,.16)}.tools-toggle .mat-button-toggle mat-icon{padding-top:10px}.tools-toggle .mat-button-toggle span{line-height:20px;padding-bottom:10px;font-size:13px}.tools-toggle.mat-button-toggle-group-appearance-standard .mat-button-toggle-appearance-standard .mat-button-toggle-label-content{padding:0}.tools-toggle .mat-button-toggle.mat-button-toggle-checked{background:var(--o-primary-500);color:var(--o-primary-contrast-500);border-color:transparent}\n"] }]
    }], () => [{ type: i1$1.DialogService }, { type: i0.Injector }, { type: i0.ChangeDetectorRef }, { type: i0.NgZone }], { fileInput: [{
            type: ViewChild,
            args: ['fileInput', { static: false }]
        }], cropperComp: [{
            type: ViewChild,
            args: ['cropper']
        }], imageBase64: [{
            type: Input,
            args: ['image']
        }], saveTarget: [{
            type: Input,
            args: ['save-target']
        }], actionsPosition: [{
            type: Input,
            args: ['actions-position']
        }], onSaveBase64: [{
            type: Output
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(OImageEditorComponent, { className: "OImageEditorComponent", filePath: "lib\\components\\o-image-editor\\o-image-editor.component.ts", lineNumber: 43 }); })();

class OImageEditorModule {
    static { this.ɵfac = function OImageEditorModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || OImageEditorModule)(); }; }
    static { this.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: OImageEditorModule }); }
    static { this.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ imports: [OImageEditorComponent] }); }
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(OImageEditorModule, [{
        type: NgModule,
        args: [{
                imports: [OImageEditorComponent],
                exports: [OImageEditorComponent]
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(OImageEditorModule, { imports: [OImageEditorComponent], exports: [OImageEditorComponent] }); })();

const OEXTRACOMPONENTS_DECLARATION_MODULES = [];
const OEXTRACOMPONENTS_IMPORTS_MODULES = [
    CommonModule,
    OntimizeWebModule,
    OSkeletonComponent
];
const OEXTRACOMPONENTS_PROVIDERS = [
    TranslateExtraComponentsService
];
const OEXTRACOMPONENTS_EXPORT_MODULES = [
    OSkeletonComponent,
    ODataViewModule,
    OImageEditorModule
];

class OExtraComponentsModule {
    static { this.ɵfac = function OExtraComponentsModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || OExtraComponentsModule)(); }; }
    static { this.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: OExtraComponentsModule }); }
    static { this.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ providers: [...OEXTRACOMPONENTS_PROVIDERS], imports: [OEXTRACOMPONENTS_IMPORTS_MODULES, ODataViewModule, OImageEditorModule] }); }
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(OExtraComponentsModule, [{
        type: NgModule,
        args: [{
                declarations: [...OEXTRACOMPONENTS_DECLARATION_MODULES],
                imports: [...OEXTRACOMPONENTS_IMPORTS_MODULES],
                providers: [...OEXTRACOMPONENTS_PROVIDERS],
                exports: [...OEXTRACOMPONENTS_EXPORT_MODULES]
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(OExtraComponentsModule, { imports: [i2.CommonModule, i1$1.OntimizeWebModule, OSkeletonComponent], exports: [OSkeletonComponent, ODataViewModule, OImageEditorModule] }); })();

;

;

/*
 * Public API Surface of ontimize-web-ngx-extra-components
 */

/**
 * Generated bundle index. Do not edit.
 */

export { ODataViewComponent, ODataViewGridItemDirective, ODataViewModule, ODataViewTableColumnsDirective, OExtraComponentsModule, OImageEditorComponent, OImageEditorModule, OSkeletonComponent, TranslateExtraComponentsService };
//# sourceMappingURL=ontimize-web-ngx-extra-components.mjs.map
