import * as i0 from '@angular/core';
import { EventEmitter, ChangeDetectionStrategy, Component, ViewEncapsulation, Injectable, Directive, HostBinding, Input, HostListener, ViewChild, NgZone, NgModule } from '@angular/core';
import * as i1 from '@angular/platform-browser';
import { DomSanitizer, HammerGestureConfig, HAMMER_GESTURE_CONFIG } from '@angular/platform-browser';
import { __decorate, __metadata } from 'tslib';
import { BooleanInputConverter, Util as Util$1 } from 'ontimize-web-ngx';
import * as i3 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i2 from '@angular/material/icon';
import { MatIconModule } from '@angular/material/icon';
import { ScrollStrategyOptions, Overlay, OverlayConfig } from '@angular/cdk/overlay';
import { ComponentPortal } from '@angular/cdk/portal';
import { Subscription, merge } from 'rxjs';
import { take, filter } from 'rxjs/operators';

class GalleryActionComponent {
    constructor() {
        this.disabled = false;
        this.titleText = '';
        this.onClick = new EventEmitter();
    }
    handleClick(event) {
        if (!this.disabled) {
            this.onClick.emit(event);
        }
        event.stopPropagation();
        event.preventDefault();
    }
    static { this.ɵfac = function GalleryActionComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || GalleryActionComponent)(); }; }
    static { this.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: GalleryActionComponent, selectors: [["o-gallery-action"]], inputs: { icon: "icon", disabled: "disabled", titleText: "titleText" }, outputs: { onClick: "onClick" }, standalone: true, features: [i0.ɵɵStandaloneFeature], decls: 3, vars: 4, consts: [["aria-hidden", "true", 1, "o-gallery-icon", 3, "click", "title"], [1, "o-gallery-icon-content"]], template: function GalleryActionComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0);
            i0.ɵɵlistener("click", function GalleryActionComponent_Template_div_click_0_listener($event) { return ctx.handleClick($event); });
            i0.ɵɵelementStart(1, "em", 1);
            i0.ɵɵtext(2);
            i0.ɵɵelementEnd()();
        } if (rf & 2) {
            i0.ɵɵclassProp("o-gallery-icon-disabled", ctx.disabled);
            i0.ɵɵproperty("title", ctx.titleText);
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate(ctx.icon);
        } }, encapsulation: 2, changeDetection: 0 }); }
}
__decorate([
    BooleanInputConverter(),
    __metadata("design:type", Boolean)
], GalleryActionComponent.prototype, "disabled", void 0);
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(GalleryActionComponent, [{
        type: Component,
        args: [{ selector: 'o-gallery-action', standalone: true, inputs: [
                    'icon',
                    'disabled',
                    'titleText'
                ], outputs: [
                    'onClick'
                ], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"o-gallery-icon\" [class.o-gallery-icon-disabled]=\"disabled\" aria-hidden=\"true\" [title]=\"titleText\" (click)=\"handleClick($event)\">\r\n  <em class=\"o-gallery-icon-content\">{{ icon }}</em>\r\n</div>\r\n" }]
    }], null, { disabled: [] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(GalleryActionComponent, { className: "GalleryActionComponent", filePath: "lib\\components\\gallery-action\\o-gallery-action.component.ts", lineNumber: 18 }); })();

const _c0$5 = (a0, a1) => ({ "o-gallery-arrow-left": a0, "o-gallery-arrow-top": a1 });
const _c1 = (a0, a1) => ({ "o-gallery-arrow-right": a0, "o-gallery-arrow-bottom": a1 });
class GalleryArrowsComponent {
    constructor() {
        this.position = 'bottom';
        this.onPrevClick = new EventEmitter();
        this.onNextClick = new EventEmitter();
        this.updatePosition();
    }
    ngOnChanges(changes) {
        if (Util$1.isDefined(changes.layout)) {
            this.updatePosition();
        }
    }
    updatePosition() {
        if (Util$1.isDefined(this.layout)) {
            this.position = this.layout.substring(this.layout.indexOf('-') + 1);
        }
    }
    handlePrevClick() {
        this.onPrevClick.emit();
    }
    handleNextClick() {
        this.onNextClick.emit();
    }
    static { this.ɵfac = function GalleryArrowsComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || GalleryArrowsComponent)(); }; }
    static { this.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: GalleryArrowsComponent, selectors: [["o-gallery-arrows"]], hostVars: 2, hostBindings: function GalleryArrowsComponent_HostBindings(rf, ctx) { if (rf & 2) {
            i0.ɵɵclassProp("o-gallery-arrows", true);
        } }, inputs: { prevDisabled: [0, "prev-disabled", "prevDisabled"], nextDisabled: [0, "next-disabled", "nextDisabled"], arrowPrevIcon: [0, "arrow-prev-icon", "arrowPrevIcon"], arrowNextIcon: [0, "arrow-next-icon", "arrowNextIcon"], layout: "layout" }, outputs: { onPrevClick: "onPrevClick", onNextClick: "onNextClick" }, standalone: true, features: [i0.ɵɵNgOnChangesFeature, i0.ɵɵStandaloneFeature], decls: 8, vars: 14, consts: [[1, "o-gallery-arrow-wrapper", 3, "ngClass"], ["aria-hidden", "true", 1, "o-gallery-icon", "o-gallery-arrow", 3, "click"], [1, "o-gallery-icon-content"]], template: function GalleryArrowsComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div", 0)(1, "div", 1);
            i0.ɵɵlistener("click", function GalleryArrowsComponent_Template_div_click_1_listener() { return ctx.handlePrevClick(); });
            i0.ɵɵelementStart(2, "mat-icon", 2);
            i0.ɵɵtext(3);
            i0.ɵɵelementEnd()()();
            i0.ɵɵelementStart(4, "div", 0)(5, "div", 1);
            i0.ɵɵlistener("click", function GalleryArrowsComponent_Template_div_click_5_listener() { return ctx.handleNextClick(); });
            i0.ɵɵelementStart(6, "mat-icon", 2);
            i0.ɵɵtext(7);
            i0.ɵɵelementEnd()()();
        } if (rf & 2) {
            i0.ɵɵproperty("ngClass", i0.ɵɵpureFunction2(8, _c0$5, ctx.position === "top" || ctx.position === "bottom", ctx.position === "left" || ctx.position === "right"));
            i0.ɵɵadvance();
            i0.ɵɵclassProp("o-gallery-disabled", ctx.prevDisabled);
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate(ctx.arrowPrevIcon);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngClass", i0.ɵɵpureFunction2(11, _c1, ctx.position === "top" || ctx.position === "bottom", ctx.position === "left" || ctx.position === "right"));
            i0.ɵɵadvance();
            i0.ɵɵclassProp("o-gallery-disabled", ctx.nextDisabled);
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate(ctx.arrowNextIcon);
        } }, dependencies: [CommonModule, i3.NgClass, MatIconModule, i2.MatIcon], styles: [".o-gallery-arrows .o-gallery-arrow-wrapper{position:absolute;height:100%;width:1px;display:table;z-index:2000;table-layout:fixed}.o-gallery-arrows .o-gallery-arrow-left .o-gallery-arrow{left:16px}.o-gallery-arrows .o-gallery-arrow-right{right:0}.o-gallery-arrows .o-gallery-arrow-right .o-gallery-arrow{right:16px}.o-gallery-arrows .o-gallery-arrow{top:calc(50% - 12px);cursor:pointer}.o-gallery-arrows .o-gallery-arrow.o-gallery-disabled{opacity:.6;cursor:default}o-gallery-thumbnails .o-gallery-arrows{width:100%;height:1px}o-gallery-thumbnails .o-gallery-arrows .o-gallery-arrow-wrapper .o-gallery-icon-content{width:16px;height:16px;font-size:16px}o-gallery-thumbnails .o-gallery-arrows .o-gallery-arrow-wrapper.o-gallery-arrow-top,o-gallery-thumbnails .o-gallery-arrows .o-gallery-arrow-wrapper.o-gallery-arrow-bottom{left:calc(50% - 8px)}o-gallery-thumbnails .o-gallery-arrows .o-gallery-arrow-wrapper.o-gallery-arrow-right .o-gallery-arrow,o-gallery-thumbnails .o-gallery-arrows .o-gallery-arrow-wrapper.o-gallery-arrow-left .o-gallery-arrow{top:calc(50% - 8px)}o-gallery-thumbnails .o-gallery-arrows .o-gallery-arrow-wrapper.o-gallery-arrow-top .o-gallery-arrow{top:12px}o-gallery-thumbnails .o-gallery-arrows .o-gallery-arrow-wrapper.o-gallery-arrow-top .o-gallery-arrow .o-gallery-icon-content{transform:rotate(90deg)}o-gallery-thumbnails .o-gallery-arrows .o-gallery-arrow-wrapper.o-gallery-arrow-bottom .o-gallery-arrow{bottom:12px;top:inherit}o-gallery-thumbnails .o-gallery-arrows .o-gallery-arrow-wrapper.o-gallery-arrow-bottom .o-gallery-arrow .o-gallery-icon-content{transform:rotate(90deg)}.o-gallery-preview .o-gallery-arrow{top:calc(50% - 24px)}.o-gallery-preview .o-gallery-arrow .o-gallery-icon-content{height:48px;width:48px;font-size:48px;border-radius:50%}.o-gallery-preview .o-gallery-arrow-left .o-gallery-arrow{left:64px}.o-gallery-preview .o-gallery-arrow-right .o-gallery-arrow{right:64px}\n"], encapsulation: 2, changeDetection: 0 }); }
}
__decorate([
    BooleanInputConverter(),
    __metadata("design:type", Boolean)
], GalleryArrowsComponent.prototype, "prevDisabled", void 0);
__decorate([
    BooleanInputConverter(),
    __metadata("design:type", Boolean)
], GalleryArrowsComponent.prototype, "nextDisabled", void 0);
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(GalleryArrowsComponent, [{
        type: Component,
        args: [{ selector: 'o-gallery-arrows', standalone: true, imports: [CommonModule, MatIconModule], inputs: [
                    'prevDisabled: prev-disabled',
                    'nextDisabled: next-disabled',
                    'arrowPrevIcon: arrow-prev-icon',
                    'arrowNextIcon: arrow-next-icon',
                    'layout'
                ], outputs: [
                    'onPrevClick',
                    'onNextClick'
                ], encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, host: {
                    '[class.o-gallery-arrows]': 'true'
                }, template: "<div class=\"o-gallery-arrow-wrapper\"\r\n  [ngClass]=\"{'o-gallery-arrow-left': position==='top' || position==='bottom','o-gallery-arrow-top':position==='left' || position==='right' }\">\r\n  <div class=\"o-gallery-icon o-gallery-arrow\" aria-hidden=\"true\" (click)=\"handlePrevClick()\" [class.o-gallery-disabled]=\"prevDisabled\">\r\n    <mat-icon class=\"o-gallery-icon-content\">{{arrowPrevIcon}}</mat-icon>\r\n  </div>\r\n</div>\r\n<div class=\"o-gallery-arrow-wrapper\"\r\n  [ngClass]=\"{'o-gallery-arrow-right': position==='top' || position==='bottom','o-gallery-arrow-bottom':position==='left' || position==='right' }\">\r\n  <div class=\"o-gallery-icon o-gallery-arrow\" aria-hidden=\"true\" (click)=\"handleNextClick()\" [class.o-gallery-disabled]=\"nextDisabled\">\r\n    <mat-icon class=\"o-gallery-icon-content\">{{arrowNextIcon}}</mat-icon>\r\n  </div>\r\n</div>\r\n", styles: [".o-gallery-arrows .o-gallery-arrow-wrapper{position:absolute;height:100%;width:1px;display:table;z-index:2000;table-layout:fixed}.o-gallery-arrows .o-gallery-arrow-left .o-gallery-arrow{left:16px}.o-gallery-arrows .o-gallery-arrow-right{right:0}.o-gallery-arrows .o-gallery-arrow-right .o-gallery-arrow{right:16px}.o-gallery-arrows .o-gallery-arrow{top:calc(50% - 12px);cursor:pointer}.o-gallery-arrows .o-gallery-arrow.o-gallery-disabled{opacity:.6;cursor:default}o-gallery-thumbnails .o-gallery-arrows{width:100%;height:1px}o-gallery-thumbnails .o-gallery-arrows .o-gallery-arrow-wrapper .o-gallery-icon-content{width:16px;height:16px;font-size:16px}o-gallery-thumbnails .o-gallery-arrows .o-gallery-arrow-wrapper.o-gallery-arrow-top,o-gallery-thumbnails .o-gallery-arrows .o-gallery-arrow-wrapper.o-gallery-arrow-bottom{left:calc(50% - 8px)}o-gallery-thumbnails .o-gallery-arrows .o-gallery-arrow-wrapper.o-gallery-arrow-right .o-gallery-arrow,o-gallery-thumbnails .o-gallery-arrows .o-gallery-arrow-wrapper.o-gallery-arrow-left .o-gallery-arrow{top:calc(50% - 8px)}o-gallery-thumbnails .o-gallery-arrows .o-gallery-arrow-wrapper.o-gallery-arrow-top .o-gallery-arrow{top:12px}o-gallery-thumbnails .o-gallery-arrows .o-gallery-arrow-wrapper.o-gallery-arrow-top .o-gallery-arrow .o-gallery-icon-content{transform:rotate(90deg)}o-gallery-thumbnails .o-gallery-arrows .o-gallery-arrow-wrapper.o-gallery-arrow-bottom .o-gallery-arrow{bottom:12px;top:inherit}o-gallery-thumbnails .o-gallery-arrows .o-gallery-arrow-wrapper.o-gallery-arrow-bottom .o-gallery-arrow .o-gallery-icon-content{transform:rotate(90deg)}.o-gallery-preview .o-gallery-arrow{top:calc(50% - 24px)}.o-gallery-preview .o-gallery-arrow .o-gallery-icon-content{height:48px;width:48px;font-size:48px;border-radius:50%}.o-gallery-preview .o-gallery-arrow-left .o-gallery-arrow{left:64px}.o-gallery-preview .o-gallery-arrow-right .o-gallery-arrow{right:64px}\n"] }]
    }], () => [], { prevDisabled: [], nextDisabled: [] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(GalleryArrowsComponent, { className: "GalleryArrowsComponent", filePath: "lib\\components\\gallery-arrows\\o-gallery-arrows.component.ts", lineNumber: 29 }); })();

const _c0$4 = a0 => ({ "o-gallery-active": a0 });
function GalleryBulletsComponent_div_0_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 1);
    i0.ɵɵlistener("click", function GalleryBulletsComponent_div_0_Template_div_click_0_listener($event) { const i_r2 = i0.ɵɵrestoreView(_r1).index; const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.handleChange($event, i_r2)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const i_r2 = ctx.index;
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵproperty("ngClass", i0.ɵɵpureFunction1(1, _c0$4, i_r2 == ctx_r2.active));
} }
class GalleryBulletsComponent {
    constructor() {
        this.active = 0;
        this.onChange = new EventEmitter();
    }
    handleChange(_event, index) {
        this.onChange.emit(index);
    }
    getBullets() {
        return Array(this.count);
    }
    static { this.ɵfac = function GalleryBulletsComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || GalleryBulletsComponent)(); }; }
    static { this.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: GalleryBulletsComponent, selectors: [["o-gallery-bullets"]], inputs: { count: "count", active: "active" }, outputs: { onChange: "onChange" }, standalone: true, features: [i0.ɵɵStandaloneFeature], decls: 1, vars: 1, consts: [["class", "o-gallery-bullet", 3, "ngClass", "click", 4, "ngFor", "ngForOf"], [1, "o-gallery-bullet", 3, "click", "ngClass"]], template: function GalleryBulletsComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵtemplate(0, GalleryBulletsComponent_div_0_Template, 1, 3, "div", 0);
        } if (rf & 2) {
            i0.ɵɵproperty("ngForOf", ctx.getBullets());
        } }, dependencies: [CommonModule, i3.NgClass, i3.NgForOf], styles: ["[_nghost-%COMP%]{position:absolute;z-index:2000;display:inline-flex;left:50%;transform:translate(-50%);bottom:0;padding:10px}.o-gallery-bullet[_ngcontent-%COMP%]{width:10px;height:10px;border-radius:50%;cursor:pointer;background:#fff}.o-gallery-bullet[_ngcontent-%COMP%]:not(:first-child){margin-left:5px}.o-gallery-bullet.o-gallery-active[_ngcontent-%COMP%], .o-gallery-bullet[_ngcontent-%COMP%]:hover{background:#000}"], changeDetection: 0 }); }
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(GalleryBulletsComponent, [{
        type: Component,
        args: [{ selector: 'o-gallery-bullets', inputs: [
                    'count',
                    'active'
                ], outputs: [
                    'onChange'
                ], standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"o-gallery-bullet\" *ngFor=\"let bullet of getBullets(); let i = index;\" (click)=\"handleChange($event, i)\"\r\n  [ngClass]=\"{ 'o-gallery-active': i == active }\"></div>\r\n", styles: [":host{position:absolute;z-index:2000;display:inline-flex;left:50%;transform:translate(-50%);bottom:0;padding:10px}.o-gallery-bullet{width:10px;height:10px;border-radius:50%;cursor:pointer;background:#fff}.o-gallery-bullet:not(:first-child){margin-left:5px}.o-gallery-bullet.o-gallery-active,.o-gallery-bullet:hover{background:#000}\n"] }]
    }], null, null); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(GalleryBulletsComponent, { className: "GalleryBulletsComponent", filePath: "lib\\components\\gallery-bullets\\o-gallery-bullets.component.ts", lineNumber: 19 }); })();

class Util {
    static isUrl(fileSource) {
        const regExpData = /^\s*data:/i;
        let base64ContentArray = fileSource.split(",");
        if (base64ContentArray[0].match(regExpData) != null) {
            return false;
        }
        else {
            return true;
        }
    }
    /**
    * Determines whether url absolute is
    * @param url
    * @returns
    */
    static isUrlAbsolute(url) {
        return url.search(/^(http|https)\:\/\//) > -1;
    }
    static getMimeType(fileSource) {
        const regExp = /^\s*data:([a-z]+\/[a-z\*]+(;[a-z\-]+\=[a-z\-]+)?)?(;base64)?\s*$/i;
        let base64ContentArray = fileSource.split(",");
        return base64ContentArray[0].match(regExp)[1];
    }
}

class GalleryHelperService {
    constructor(renderer) {
        this.renderer = renderer;
        this.swipeHandlers = new Map();
    }
    manageSwipe(status, element, id, nextHandler, prevHandler) {
        const handlers = this.getSwipeHandlers(id);
        // swipeleft and swiperight are available only if hammerjs is included
        try {
            if (status && !handlers) {
                this.swipeHandlers.set(id, [
                    this.renderer.listen(element.nativeElement, 'swipeleft', () => nextHandler()),
                    this.renderer.listen(element.nativeElement, 'swiperight', () => prevHandler())
                ]);
            }
            else if (!status && handlers) {
                handlers.forEach((handler) => handler());
                this.removeSwipeHandlers(id);
            }
        }
        catch (e) { }
    }
    validateUrl(url) {
        if (url.replace) {
            return url.replace("/ /g", '%20')
                .replace("/\, g", '%27');
        }
        else {
            return url;
        }
    }
    getBackgroundUrl(image) {
        return 'url(\'' + this.validateUrl(image) + '\')';
    }
    getSwipeHandlers(id) {
        return this.swipeHandlers.get(id);
    }
    removeSwipeHandlers(id) {
        this.swipeHandlers.delete(id);
    }
    getFileType(fileSource) {
        //First we check if the filesouce starts with data:
        if (!Util.isUrl(fileSource)) {
            return this.getFileTypeByMime(fileSource);
        }
        try {
            let url;
            if (Util.isUrlAbsolute(fileSource)) {
                url = new URL(fileSource);
            }
            else {
                url = new URL(fileSource, document.baseURI);
            }
            if (url == undefined) {
                return 'unknown';
            }
            else {
                return this.getFileTypeByURL(url);
            }
        }
        catch (error) {
            console.warn("Impossible to parse file source url");
        }
        return 'unknown';
    }
    /**
     * Gets file type by mime
     * @param fileSource
     * @returns file type by mime
     */
    getFileTypeByMime(fileSource) {
        //We get the mimeType and check that it is a valid type
        let mimeType = Util.getMimeType(fileSource);
        if (mimeType != undefined) {
            switch (mimeType.split("/")[0]) {
                case 'image': return 'image';
                case 'video': return 'video';
                default: return 'unknown';
            }
        }
        else {
            return 'unknown';
        }
    }
    /**
     * Gets file type by URL
     * @param url
     * @returns file type by URL
     */
    getFileTypeByURL(url) {
        const fileName = url.pathname.split('/').pop();
        if (fileName == undefined || fileName.length == 0) {
            return 'unknown';
        }
        let fileExtension = fileName.split('.').pop().toLowerCase();
        if (!fileExtension
            || fileExtension === 'jpeg' || fileExtension === 'jpg'
            || fileExtension === 'png' || fileExtension === 'bmp'
            || fileExtension === 'gif') {
            return 'image';
        }
        else if (fileExtension === 'avi' || fileExtension === 'flv'
            || fileExtension === 'wmv' || fileExtension === 'mov'
            || fileExtension === 'mp4') {
            return 'video';
        }
    }
    static { this.ɵfac = function GalleryHelperService_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || GalleryHelperService)(i0.ɵɵinject(i0.Renderer2)); }; }
    static { this.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: GalleryHelperService, factory: GalleryHelperService.ɵfac }); }
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(GalleryHelperService, [{
        type: Injectable
    }], () => [{ type: i0.Renderer2 }], null); })();

class GalleryImageDirective {
    set image(val) {
        this._image = val;
        this.src = this.sanitization.bypassSecurityTrustStyle(this.helperService.getBackgroundUrl(this._image));
    }
    get imgage() {
        return this._image;
    }
    constructor(sanitization, helperService) {
        this.sanitization = sanitization;
        this.helperService = helperService;
    }
    static { this.ɵfac = function GalleryImageDirective_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || GalleryImageDirective)(i0.ɵɵdirectiveInject(i1.DomSanitizer), i0.ɵɵdirectiveInject(GalleryHelperService)); }; }
    static { this.ɵdir = /*@__PURE__*/ i0.ɵɵdefineDirective({ type: GalleryImageDirective, selectors: [["", "oGalleryBackgroundImg", ""]], hostVars: 2, hostBindings: function GalleryImageDirective_HostBindings(rf, ctx) { if (rf & 2) {
            i0.ɵɵstyleProp("background-image", ctx.src);
        } }, inputs: { image: [0, "oGalleryBackgroundImg", "image"] }, standalone: true }); }
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(GalleryImageDirective, [{
        type: Directive,
        args: [{
                selector: '[oGalleryBackgroundImg]',
                standalone: true
            }]
    }], () => [{ type: i1.DomSanitizer }, { type: GalleryHelperService }], { image: [{
            type: Input,
            args: ['oGalleryBackgroundImg']
        }], src: [{
            type: HostBinding,
            args: ['style.background-image']
        }] }); })();

class GalleryAnimation {
    static { this.Fade = 'fade'; }
    static { this.Slide = 'slide'; }
    static { this.Rotate = 'rotate'; }
    static { this.Zoom = 'zoom'; }
}

const _c0$3 = (a0, a1, a2, a3) => ({ "o-gallery-active": a0, "o-gallery-inactive-left": a1, "o-gallery-inactive-right": a2, "o-gallery-clickable": a3 });
function GalleryImageComponent_div_1_div_1_o_gallery_action_2_Template(rf, ctx) { if (rf & 1) {
    const _r4 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "o-gallery-action", 9);
    i0.ɵɵlistener("onClick", function GalleryImageComponent_div_1_div_1_o_gallery_action_2_Template_o_gallery_action_onClick_0_listener($event) { const action_r5 = i0.ɵɵrestoreView(_r4).$implicit; const image_r2 = i0.ɵɵnextContext(2).$implicit; return i0.ɵɵresetView(action_r5.onClick($event, image_r2.index)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const action_r5 = ctx.$implicit;
    i0.ɵɵproperty("icon", action_r5.icon)("disabled", action_r5.disabled)("titleText", action_r5.titleText);
} }
function GalleryImageComponent_div_1_div_1_div_3_Template(rf, ctx) { if (rf & 1) {
    const _r6 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 10);
    i0.ɵɵlistener("click", function GalleryImageComponent_div_1_div_1_div_3_Template_div_click_0_listener($event) { i0.ɵɵrestoreView(_r6); return i0.ɵɵresetView($event.stopPropagation()); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const image_r2 = i0.ɵɵnextContext(2).$implicit;
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵproperty("innerHTML", ctx_r2.descriptions[image_r2.index], i0.ɵɵsanitizeHtml);
} }
function GalleryImageComponent_div_1_div_1_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 5);
    i0.ɵɵlistener("click", function GalleryImageComponent_div_1_div_1_Template_div_click_0_listener($event) { i0.ɵɵrestoreView(_r1); const image_r2 = i0.ɵɵnextContext().$implicit; const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.handleClick($event, image_r2.index)); });
    i0.ɵɵelementStart(1, "div", 6);
    i0.ɵɵtemplate(2, GalleryImageComponent_div_1_div_1_o_gallery_action_2_Template, 1, 3, "o-gallery-action", 7);
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(3, GalleryImageComponent_div_1_div_1_div_3_Template, 1, 1, "div", 8);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const image_r2 = i0.ɵɵnextContext().$implicit;
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵproperty("oGalleryBackgroundImg", image_r2.src)("ngClass", i0.ɵɵpureFunction4(4, _c0$3, ctx_r2.selectedIndex === image_r2.index, ctx_r2.selectedIndex > image_r2.index, ctx_r2.selectedIndex < image_r2.index, ctx_r2.clickable));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngForOf", ctx_r2.actions);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r2.showDescription && ctx_r2.descriptions[image_r2.index]);
} }
function GalleryImageComponent_div_1_div_2_o_gallery_action_5_Template(rf, ctx) { if (rf & 1) {
    const _r8 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "o-gallery-action", 9);
    i0.ɵɵlistener("onClick", function GalleryImageComponent_div_1_div_2_o_gallery_action_5_Template_o_gallery_action_onClick_0_listener($event) { const action_r9 = i0.ɵɵrestoreView(_r8).$implicit; const image_r2 = i0.ɵɵnextContext(2).$implicit; return i0.ɵɵresetView(action_r9.onClick($event, image_r2.index)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const action_r9 = ctx.$implicit;
    i0.ɵɵproperty("icon", action_r9.icon)("disabled", action_r9.disabled)("titleText", action_r9.titleText);
} }
function GalleryImageComponent_div_1_div_2_div_6_Template(rf, ctx) { if (rf & 1) {
    const _r10 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 10);
    i0.ɵɵlistener("click", function GalleryImageComponent_div_1_div_2_div_6_Template_div_click_0_listener($event) { i0.ɵɵrestoreView(_r10); return i0.ɵɵresetView($event.stopPropagation()); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const image_r2 = i0.ɵɵnextContext(2).$implicit;
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵproperty("innerHTML", ctx_r2.descriptions[image_r2.index], i0.ɵɵsanitizeHtml);
} }
function GalleryImageComponent_div_1_div_2_Template(rf, ctx) { if (rf & 1) {
    const _r7 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 11);
    i0.ɵɵlistener("click", function GalleryImageComponent_div_1_div_2_Template_div_click_0_listener($event) { i0.ɵɵrestoreView(_r7); const image_r2 = i0.ɵɵnextContext().$implicit; const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.handleClick($event, image_r2.index)); });
    i0.ɵɵelementStart(1, "video", 12);
    i0.ɵɵelement(2, "source", 13);
    i0.ɵɵtext(3, " Your browser does not support the video tag. ");
    i0.ɵɵelementEnd();
    i0.ɵɵelementStart(4, "div", 6);
    i0.ɵɵtemplate(5, GalleryImageComponent_div_1_div_2_o_gallery_action_5_Template, 1, 3, "o-gallery-action", 7);
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(6, GalleryImageComponent_div_1_div_2_div_6_Template, 1, 1, "div", 8);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const image_r2 = i0.ɵɵnextContext().$implicit;
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵproperty("ngClass", i0.ɵɵpureFunction4(4, _c0$3, ctx_r2.selectedIndex === image_r2.index, ctx_r2.selectedIndex > image_r2.index, ctx_r2.selectedIndex < image_r2.index, ctx_r2.clickable));
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("src", image_r2.src, i0.ɵɵsanitizeUrl);
    i0.ɵɵadvance(3);
    i0.ɵɵproperty("ngForOf", ctx_r2.actions);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r2.showDescription && ctx_r2.descriptions[image_r2.index]);
} }
function GalleryImageComponent_div_1_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div");
    i0.ɵɵtemplate(1, GalleryImageComponent_div_1_div_1_Template, 4, 9, "div", 3)(2, GalleryImageComponent_div_1_div_2_Template, 7, 9, "div", 4);
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const image_r2 = ctx.$implicit;
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", image_r2.type === "image" || image_r2.type === "unknown");
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", image_r2.type === "video");
} }
function GalleryImageComponent_o_gallery_bullets_2_Template(rf, ctx) { if (rf & 1) {
    const _r11 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "o-gallery-bullets", 14);
    i0.ɵɵlistener("onChange", function GalleryImageComponent_o_gallery_bullets_2_Template_o_gallery_bullets_onChange_0_listener($event) { i0.ɵɵrestoreView(_r11); const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.show($event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵproperty("count", ctx_r2.images.length)("active", ctx_r2.selectedIndex);
} }
function GalleryImageComponent_o_gallery_arrows_3_Template(rf, ctx) { if (rf & 1) {
    const _r12 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "o-gallery-arrows", 15);
    i0.ɵɵlistener("onPrevClick", function GalleryImageComponent_o_gallery_arrows_3_Template_o_gallery_arrows_onPrevClick_0_listener() { i0.ɵɵrestoreView(_r12); const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.showPrev()); })("onNextClick", function GalleryImageComponent_o_gallery_arrows_3_Template_o_gallery_arrows_onNextClick_0_listener() { i0.ɵɵrestoreView(_r12); const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.showNext()); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵclassMapInterpolate1("o-gallery-image-size-", ctx_r2.size, "");
    i0.ɵɵproperty("prev-disabled", !ctx_r2.canShowPrev)("next-disabled", !ctx_r2.canShowNext)("arrow-prev-icon", ctx_r2.arrowPrevIcon)("arrow-next-icon", ctx_r2.arrowNextIcon);
} }
class GalleryImageComponent {
    constructor(elementRef, helperService) {
        this.elementRef = elementRef;
        this.helperService = helperService;
        this.selectedIndex = -1;
        this.onClick = new EventEmitter();
        this.onActiveChange = new EventEmitter();
        this.canChangeImage = true;
    }
    ngOnInit() {
        if (this.arrows && this.arrowsAutoHide) {
            this.arrows = false;
        }
        if (this.autoPlay) {
            this.startAutoPlay();
        }
    }
    ngOnChanges(changes) {
        if (changes.swipe) {
            this.helperService.manageSwipe(this.swipe, this.elementRef, 'image', () => this.showNext(), () => this.showPrev());
        }
    }
    onMouseEnter() {
        if (this.arrowsAutoHide && !this.arrows) {
            this.arrows = true;
        }
        if (this.autoPlay && this.autoPlayPauseOnHover) {
            this.stopAutoPlay();
        }
    }
    onMouseLeave() {
        if (this.arrowsAutoHide && this.arrows) {
            this.arrows = false;
        }
        if (this.autoPlay && this.autoPlayPauseOnHover) {
            this.startAutoPlay();
        }
    }
    reset(index) {
        this.selectedIndex = index;
    }
    getImages() {
        if (!this.images) {
            return [];
        }
        if (this.lazyLoading) {
            let indexes = [this.selectedIndex];
            let prevIndex = this.selectedIndex - 1;
            if (prevIndex === -1 && this.infinityMove) {
                indexes.push(this.images.length - 1);
            }
            else if (prevIndex >= 0) {
                indexes.push(prevIndex);
            }
            let nextIndex = this.selectedIndex + 1;
            if (nextIndex == this.images.length && this.infinityMove) {
                indexes.push(0);
            }
            else if (nextIndex < this.images.length) {
                indexes.push(nextIndex);
            }
            return this.images.filter((img, i) => indexes.indexOf(i) != -1);
        }
        else {
            return this.images;
        }
    }
    startAutoPlay() {
        this.stopAutoPlay();
        this.timer = setInterval(() => {
            if (!this.showNext()) {
                this.selectedIndex = -1;
                this.showNext();
            }
        }, this.autoPlayInterval);
    }
    stopAutoPlay() {
        if (this.timer) {
            clearInterval(this.timer);
        }
    }
    handleClick(event, index) {
        if (this.clickable) {
            this.onClick.emit(index);
            event.stopPropagation();
            event.preventDefault();
        }
    }
    show(index) {
        this.selectedIndex = index;
        this.onActiveChange.emit(this.selectedIndex);
        this.setChangeTimeout();
    }
    showNext() {
        if (this.canShowNext && this.canChangeImage) {
            this.selectedIndex++;
            if (this.selectedIndex === this.images.length) {
                this.selectedIndex = 0;
            }
            this.onActiveChange.emit(this.selectedIndex);
            this.setChangeTimeout();
            return true;
        }
        else {
            return false;
        }
    }
    showPrev() {
        if (this.canShowPrev && this.canChangeImage) {
            this.selectedIndex--;
            if (this.selectedIndex < 0) {
                this.selectedIndex = this.images.length - 1;
            }
            this.onActiveChange.emit(this.selectedIndex);
            this.setChangeTimeout();
        }
    }
    setChangeTimeout() {
        this.canChangeImage = false;
        let timeout = 1000;
        if (this.animation === GalleryAnimation.Slide
            || this.animation === GalleryAnimation.Fade) {
            timeout = 500;
        }
        setTimeout(() => {
            this.canChangeImage = true;
        }, timeout);
    }
    get canShowNext() {
        return this.infinityMove || (this.selectedIndex < this.images.length - 1);
    }
    get canShowPrev() {
        return this.infinityMove || (this.selectedIndex > 0);
    }
    getFileType(fileSource) {
        return this.helperService.getFileType(fileSource);
    }
    static { this.ɵfac = function GalleryImageComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || GalleryImageComponent)(i0.ɵɵdirectiveInject(i0.ElementRef), i0.ɵɵdirectiveInject(GalleryHelperService)); }; }
    static { this.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: GalleryImageComponent, selectors: [["o-gallery-image"]], hostBindings: function GalleryImageComponent_HostBindings(rf, ctx) { if (rf & 1) {
            i0.ɵɵlistener("mouseenter", function GalleryImageComponent_mouseenter_HostBindingHandler() { return ctx.onMouseEnter(); })("mouseleave", function GalleryImageComponent_mouseleave_HostBindingHandler() { return ctx.onMouseLeave(); });
        } }, inputs: { images: "images", clickable: "clickable", selectedIndex: [0, "selected-index", "selectedIndex"], arrows: "arrows", arrowsAutoHide: [0, "arrows-auto-hide", "arrowsAutoHide"], swipe: "swipe", animation: "animation", size: "size", arrowPrevIcon: [0, "arrow-prev-icon", "arrowPrevIcon"], arrowNextIcon: [0, "arrow-next-icon", "arrowNextIcon"], autoPlay: [0, "auto-play", "autoPlay"], autoPlayInterval: [0, "auto-play-interval", "autoPlayInterval"], autoPlayPauseOnHover: [0, "auto-play-pause-on-hover", "autoPlayPauseOnHover"], infinityMove: [0, "infinity-move", "infinityMove"], lazyLoading: [0, "lazy-loading", "lazyLoading"], actions: "actions", descriptions: "descriptions", showDescription: [0, "show-description", "showDescription"], bullets: "bullets" }, outputs: { onClick: "onClick", onActiveChange: "onActiveChange" }, standalone: true, features: [i0.ɵɵNgOnChangesFeature, i0.ɵɵStandaloneFeature], decls: 4, vars: 7, consts: [[4, "ngFor", "ngForOf"], [3, "count", "active", "onChange", 4, "ngIf"], [3, "class", "prev-disabled", "next-disabled", "arrow-prev-icon", "arrow-next-icon", "onPrevClick", "onNextClick", 4, "ngIf"], ["class", "o-gallery-image", 3, "oGalleryBackgroundImg", "ngClass", "click", 4, "ngIf"], ["class", "o-gallery-image", 3, "ngClass", "click", 4, "ngIf"], [1, "o-gallery-image", 3, "click", "oGalleryBackgroundImg", "ngClass"], [1, "o-gallery-icons-wrapper"], [3, "icon", "disabled", "titleText", "onClick", 4, "ngFor", "ngForOf"], ["class", "o-gallery-image-text", 3, "innerHTML", "click", 4, "ngIf"], [3, "onClick", "icon", "disabled", "titleText"], [1, "o-gallery-image-text", 3, "click", "innerHTML"], [1, "o-gallery-image", 3, "click", "ngClass"], ["controls", "", 2, "width", "100%", "height", "100%"], [3, "src"], [3, "onChange", "count", "active"], [3, "onPrevClick", "onNextClick", "prev-disabled", "next-disabled", "arrow-prev-icon", "arrow-next-icon"]], template: function GalleryImageComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div");
            i0.ɵɵtemplate(1, GalleryImageComponent_div_1_Template, 3, 2, "div", 0);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(2, GalleryImageComponent_o_gallery_bullets_2_Template, 1, 2, "o-gallery-bullets", 1)(3, GalleryImageComponent_o_gallery_arrows_3_Template, 1, 7, "o-gallery-arrows", 2);
        } if (rf & 2) {
            i0.ɵɵclassMapInterpolate2("o-gallery-image-wrapper o-gallery-animation-", ctx.animation, " o-gallery-image-size-", ctx.size, "");
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngForOf", ctx.images);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.bullets);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.arrows);
        } }, dependencies: [CommonModule, i3.NgClass, i3.NgForOf, i3.NgIf, GalleryActionComponent, GalleryArrowsComponent, GalleryBulletsComponent, GalleryImageDirective], styles: ["[_nghost-%COMP%]{width:100%;display:inline-block;position:relative}.o-gallery-image-wrapper[_ngcontent-%COMP%]{width:100%;height:100%;position:absolute;left:0;top:0;overflow:hidden}.o-gallery-image[_ngcontent-%COMP%]{background-position:center;background-repeat:no-repeat;height:100%;width:100%;position:absolute;top:0}.o-gallery-image.o-gallery-active[_ngcontent-%COMP%]{z-index:1000}.o-gallery-image-size-cover[_ngcontent-%COMP%]   .o-gallery-image[_ngcontent-%COMP%]{background-size:cover}.o-gallery-image-size-contain[_ngcontent-%COMP%]   .o-gallery-image[_ngcontent-%COMP%]{background-size:contain}.o-gallery-animation-fade[_ngcontent-%COMP%]   .o-gallery-image[_ngcontent-%COMP%]{left:0;opacity:0;transition:.5s ease-in-out}.o-gallery-animation-fade[_ngcontent-%COMP%]   .o-gallery-image.o-gallery-active[_ngcontent-%COMP%]{opacity:1}.o-gallery-animation-slide[_ngcontent-%COMP%]   .o-gallery-image[_ngcontent-%COMP%]{transition:.5s ease-in-out}.o-gallery-animation-slide[_ngcontent-%COMP%]   .o-gallery-image.o-gallery-active[_ngcontent-%COMP%]{left:0}.o-gallery-animation-slide[_ngcontent-%COMP%]   .o-gallery-image.o-gallery-inactive-left[_ngcontent-%COMP%]{left:-100%}.o-gallery-animation-slide[_ngcontent-%COMP%]   .o-gallery-image.o-gallery-inactive-right[_ngcontent-%COMP%]{left:100%}.o-gallery-animation-rotate[_ngcontent-%COMP%]   .o-gallery-image[_ngcontent-%COMP%]{transition:1s ease;transform:scale(3.5) rotate(90deg);left:0;opacity:0}.o-gallery-animation-rotate[_ngcontent-%COMP%]   .o-gallery-image.o-gallery-active[_ngcontent-%COMP%]{transform:scale(1) rotate(0);opacity:1}.o-gallery-animation-zoom[_ngcontent-%COMP%]   .o-gallery-image[_ngcontent-%COMP%]{transition:1s ease;transform:scale(2.5);left:0;opacity:0}.o-gallery-animation-zoom[_ngcontent-%COMP%]   .o-gallery-image.o-gallery-active[_ngcontent-%COMP%]{transform:scale(1);opacity:1}.o-gallery-image-text[_ngcontent-%COMP%]{width:100%;background:#000000b3;padding:10px;text-align:center;color:#fff;font-size:16px;position:absolute;bottom:0;z-index:10}"] }); }
}
__decorate([
    BooleanInputConverter(),
    __metadata("design:type", Boolean)
], GalleryImageComponent.prototype, "clickable", void 0);
__decorate([
    BooleanInputConverter(),
    __metadata("design:type", Boolean)
], GalleryImageComponent.prototype, "arrows", void 0);
__decorate([
    BooleanInputConverter(),
    __metadata("design:type", Boolean)
], GalleryImageComponent.prototype, "arrowsAutoHide", void 0);
__decorate([
    BooleanInputConverter(),
    __metadata("design:type", Boolean)
], GalleryImageComponent.prototype, "swipe", void 0);
__decorate([
    BooleanInputConverter(),
    __metadata("design:type", Boolean)
], GalleryImageComponent.prototype, "autoPlay", void 0);
__decorate([
    BooleanInputConverter(),
    __metadata("design:type", Boolean)
], GalleryImageComponent.prototype, "autoPlayPauseOnHover", void 0);
__decorate([
    BooleanInputConverter(),
    __metadata("design:type", Boolean)
], GalleryImageComponent.prototype, "infinityMove", void 0);
__decorate([
    BooleanInputConverter(),
    __metadata("design:type", Boolean)
], GalleryImageComponent.prototype, "lazyLoading", void 0);
__decorate([
    BooleanInputConverter(),
    __metadata("design:type", Boolean)
], GalleryImageComponent.prototype, "showDescription", void 0);
__decorate([
    BooleanInputConverter(),
    __metadata("design:type", Boolean)
], GalleryImageComponent.prototype, "bullets", void 0);
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(GalleryImageComponent, [{
        type: Component,
        args: [{ selector: 'o-gallery-image', standalone: true, imports: [CommonModule, GalleryActionComponent, GalleryArrowsComponent, GalleryBulletsComponent, GalleryImageDirective], inputs: [
                    'images',
                    'clickable',
                    'selectedIndex : selected-index',
                    'arrows',
                    'arrowsAutoHide : arrows-auto-hide',
                    'swipe',
                    'animation',
                    'size',
                    'arrowPrevIcon : arrow-prev-icon',
                    'arrowNextIcon : arrow-next-icon',
                    'autoPlay : auto-play',
                    'autoPlayInterval : auto-play-interval',
                    'autoPlayPauseOnHover : auto-play-pause-on-hover',
                    'infinityMove : infinity-move',
                    'lazyLoading : lazy-loading',
                    'actions',
                    'descriptions',
                    'showDescription : show-description',
                    'bullets'
                ], outputs: [
                    'onClick',
                    'onActiveChange'
                ], template: "<div class=\"o-gallery-image-wrapper o-gallery-animation-{{animation}} o-gallery-image-size-{{size}}\">\r\n  <div *ngFor=\"let image of images; let i = index;\">\r\n    <div *ngIf=\"image.type === 'image' || image.type === 'unknown'\" [oGalleryBackgroundImg]=\"image.src\" class=\"o-gallery-image\"\r\n      [ngClass]=\"{ 'o-gallery-active': selectedIndex === image.index, 'o-gallery-inactive-left': selectedIndex > image.index, 'o-gallery-inactive-right': selectedIndex < image.index, 'o-gallery-clickable': clickable }\"\r\n      (click)=\"handleClick($event, image.index)\">\r\n      <div class=\"o-gallery-icons-wrapper\">\r\n        <o-gallery-action *ngFor=\"let action of actions\" [icon]=\"action.icon\" [disabled]=\"action.disabled\" [titleText]=\"action.titleText\"\r\n          (onClick)=\"action.onClick($event, image.index)\"></o-gallery-action>\r\n      </div>\r\n      <div class=\"o-gallery-image-text\" *ngIf=\"showDescription && descriptions[image.index]\" [innerHTML]=\"descriptions[image.index]\"\r\n        (click)=\"$event.stopPropagation()\"></div>\r\n    </div>\r\n    <div *ngIf=\"image.type === 'video'\" class=\"o-gallery-image\"\r\n      [ngClass]=\"{ 'o-gallery-active': selectedIndex === image.index, 'o-gallery-inactive-left': selectedIndex > image.index, 'o-gallery-inactive-right': selectedIndex < image.index, 'o-gallery-clickable': clickable }\"\r\n      (click)=\"handleClick($event, image.index)\">\r\n      <video controls style=\"width: 100%; height: 100%;\">\r\n        <source [src]=\"image.src\">\r\n        Your browser does not support the video tag.\r\n      </video>\r\n      <div class=\"o-gallery-icons-wrapper\">\r\n        <o-gallery-action *ngFor=\"let action of actions\" [icon]=\"action.icon\" [disabled]=\"action.disabled\" [titleText]=\"action.titleText\"\r\n          (onClick)=\"action.onClick($event, image.index)\"></o-gallery-action>\r\n      </div>\r\n      <div class=\"o-gallery-image-text\" *ngIf=\"showDescription && descriptions[image.index]\" [innerHTML]=\"descriptions[image.index]\"\r\n        (click)=\"$event.stopPropagation()\"></div>\r\n    </div>\r\n  </div>\r\n</div>\r\n\r\n<o-gallery-bullets *ngIf=\"bullets\" [count]=\"images.length\" [active]=\"selectedIndex\" (onChange)=\"show($event)\"></o-gallery-bullets>\r\n\r\n<o-gallery-arrows class=\"o-gallery-image-size-{{size}}\" *ngIf=\"arrows\" (onPrevClick)=\"showPrev()\" (onNextClick)=\"showNext()\"\r\n  [prev-disabled]=\"!canShowPrev\" [next-disabled]=\"!canShowNext\" [arrow-prev-icon]=\"arrowPrevIcon\" [arrow-next-icon]=\"arrowNextIcon\">\r\n</o-gallery-arrows>\r\n", styles: [":host{width:100%;display:inline-block;position:relative}.o-gallery-image-wrapper{width:100%;height:100%;position:absolute;left:0;top:0;overflow:hidden}.o-gallery-image{background-position:center;background-repeat:no-repeat;height:100%;width:100%;position:absolute;top:0}.o-gallery-image.o-gallery-active{z-index:1000}.o-gallery-image-size-cover .o-gallery-image{background-size:cover}.o-gallery-image-size-contain .o-gallery-image{background-size:contain}.o-gallery-animation-fade .o-gallery-image{left:0;opacity:0;transition:.5s ease-in-out}.o-gallery-animation-fade .o-gallery-image.o-gallery-active{opacity:1}.o-gallery-animation-slide .o-gallery-image{transition:.5s ease-in-out}.o-gallery-animation-slide .o-gallery-image.o-gallery-active{left:0}.o-gallery-animation-slide .o-gallery-image.o-gallery-inactive-left{left:-100%}.o-gallery-animation-slide .o-gallery-image.o-gallery-inactive-right{left:100%}.o-gallery-animation-rotate .o-gallery-image{transition:1s ease;transform:scale(3.5) rotate(90deg);left:0;opacity:0}.o-gallery-animation-rotate .o-gallery-image.o-gallery-active{transform:scale(1) rotate(0);opacity:1}.o-gallery-animation-zoom .o-gallery-image{transition:1s ease;transform:scale(2.5);left:0;opacity:0}.o-gallery-animation-zoom .o-gallery-image.o-gallery-active{transform:scale(1);opacity:1}.o-gallery-image-text{width:100%;background:#000000b3;padding:10px;text-align:center;color:#fff;font-size:16px;position:absolute;bottom:0;z-index:10}\n"] }]
    }], () => [{ type: i0.ElementRef }, { type: GalleryHelperService }], { images: [{
            type: Input
        }], clickable: [], arrows: [], arrowsAutoHide: [], swipe: [], autoPlay: [], autoPlayPauseOnHover: [], infinityMove: [], lazyLoading: [], showDescription: [], bullets: [], onMouseEnter: [{
            type: HostListener,
            args: ['mouseenter']
        }], onMouseLeave: [{
            type: HostListener,
            args: ['mouseleave']
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(GalleryImageComponent, { className: "GalleryImageComponent", filePath: "lib\\components\\gallery-image\\o-gallery-image.component.ts", lineNumber: 46 }); })();

const _c0$2 = ["previewImage"];
function GalleryPreviewComponent_o_gallery_arrows_0_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "o-gallery-arrows", 17);
    i0.ɵɵlistener("onPrevClick", function GalleryPreviewComponent_o_gallery_arrows_0_Template_o_gallery_arrows_onPrevClick_0_listener() { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.showPrev()); })("onNextClick", function GalleryPreviewComponent_o_gallery_arrows_0_Template_o_gallery_arrows_onNextClick_0_listener() { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.showNext()); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("prev-disabled", !ctx_r1.canShowPrev)("next-disabled", !ctx_r1.canShowNext)("arrow-prev-icon", ctx_r1.arrowPrevIcon)("arrow-next-icon", ctx_r1.arrowNextIcon);
} }
function GalleryPreviewComponent_o_gallery_action_3_Template(rf, ctx) { if (rf & 1) {
    const _r3 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "o-gallery-action", 18);
    i0.ɵɵlistener("onClick", function GalleryPreviewComponent_o_gallery_action_3_Template_o_gallery_action_onClick_0_listener($event) { const action_r4 = i0.ɵɵrestoreView(_r3).$implicit; const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(action_r4.onClick($event, ctx_r1.index)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const action_r4 = ctx.$implicit;
    i0.ɵɵproperty("icon", action_r4.icon)("disabled", action_r4.disabled)("titleText", action_r4.titleText);
} }
function GalleryPreviewComponent_a_4_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "a", 19)(1, "em", 20);
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("href", ctx_r1.src, i0.ɵɵsanitizeUrl);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate(ctx_r1.downloadIcon);
} }
function GalleryPreviewComponent_o_gallery_action_5_Template(rf, ctx) { if (rf & 1) {
    const _r5 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "o-gallery-action", 21);
    i0.ɵɵlistener("onClick", function GalleryPreviewComponent_o_gallery_action_5_Template_o_gallery_action_onClick_0_listener() { i0.ɵɵrestoreView(_r5); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.zoomOut()); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("icon", ctx_r1.zoomOutIcon)("disabled", !ctx_r1.canZoomOut);
} }
function GalleryPreviewComponent_o_gallery_action_6_Template(rf, ctx) { if (rf & 1) {
    const _r6 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "o-gallery-action", 21);
    i0.ɵɵlistener("onClick", function GalleryPreviewComponent_o_gallery_action_6_Template_o_gallery_action_onClick_0_listener() { i0.ɵɵrestoreView(_r6); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.zoomIn()); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("icon", ctx_r1.zoomInIcon)("disabled", !ctx_r1.canZoomIn);
} }
function GalleryPreviewComponent_o_gallery_action_7_Template(rf, ctx) { if (rf & 1) {
    const _r7 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "o-gallery-action", 8);
    i0.ɵɵlistener("onClick", function GalleryPreviewComponent_o_gallery_action_7_Template_o_gallery_action_onClick_0_listener() { i0.ɵɵrestoreView(_r7); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.rotateLeft()); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("icon", ctx_r1.rotateLeftIcon);
} }
function GalleryPreviewComponent_o_gallery_action_8_Template(rf, ctx) { if (rf & 1) {
    const _r8 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "o-gallery-action", 8);
    i0.ɵɵlistener("onClick", function GalleryPreviewComponent_o_gallery_action_8_Template_o_gallery_action_onClick_0_listener() { i0.ɵɵrestoreView(_r8); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.rotateRight()); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("icon", ctx_r1.rotateRightIcon);
} }
function GalleryPreviewComponent_o_gallery_action_9_Template(rf, ctx) { if (rf & 1) {
    const _r9 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "o-gallery-action", 8);
    i0.ɵɵlistener("onClick", function GalleryPreviewComponent_o_gallery_action_9_Template_o_gallery_action_onClick_0_listener() { i0.ɵɵrestoreView(_r9); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.manageFullscreen()); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("icon", ctx_r1.fullscreenIcon);
} }
function GalleryPreviewComponent_img_16_Template(rf, ctx) { if (rf & 1) {
    const _r10 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "img", 22, 0);
    i0.ɵɵlistener("click", function GalleryPreviewComponent_img_16_Template_img_click_0_listener($event) { i0.ɵɵrestoreView(_r10); return i0.ɵɵresetView($event.stopPropagation()); })("mouseenter", function GalleryPreviewComponent_img_16_Template_img_mouseenter_0_listener() { i0.ɵɵrestoreView(_r10); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.imageMouseEnter()); })("mouseleave", function GalleryPreviewComponent_img_16_Template_img_mouseleave_0_listener() { i0.ɵɵrestoreView(_r10); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.imageMouseLeave()); })("mousedown", function GalleryPreviewComponent_img_16_Template_img_mousedown_0_listener($event) { i0.ɵɵrestoreView(_r10); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.mouseDownHandler($event)); })("touchstart", function GalleryPreviewComponent_img_16_Template_img_touchstart_0_listener($event) { i0.ɵɵrestoreView(_r10); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.mouseDownHandler($event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵstyleProp("transform", ctx_r1.getTransform)("left", ctx_r1.positionLeft + "px")("top", ctx_r1.positionTop + "px")("aspect-ratio", ctx_r1.aspectRatio);
    i0.ɵɵclassProp("o-gallery-active", !ctx_r1.loading)("animation", ctx_r1.animation)("o-gallery-grab", ctx_r1.canDragOnZoom);
    i0.ɵɵproperty("src", ctx_r1.src, i0.ɵɵsanitizeUrl);
} }
function GalleryPreviewComponent_video_17_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "video", 23, 0);
    i0.ɵɵelement(2, "source", 24);
    i0.ɵɵtext(3, " Your browser does not support the video tag. ");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("src", ctx_r1.src, i0.ɵɵsanitizeUrl);
} }
function GalleryPreviewComponent_o_gallery_bullets_18_Template(rf, ctx) { if (rf & 1) {
    const _r11 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "o-gallery-bullets", 25);
    i0.ɵɵlistener("onChange", function GalleryPreviewComponent_o_gallery_bullets_18_Template_o_gallery_bullets_onChange_0_listener($event) { i0.ɵɵrestoreView(_r11); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.showAtIndex($event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("count", ctx_r1.images.length)("active", ctx_r1.index);
} }
function GalleryPreviewComponent_div_19_Template(rf, ctx) { if (rf & 1) {
    const _r12 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div", 26);
    i0.ɵɵlistener("click", function GalleryPreviewComponent_div_19_Template_div_click_0_listener($event) { i0.ɵɵrestoreView(_r12); return i0.ɵɵresetView($event.stopPropagation()); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵproperty("innerHTML", ctx_r1.description, i0.ɵɵsanitizeHtml);
} }
class GalleryPreviewComponent {
    constructor(sanitization, elementRef, helperService, renderer, changeDetectorRef) {
        this.sanitization = sanitization;
        this.elementRef = elementRef;
        this.helperService = helperService;
        this.renderer = renderer;
        this.changeDetectorRef = changeDetectorRef;
        this.showSpinner = false;
        this.positionLeft = 0;
        this.positionTop = 0;
        this.zoomValue = 1;
        this.loading = false;
        this.rotateValue = 0;
        this.index = 0;
        this.onOpen = new EventEmitter();
        this.onClose = new EventEmitter();
        this.onActiveChange = new EventEmitter();
        this.isOpen = false;
        this.initialX = 0;
        this.initialY = 0;
        this.initialLeft = 0;
        this.initialTop = 0;
        this.isMove = false;
    }
    ngOnInit() {
        if (this.arrows && this.arrowsAutoHide) {
            this.arrows = false;
        }
    }
    ngOnChanges(changes) {
        if (changes.swipe) {
            this.helperService.manageSwipe(this.swipe, this.elementRef, 'preview', () => this.showNext(), () => this.showPrev());
        }
    }
    ngOnDestroy() {
        if (this.keyDownListener) {
            this.keyDownListener();
        }
    }
    onMouseEnter() {
        if (this.arrowsAutoHide && !this.arrows) {
            this.arrows = true;
        }
    }
    onMouseLeave() {
        if (this.arrowsAutoHide && this.arrows) {
            this.arrows = false;
        }
    }
    onKeyDown(e) {
        if (this.isOpen) {
            if (this.keyboardNavigation) {
                if (this.isKeyboardPrev(e)) {
                    this.showPrev();
                }
                else if (this.isKeyboardNext(e)) {
                    this.showNext();
                }
            }
            if (this.closeOnEsc && this.isKeyboardEsc(e)) {
                this.close();
            }
        }
    }
    open(index) {
        this.onOpen.emit();
        this.index = index;
        this.isOpen = true;
        this.show(true);
        if (this.forceFullscreen) {
            this.manageFullscreen();
        }
        this.keyDownListener = this.renderer.listen('window', 'keydown', (e) => this.onKeyDown(e));
    }
    close() {
        this.isOpen = false;
        this.closeFullscreen();
        this.onClose.emit();
        this.stopAutoPlay();
        if (this.keyDownListener) {
            this.keyDownListener();
        }
    }
    imageMouseEnter() {
        if (this.autoPlay && this.autoPlayPauseOnHover) {
            this.stopAutoPlay();
        }
    }
    imageMouseLeave() {
        if (this.autoPlay && this.autoPlayPauseOnHover) {
            this.startAutoPlay();
        }
    }
    startAutoPlay() {
        if (this.autoPlay) {
            this.stopAutoPlay();
            this.timer = setTimeout(() => {
                if (!this.showNext()) {
                    this.index = -1;
                    this.showNext();
                }
            }, this.autoPlayInterval);
        }
    }
    stopAutoPlay() {
        if (this.timer) {
            clearTimeout(this.timer);
        }
    }
    showAtIndex(index) {
        this.index = index;
        this.show();
    }
    showNext() {
        if (this.canShowNext) {
            this.index++;
            if (this.index === this.images.length) {
                this.index = 0;
            }
            this.show();
            return true;
        }
        else {
            return false;
        }
    }
    showPrev() {
        if (this.canShowPrev) {
            this.index--;
            if (this.index < 0) {
                this.index = this.images.length - 1;
            }
            this.show();
        }
    }
    get canShowNext() {
        if (this.loading) {
            return false;
        }
        else if (this.images) {
            return this.infinityMove || this.index < this.images.length - 1 ? true : false;
        }
        else {
            return false;
        }
    }
    get canShowPrev() {
        if (this.loading) {
            return false;
        }
        else if (this.images) {
            return this.infinityMove || this.index > 0 ? true : false;
        }
        else {
            return false;
        }
    }
    manageFullscreen() {
        if (this.fullscreen || this.forceFullscreen) {
            const doc = document;
            if (!doc.fullscreenElement && !doc.mozFullScreenElement
                && !doc.webkitFullscreenElement && !doc.msFullscreenElement) {
                this.openFullscreen();
            }
            else {
                this.closeFullscreen();
            }
        }
    }
    getSafeUrl(image) {
        return this.sanitization.bypassSecurityTrustUrl(image);
    }
    getFileType(fileSource) {
        return this.helperService.getFileType(fileSource);
    }
    zoomIn() {
        if (this.canZoomIn) {
            this.zoomValue += this.zoomStep;
            if (this.zoomValue > this.zoomMax) {
                this.zoomValue = this.zoomMax;
            }
        }
    }
    zoomOut() {
        if (this.canZoomOut) {
            this.zoomValue -= this.zoomStep;
            if (this.zoomValue < this.zoomMin) {
                this.zoomValue = this.zoomMin;
            }
            if (this.zoomValue <= 1) {
                this.resetPosition();
            }
        }
    }
    rotateLeft() {
        this.rotateValue -= 90;
    }
    rotateRight() {
        this.rotateValue += 90;
    }
    get getTransform() {
        return this.sanitization.bypassSecurityTrustStyle('scale(' + this.zoomValue + ') rotate(' + this.rotateValue + 'deg)');
    }
    get canZoomIn() {
        return this.zoomValue < this.zoomMax ? true : false;
    }
    get canZoomOut() {
        return this.zoomValue > this.zoomMin ? true : false;
    }
    get canDragOnZoom() {
        return this.zoom && this.zoomValue > 1;
    }
    mouseDownHandler(e) {
        if (this.canDragOnZoom) {
            this.initialX = this.getClientX(e);
            this.initialY = this.getClientY(e);
            this.initialLeft = this.positionLeft;
            this.initialTop = this.positionTop;
            this.isMove = true;
            e.preventDefault();
        }
    }
    mouseUpHandler(_e) {
        this.isMove = false;
    }
    mouseMoveHandler(e) {
        if (this.isMove) {
            this.positionLeft = this.initialLeft + (this.getClientX(e) - this.initialX);
            this.positionTop = this.initialTop + (this.getClientY(e) - this.initialY);
        }
    }
    getClientX(e) {
        return e.touches && e.touches.length ? e.touches[0].clientX : e.clientX;
    }
    getClientY(e) {
        return e.touches && e.touches.length ? e.touches[0].clientY : e.clientY;
    }
    resetPosition() {
        if (this.zoom) {
            this.positionLeft = 0;
            this.positionTop = 0;
        }
    }
    isKeyboardNext(e) {
        return e.keyCode === 39 ? true : false;
    }
    isKeyboardPrev(e) {
        return e.keyCode === 37 ? true : false;
    }
    isKeyboardEsc(e) {
        return e.keyCode === 27 ? true : false;
    }
    openFullscreen() {
        const element = document.documentElement;
        if (element.requestFullscreen) {
            element.requestFullscreen();
        }
        else if (element.msRequestFullscreen) {
            element.msRequestFullscreen();
        }
        else if (element.mozRequestFullScreen) {
            element.mozRequestFullScreen();
        }
        else if (element.webkitRequestFullscreen) {
            element.webkitRequestFullscreen();
        }
    }
    closeFullscreen() {
        if (this.isFullscreen()) {
            const doc = document;
            if (doc.exitFullscreen) {
                doc.exitFullscreen();
            }
            else if (doc.msExitFullscreen) {
                doc.msExitFullscreen();
            }
            else if (doc.mozCancelFullScreen) {
                doc.mozCancelFullScreen();
            }
            else if (doc.webkitExitFullscreen) {
                doc.webkitExitFullscreen();
            }
        }
    }
    isFullscreen() {
        const doc = document;
        return doc.fullscreenElement || doc.webkitFullscreenElement
            || doc.mozFullScreenElement || doc.msFullscreenElement;
    }
    show(first = false) {
        this.loading = true;
        this.stopAutoPlay();
        this.onActiveChange.emit(this.index);
        if (first || !this.animation) {
            this._show();
        }
        else {
            setTimeout(() => this._show(), 600);
        }
    }
    _show() {
        this.zoomValue = 1;
        this.rotateValue = 0;
        this.resetPosition();
        this.src = this.getSafeUrl(this.images[this.index]);
        this.type = this.getFileType(this.images[this.index]);
        this.srcIndex = this.index;
        this.description = this.descriptions[this.index];
        this.changeDetectorRef.markForCheck();
        setTimeout(() => {
            if (this.isLoaded(this.previewImage.nativeElement) || this.type === 'video') {
                this.loading = false;
                this.startAutoPlay();
                this.changeDetectorRef.markForCheck();
            }
            else {
                setTimeout(() => {
                    if (this.loading) {
                        this.showSpinner = true;
                        this.changeDetectorRef.markForCheck();
                    }
                });
                this.previewImage.nativeElement.onload = () => {
                    this.loading = false;
                    this.showSpinner = false;
                    this.previewImage.nativeElement.onload = null;
                    this.startAutoPlay();
                    this.changeDetectorRef.markForCheck();
                };
            }
        });
    }
    isLoaded(img) {
        if (!img.complete) {
            return false;
        }
        if (typeof img.naturalWidth !== 'undefined' && img.naturalWidth === 0) {
            return false;
        }
        return true;
    }
    static { this.ɵfac = function GalleryPreviewComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || GalleryPreviewComponent)(i0.ɵɵdirectiveInject(i1.DomSanitizer), i0.ɵɵdirectiveInject(i0.ElementRef), i0.ɵɵdirectiveInject(GalleryHelperService), i0.ɵɵdirectiveInject(i0.Renderer2), i0.ɵɵdirectiveInject(i0.ChangeDetectorRef)); }; }
    static { this.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: GalleryPreviewComponent, selectors: [["o-gallery-preview"]], viewQuery: function GalleryPreviewComponent_Query(rf, ctx) { if (rf & 1) {
            i0.ɵɵviewQuery(_c0$2, 5);
        } if (rf & 2) {
            let _t;
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.previewImage = _t.first);
        } }, hostVars: 4, hostBindings: function GalleryPreviewComponent_HostBindings(rf, ctx) { if (rf & 1) {
            i0.ɵɵlistener("mouseenter", function GalleryPreviewComponent_mouseenter_HostBindingHandler() { return ctx.onMouseEnter(); })("mouseleave", function GalleryPreviewComponent_mouseleave_HostBindingHandler() { return ctx.onMouseLeave(); });
        } if (rf & 2) {
            i0.ɵɵclassProp("o-gallery-preview", true)("o-gallery-active", ctx.previewEnabled);
        } }, inputs: { images: "images", descriptions: "descriptions", showDescription: [0, "show-description", "showDescription"], arrows: "arrows", arrowsAutoHide: [0, "arrows-auto-hide", "arrowsAutoHide"], swipe: "swipe", fullscreen: "fullscreen", forceFullscreen: [0, "force-fullscreen", "forceFullscreen"], closeOnClick: [0, "close-on-click", "closeOnClick"], closeOnEsc: [0, "close-on-esc", "closeOnEsc"], keyboardNavigation: [0, "keyboard-navigation", "keyboardNavigation"], arrowPrevIcon: [0, "arrow-prev-icon", "arrowPrevIcon"], arrowNextIcon: [0, "arrow-next-icon", "arrowNextIcon"], closeIcon: [0, "close-icon", "closeIcon"], fullscreenIcon: [0, "fullscreen-icon", "fullscreenIcon"], spinnerIcon: [0, "spinner-icon", "spinnerIcon"], autoPlay: [0, "auto-play", "autoPlay"], autoPlayInterval: [0, "auto-play-interval", "autoPlayInterval"], autoPlayPauseOnHover: [0, "auto-play-pause-on-hover", "autoPlayPauseOnHover"], infinityMove: [0, "infinity-move", "infinityMove"], zoom: "zoom", zoomStep: [0, "zoom-step", "zoomStep"], zoomMax: [0, "zoom-max", "zoomMax"], zoomMin: [0, "zoom-min", "zoomMin"], zoomInIcon: [0, "zoom-in-icon", "zoomInIcon"], zoomOutIcon: [0, "zoom-out-icon", "zoomOutIcon"], animation: "animation", actions: "actions", rotate: "rotate", rotateLeftIcon: [0, "rotate-left-icon", "rotateLeftIcon"], rotateRightIcon: [0, "rotate-right-icon", "rotateRightIcon"], download: "download", downloadIcon: [0, "download-icon", "downloadIcon"], bullets: "bullets", previewEnabled: "previewEnabled" }, outputs: { onOpen: "onOpen", onClose: "onClose", onActiveChange: "onActiveChange" }, standalone: true, features: [i0.ɵɵProvidersFeature([GalleryHelperService]), i0.ɵɵNgOnChangesFeature, i0.ɵɵStandaloneFeature], decls: 20, vars: 16, consts: [["previewImage", ""], [3, "prev-disabled", "next-disabled", "arrow-prev-icon", "arrow-next-icon", "onPrevClick", "onNextClick", 4, "ngIf"], [1, "o-gallery-preview-top"], [1, "o-gallery-preview-icons"], [3, "icon", "disabled", "titleText", "onClick", 4, "ngFor", "ngForOf"], ["class", "o-gallery-icon", "aria-hidden", "true", "download", "", 3, "href", 4, "ngIf"], [3, "icon", "disabled", "onClick", 4, "ngIf"], [3, "icon", "onClick", 4, "ngIf"], [3, "onClick", "icon"], [1, "ngx-spinner-wrapper", "o-gallery-center"], ["aria-hidden", "true", 1, "o-gallery-icon", "o-gallery-spinner"], [1, "o-gallery-preview-wrapper", 3, "click", "mouseup", "mousemove", "touchend", "touchmove"], [1, "o-gallery-preview-img-wrapper"], ["alt", "previewImage", "class", "o-gallery-preview-img o-gallery-center", 3, "src", "o-gallery-active", "animation", "o-gallery-grab", "transform", "left", "top", "aspectRatio", "click", "mouseenter", "mouseleave", "mousedown", "touchstart", 4, "ngIf"], ["class", "o-gallery-preview-video o-gallery-center", "controls", "", "style", "width: 50%; height: 50%;", 4, "ngIf"], [3, "count", "active", "onChange", 4, "ngIf"], ["class", "o-gallery-preview-text", 3, "innerHTML", "click", 4, "ngIf"], [3, "onPrevClick", "onNextClick", "prev-disabled", "next-disabled", "arrow-prev-icon", "arrow-next-icon"], [3, "onClick", "icon", "disabled", "titleText"], ["aria-hidden", "true", "download", "", 1, "o-gallery-icon", 3, "href"], [1, "o-gallery-icon-content"], [3, "onClick", "icon", "disabled"], ["alt", "previewImage", 1, "o-gallery-preview-img", "o-gallery-center", 3, "click", "mouseenter", "mouseleave", "mousedown", "touchstart", "src"], ["controls", "", 1, "o-gallery-preview-video", "o-gallery-center", 2, "width", "50%", "height", "50%"], [3, "src"], [3, "onChange", "count", "active"], [1, "o-gallery-preview-text", 3, "click", "innerHTML"]], template: function GalleryPreviewComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵtemplate(0, GalleryPreviewComponent_o_gallery_arrows_0_Template, 1, 4, "o-gallery-arrows", 1);
            i0.ɵɵelementStart(1, "div", 2)(2, "div", 3);
            i0.ɵɵtemplate(3, GalleryPreviewComponent_o_gallery_action_3_Template, 1, 3, "o-gallery-action", 4)(4, GalleryPreviewComponent_a_4_Template, 3, 2, "a", 5)(5, GalleryPreviewComponent_o_gallery_action_5_Template, 1, 2, "o-gallery-action", 6)(6, GalleryPreviewComponent_o_gallery_action_6_Template, 1, 2, "o-gallery-action", 6)(7, GalleryPreviewComponent_o_gallery_action_7_Template, 1, 1, "o-gallery-action", 7)(8, GalleryPreviewComponent_o_gallery_action_8_Template, 1, 1, "o-gallery-action", 7)(9, GalleryPreviewComponent_o_gallery_action_9_Template, 1, 1, "o-gallery-action", 7);
            i0.ɵɵelementStart(10, "o-gallery-action", 8);
            i0.ɵɵlistener("onClick", function GalleryPreviewComponent_Template_o_gallery_action_onClick_10_listener() { return ctx.close(); });
            i0.ɵɵelementEnd()()();
            i0.ɵɵelementStart(11, "div", 9)(12, "i", 10);
            i0.ɵɵtext(13);
            i0.ɵɵelementEnd()();
            i0.ɵɵelementStart(14, "div", 11);
            i0.ɵɵlistener("click", function GalleryPreviewComponent_Template_div_click_14_listener() { return ctx.closeOnClick && ctx.close(); })("mouseup", function GalleryPreviewComponent_Template_div_mouseup_14_listener($event) { return ctx.mouseUpHandler($event); })("mousemove", function GalleryPreviewComponent_Template_div_mousemove_14_listener($event) { return ctx.mouseMoveHandler($event); })("touchend", function GalleryPreviewComponent_Template_div_touchend_14_listener($event) { return ctx.mouseUpHandler($event); })("touchmove", function GalleryPreviewComponent_Template_div_touchmove_14_listener($event) { return ctx.mouseMoveHandler($event); });
            i0.ɵɵelementStart(15, "div", 12);
            i0.ɵɵtemplate(16, GalleryPreviewComponent_img_16_Template, 2, 15, "img", 13)(17, GalleryPreviewComponent_video_17_Template, 4, 1, "video", 14)(18, GalleryPreviewComponent_o_gallery_bullets_18_Template, 1, 2, "o-gallery-bullets", 15);
            i0.ɵɵelementEnd();
            i0.ɵɵtemplate(19, GalleryPreviewComponent_div_19_Template, 1, 1, "div", 16);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵproperty("ngIf", ctx.arrows);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("ngForOf", ctx.actions);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.download && ctx.src);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.zoom);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.zoom);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.rotate);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.rotate);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.fullscreen);
            i0.ɵɵadvance();
            i0.ɵɵproperty("icon", ctx.closeIcon);
            i0.ɵɵadvance();
            i0.ɵɵclassProp("o-gallery-active", ctx.showSpinner);
            i0.ɵɵadvance(2);
            i0.ɵɵtextInterpolate(ctx.spinnerIcon);
            i0.ɵɵadvance(3);
            i0.ɵɵproperty("ngIf", ctx.src && ctx.type === "image");
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.src && ctx.type === "video");
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.bullets);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.showDescription && ctx.description);
        } }, dependencies: [CommonModule, i3.NgForOf, i3.NgIf, GalleryActionComponent, GalleryArrowsComponent, GalleryBulletsComponent], styles: [".o-gallery-preview{width:100%;height:100%}.o-gallery-preview.o-gallery-active{width:100%;height:100%;position:fixed;left:0;top:0;background:#000000b3;z-index:10000;display:inline-block}.o-gallery-preview o-gallery-bullets{height:5%;align-items:center;padding:0}.o-gallery-preview .o-gallery-preview-img{opacity:0;max-width:90%;max-height:90%;-webkit-user-select:none;user-select:none;transition:transform .5s}.o-gallery-preview .o-gallery-preview-img.animation{transition:opacity .5s linear,transform .5s}.o-gallery-preview .o-gallery-preview-img.o-gallery-active{opacity:1}.o-gallery-preview .o-gallery-preview-img.o-gallery-grab{cursor:grab;cursor:-webkit-grab}.o-gallery-preview .o-gallery-preview-video{max-width:90%;max-height:90%;-webkit-user-select:none;user-select:none;transition:transform .5s}.o-gallery-preview .o-gallery-preview-video.animation{transition:opacity .5s linear,transform .5s}.o-gallery-preview .o-gallery-preview-video.o-gallery-active{opacity:1}.o-gallery-preview .o-gallery-preview-video.o-gallery-grab{cursor:grab;cursor:-webkit-grab}.o-gallery-preview .o-gallery-icon.o-gallery-spinner{font-family:Material Icons,sans-serif;font-size:50px;left:0;display:inline-block}.o-gallery-preview .o-gallery-preview-top{position:absolute;width:100%;-webkit-user-select:none;user-select:none}.o-gallery-preview .o-gallery-preview-icons{float:right}.o-gallery-preview .o-gallery-preview-icons .o-gallery-icon{position:relative;margin-right:10px;margin-top:10px;font-size:25px;cursor:pointer;text-decoration:none}.o-gallery-preview .o-gallery-preview-icons .o-gallery-icon.o-gallery-icon-disabled{cursor:default;opacity:.4}.o-gallery-preview .ngx-spinner-wrapper{width:50px;height:50px;display:none}.o-gallery-preview .ngx-spinner-wrapper.o-gallery-active{display:inline-block}.o-gallery-preview .o-gallery-center{position:absolute;inset:0;margin:auto}.o-gallery-preview .o-gallery-preview-text{width:100%;background:#000000b3;padding:10px;text-align:center;color:#fff;font-size:16px;flex:0 1 auto;z-index:10}.o-gallery-preview .o-gallery-preview-wrapper{width:100%;height:100%;display:flex;flex-flow:column}.o-gallery-preview .o-gallery-preview-img-wrapper{flex:1 1 auto;position:relative}.o-gallery-preview .o-gallery-icon{font-family:Material Icons,sans-serif;color:#fff;font-size:25px;position:absolute;z-index:2000;display:inline-block}.o-gallery-preview .o-gallery-icon .o-gallery-icon-content{display:block}\n"], encapsulation: 2 }); }
}
__decorate([
    BooleanInputConverter(),
    __metadata("design:type", Boolean)
], GalleryPreviewComponent.prototype, "showDescription", void 0);
__decorate([
    BooleanInputConverter(),
    __metadata("design:type", Boolean)
], GalleryPreviewComponent.prototype, "arrows", void 0);
__decorate([
    BooleanInputConverter(),
    __metadata("design:type", Boolean)
], GalleryPreviewComponent.prototype, "arrowsAutoHide", void 0);
__decorate([
    BooleanInputConverter(),
    __metadata("design:type", Boolean)
], GalleryPreviewComponent.prototype, "swipe", void 0);
__decorate([
    BooleanInputConverter(),
    __metadata("design:type", Boolean)
], GalleryPreviewComponent.prototype, "fullscreen", void 0);
__decorate([
    BooleanInputConverter(),
    __metadata("design:type", Boolean)
], GalleryPreviewComponent.prototype, "forceFullscreen", void 0);
__decorate([
    BooleanInputConverter(),
    __metadata("design:type", Boolean)
], GalleryPreviewComponent.prototype, "closeOnClick", void 0);
__decorate([
    BooleanInputConverter(),
    __metadata("design:type", Boolean)
], GalleryPreviewComponent.prototype, "closeOnEsc", void 0);
__decorate([
    BooleanInputConverter(),
    __metadata("design:type", Boolean)
], GalleryPreviewComponent.prototype, "keyboardNavigation", void 0);
__decorate([
    BooleanInputConverter(),
    __metadata("design:type", Boolean)
], GalleryPreviewComponent.prototype, "autoPlay", void 0);
__decorate([
    BooleanInputConverter(),
    __metadata("design:type", Boolean)
], GalleryPreviewComponent.prototype, "autoPlayPauseOnHover", void 0);
__decorate([
    BooleanInputConverter(),
    __metadata("design:type", Boolean)
], GalleryPreviewComponent.prototype, "infinityMove", void 0);
__decorate([
    BooleanInputConverter(),
    __metadata("design:type", Boolean)
], GalleryPreviewComponent.prototype, "zoom", void 0);
__decorate([
    BooleanInputConverter(),
    __metadata("design:type", Boolean)
], GalleryPreviewComponent.prototype, "animation", void 0);
__decorate([
    BooleanInputConverter(),
    __metadata("design:type", Boolean)
], GalleryPreviewComponent.prototype, "rotate", void 0);
__decorate([
    BooleanInputConverter(),
    __metadata("design:type", Boolean)
], GalleryPreviewComponent.prototype, "download", void 0);
__decorate([
    BooleanInputConverter(),
    __metadata("design:type", Boolean)
], GalleryPreviewComponent.prototype, "previewEnabled", void 0);
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(GalleryPreviewComponent, [{
        type: Component,
        args: [{ selector: 'o-gallery-preview', standalone: true, imports: [CommonModule, GalleryActionComponent, GalleryArrowsComponent, GalleryBulletsComponent], providers: [GalleryHelperService], inputs: [
                    'images',
                    'descriptions',
                    'showDescription : show-description',
                    'arrows',
                    'arrowsAutoHide : arrows-auto-hide',
                    'swipe',
                    'fullscreen',
                    'forceFullscreen : force-fullscreen',
                    'closeOnClick : close-on-click',
                    'closeOnEsc : close-on-esc',
                    'keyboardNavigation : keyboard-navigation',
                    'arrowPrevIcon : arrow-prev-icon',
                    'arrowNextIcon : arrow-next-icon',
                    'closeIcon : close-icon',
                    'fullscreenIcon : fullscreen-icon',
                    'spinnerIcon : spinner-icon',
                    'autoPlay : auto-play',
                    'autoPlayInterval : auto-play-interval',
                    'autoPlayPauseOnHover : auto-play-pause-on-hover',
                    'infinityMove : infinity-move',
                    'zoom',
                    'zoomStep : zoom-step',
                    'zoomMax : zoom-max',
                    'zoomMin : zoom-min',
                    'zoomInIcon : zoom-in-icon',
                    'zoomOutIcon : zoom-out-icon',
                    'animation',
                    'actions',
                    'rotate',
                    'rotateLeftIcon : rotate-left-icon',
                    'rotateRightIcon : rotate-right-icon',
                    'download',
                    'downloadIcon : download-icon',
                    'bullets',
                    'previewEnabled'
                ], outputs: [
                    'onOpen',
                    'onClose',
                    'onActiveChange'
                ], encapsulation: ViewEncapsulation.None, host: {
                    '[class.o-gallery-preview]': 'true',
                    '[class.o-gallery-active]': 'previewEnabled'
                }, template: "<o-gallery-arrows *ngIf=\"arrows\" (onPrevClick)=\"showPrev()\" (onNextClick)=\"showNext()\" [prev-disabled]=\"!canShowPrev\" [next-disabled]=\"!canShowNext\"\r\n  [arrow-prev-icon]=\"arrowPrevIcon\" [arrow-next-icon]=\"arrowNextIcon\"></o-gallery-arrows>\r\n\r\n<div class=\"o-gallery-preview-top\">\r\n  <div class=\"o-gallery-preview-icons\">\r\n    <o-gallery-action *ngFor=\"let action of actions\" [icon]=\"action.icon\" [disabled]=\"action.disabled\" [titleText]=\"action.titleText\"\r\n      (onClick)=\"action.onClick($event, index)\"></o-gallery-action>\r\n    <a *ngIf=\"download && src\" [href]=\"src\" class=\"o-gallery-icon\" aria-hidden=\"true\" download>\r\n      <em class=\"o-gallery-icon-content\">{{ downloadIcon }}</em>\r\n    </a>\r\n    <o-gallery-action *ngIf=\"zoom\" [icon]=\"zoomOutIcon\" [disabled]=\"!canZoomOut\" (onClick)=\"zoomOut()\"></o-gallery-action>\r\n    <o-gallery-action *ngIf=\"zoom\" [icon]=\"zoomInIcon\" [disabled]=\"!canZoomIn\" (onClick)=\"zoomIn()\"></o-gallery-action>\r\n    <o-gallery-action *ngIf=\"rotate\" [icon]=\"rotateLeftIcon\" (onClick)=\"rotateLeft()\"></o-gallery-action>\r\n    <o-gallery-action *ngIf=\"rotate\" [icon]=\"rotateRightIcon\" (onClick)=\"rotateRight()\"></o-gallery-action>\r\n    <o-gallery-action *ngIf=\"fullscreen\" [icon]=\"fullscreenIcon\" (onClick)=\"manageFullscreen()\"></o-gallery-action>\r\n    <o-gallery-action [icon]=\"closeIcon\" (onClick)=\"close()\"></o-gallery-action>\r\n  </div>\r\n</div>\r\n<div class=\"ngx-spinner-wrapper o-gallery-center\" [class.o-gallery-active]=\"showSpinner\">\r\n  <i class=\"o-gallery-icon o-gallery-spinner\" aria-hidden=\"true\">{{spinnerIcon}}</i>\r\n</div>\r\n<div class=\"o-gallery-preview-wrapper\" (click)=\"closeOnClick && close()\" (mouseup)=\"mouseUpHandler($event)\" (mousemove)=\"mouseMoveHandler($event)\"\r\n  (touchend)=\"mouseUpHandler($event)\" (touchmove)=\"mouseMoveHandler($event)\">\r\n  <div class=\"o-gallery-preview-img-wrapper\">\r\n    <img alt=\"previewImage\" *ngIf=\"src && type === 'image'\" #previewImage class=\"o-gallery-preview-img o-gallery-center\" [src]=\"src\" (click)=\"$event.stopPropagation()\"\r\n      (mouseenter)=\"imageMouseEnter()\" (mouseleave)=\"imageMouseLeave()\" (mousedown)=\"mouseDownHandler($event)\" (touchstart)=\"mouseDownHandler($event)\"\r\n      [class.o-gallery-active]=\"!loading\" [class.animation]=\"animation\" [class.o-gallery-grab]=\"canDragOnZoom\" [style.transform]=\"getTransform\"\r\n      [style.left]=\"positionLeft + 'px'\" [style.top]=\"positionTop + 'px'\"\r\n      [style.aspectRatio]=\"aspectRatio\"/>\r\n    <video *ngIf=\"src && type === 'video'\" #previewImage class=\"o-gallery-preview-video o-gallery-center\" controls style=\"width: 50%; height: 50%;\">\r\n      <source [src]=\"src\">\r\n      Your browser does not support the video tag.\r\n    </video>\r\n    <o-gallery-bullets *ngIf=\"bullets\" [count]=\"images.length\" [active]=\"index\" (onChange)=\"showAtIndex($event)\">\r\n    </o-gallery-bullets>\r\n  </div>\r\n  <div class=\"o-gallery-preview-text\" *ngIf=\"showDescription && description\" [innerHTML]=\"description\" (click)=\"$event.stopPropagation()\"></div>\r\n</div>\r\n", styles: [".o-gallery-preview{width:100%;height:100%}.o-gallery-preview.o-gallery-active{width:100%;height:100%;position:fixed;left:0;top:0;background:#000000b3;z-index:10000;display:inline-block}.o-gallery-preview o-gallery-bullets{height:5%;align-items:center;padding:0}.o-gallery-preview .o-gallery-preview-img{opacity:0;max-width:90%;max-height:90%;-webkit-user-select:none;user-select:none;transition:transform .5s}.o-gallery-preview .o-gallery-preview-img.animation{transition:opacity .5s linear,transform .5s}.o-gallery-preview .o-gallery-preview-img.o-gallery-active{opacity:1}.o-gallery-preview .o-gallery-preview-img.o-gallery-grab{cursor:grab;cursor:-webkit-grab}.o-gallery-preview .o-gallery-preview-video{max-width:90%;max-height:90%;-webkit-user-select:none;user-select:none;transition:transform .5s}.o-gallery-preview .o-gallery-preview-video.animation{transition:opacity .5s linear,transform .5s}.o-gallery-preview .o-gallery-preview-video.o-gallery-active{opacity:1}.o-gallery-preview .o-gallery-preview-video.o-gallery-grab{cursor:grab;cursor:-webkit-grab}.o-gallery-preview .o-gallery-icon.o-gallery-spinner{font-family:Material Icons,sans-serif;font-size:50px;left:0;display:inline-block}.o-gallery-preview .o-gallery-preview-top{position:absolute;width:100%;-webkit-user-select:none;user-select:none}.o-gallery-preview .o-gallery-preview-icons{float:right}.o-gallery-preview .o-gallery-preview-icons .o-gallery-icon{position:relative;margin-right:10px;margin-top:10px;font-size:25px;cursor:pointer;text-decoration:none}.o-gallery-preview .o-gallery-preview-icons .o-gallery-icon.o-gallery-icon-disabled{cursor:default;opacity:.4}.o-gallery-preview .ngx-spinner-wrapper{width:50px;height:50px;display:none}.o-gallery-preview .ngx-spinner-wrapper.o-gallery-active{display:inline-block}.o-gallery-preview .o-gallery-center{position:absolute;inset:0;margin:auto}.o-gallery-preview .o-gallery-preview-text{width:100%;background:#000000b3;padding:10px;text-align:center;color:#fff;font-size:16px;flex:0 1 auto;z-index:10}.o-gallery-preview .o-gallery-preview-wrapper{width:100%;height:100%;display:flex;flex-flow:column}.o-gallery-preview .o-gallery-preview-img-wrapper{flex:1 1 auto;position:relative}.o-gallery-preview .o-gallery-icon{font-family:Material Icons,sans-serif;color:#fff;font-size:25px;position:absolute;z-index:2000;display:inline-block}.o-gallery-preview .o-gallery-icon .o-gallery-icon-content{display:block}\n"] }]
    }], () => [{ type: i1.DomSanitizer }, { type: i0.ElementRef }, { type: GalleryHelperService }, { type: i0.Renderer2 }, { type: i0.ChangeDetectorRef }], { showDescription: [], arrows: [], arrowsAutoHide: [], swipe: [], fullscreen: [], forceFullscreen: [], closeOnClick: [], closeOnEsc: [], keyboardNavigation: [], autoPlay: [], autoPlayPauseOnHover: [], infinityMove: [], zoom: [], animation: [], rotate: [], download: [], previewEnabled: [], previewImage: [{
            type: ViewChild,
            args: ['previewImage']
        }], onMouseEnter: [{
            type: HostListener,
            args: ['mouseenter']
        }], onMouseLeave: [{
            type: HostListener,
            args: ['mouseleave']
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(GalleryPreviewComponent, { className: "GalleryPreviewComponent", filePath: "lib\\components\\gallery-preview\\o-gallery-preview.component.ts", lineNumber: 80 }); })();

class GalleryLayout {
    static { this.ThumbnailsTop = 'thumbnails-top'; }
    static { this.ThumbnailsBottom = 'thumbnails-bottom'; }
    static { this.ThumbnailsLeft = 'thumbnails-left'; }
    static { this.ThumbnailsRight = 'thumbnails-right'; }
}

class GalleryOrder {
    static { this.Column = 1; }
    static { this.Row = 2; }
    static { this.Page = 3; }
}

const _c0$1 = (a0, a1) => ({ "o-gallery-active": a0, "o-gallery-clickable": a1 });
function GalleryThumbnailsComponent_div_2_div_2_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelement(0, "div", 9);
} if (rf & 2) {
    const ctx_r3 = i0.ɵɵnextContext();
    const image_r5 = ctx_r3.$implicit;
    const i_r2 = ctx_r3.index;
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵproperty("oGalleryBackgroundImg", image_r5)("ngClass", i0.ɵɵpureFunction2(2, _c0$1, i_r2 === ctx_r2.selectedIndex, ctx_r2.clickable));
} }
function GalleryThumbnailsComponent_div_2_video_3_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "video", 10);
    i0.ɵɵelement(1, "source", 11);
    i0.ɵɵtext(2, " Your browser does not support the video tag. ");
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r3 = i0.ɵɵnextContext();
    const image_r5 = ctx_r3.$implicit;
    const i_r2 = ctx_r3.index;
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵproperty("ngClass", i0.ɵɵpureFunction2(2, _c0$1, i_r2 === ctx_r2.selectedIndex, ctx_r2.clickable));
    i0.ɵɵadvance();
    i0.ɵɵproperty("src", image_r5, i0.ɵɵsanitizeUrl);
} }
function GalleryThumbnailsComponent_div_2_o_gallery_action_5_Template(rf, ctx) { if (rf & 1) {
    const _r6 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "o-gallery-action", 12);
    i0.ɵɵlistener("onClick", function GalleryThumbnailsComponent_div_2_o_gallery_action_5_Template_o_gallery_action_onClick_0_listener($event) { const action_r7 = i0.ɵɵrestoreView(_r6).$implicit; const i_r2 = i0.ɵɵnextContext().index; return i0.ɵɵresetView(action_r7.onClick($event, i_r2)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const action_r7 = ctx.$implicit;
    i0.ɵɵproperty("icon", action_r7.icon)("disabled", action_r7.disabled)("titleText", action_r7.titleText);
} }
function GalleryThumbnailsComponent_div_2_div_6_Template(rf, ctx) { if (rf & 1) {
    i0.ɵɵelementStart(0, "div", 13)(1, "span", 14);
    i0.ɵɵtext(2);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext(2);
    i0.ɵɵadvance(2);
    i0.ɵɵtextInterpolate1("+", ctx_r2.remainingCountValue, "");
} }
function GalleryThumbnailsComponent_div_2_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "div")(1, "a", 3);
    i0.ɵɵlistener("click", function GalleryThumbnailsComponent_div_2_Template_a_click_1_listener($event) { const i_r2 = i0.ɵɵrestoreView(_r1).index; const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.handleClick($event, i_r2)); });
    i0.ɵɵtemplate(2, GalleryThumbnailsComponent_div_2_div_2_Template, 1, 5, "div", 4)(3, GalleryThumbnailsComponent_div_2_video_3_Template, 3, 5, "video", 5);
    i0.ɵɵelementStart(4, "div", 6);
    i0.ɵɵtemplate(5, GalleryThumbnailsComponent_div_2_o_gallery_action_5_Template, 1, 3, "o-gallery-action", 7);
    i0.ɵɵelementEnd();
    i0.ɵɵtemplate(6, GalleryThumbnailsComponent_div_2_div_6_Template, 3, 1, "div", 8);
    i0.ɵɵelementEnd()();
} if (rf & 2) {
    const image_r5 = ctx.$implicit;
    const i_r2 = ctx.index;
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵadvance();
    i0.ɵɵstyleProp("width", ctx_r2.thumbnailWidth)("height", ctx_r2.thumbnailHeight)("left", ctx_r2.getThumbnailLeft(i_r2))("top", ctx_r2.getThumbnailTop(i_r2));
    i0.ɵɵproperty("href", ctx_r2.hasLink(i_r2) ? ctx_r2.links[i_r2] : "#", i0.ɵɵsanitizeUrl)("target", ctx_r2.linkTarget)("ngClass", i0.ɵɵpureFunction2(16, _c0$1, i_r2 === ctx_r2.selectedIndex, ctx_r2.clickable));
    i0.ɵɵattribute("aria-label", ctx_r2.labels[i_r2]);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r2.getFileType(image_r5) === "image");
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r2.getFileType(image_r5) === "video");
    i0.ɵɵadvance(2);
    i0.ɵɵproperty("ngForOf", ctx_r2.actions);
    i0.ɵɵadvance();
    i0.ɵɵproperty("ngIf", ctx_r2.remainingCount && ctx_r2.remainingCountValue && i_r2 === ctx_r2.rows * ctx_r2.columns - 1);
} }
function GalleryThumbnailsComponent_o_gallery_arrows_3_Template(rf, ctx) { if (rf & 1) {
    const _r8 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "o-gallery-arrows", 15);
    i0.ɵɵlistener("onPrevClick", function GalleryThumbnailsComponent_o_gallery_arrows_3_Template_o_gallery_arrows_onPrevClick_0_listener() { i0.ɵɵrestoreView(_r8); const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.layout === "thumbnails-top" || ctx_r2.layout === "thumbnails-bottom" ? ctx_r2.moveLeft() : ctx_r2.moveTop()); })("onNextClick", function GalleryThumbnailsComponent_o_gallery_arrows_3_Template_o_gallery_arrows_onNextClick_0_listener() { i0.ɵɵrestoreView(_r8); const ctx_r2 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r2.layout === "thumbnails-top" || ctx_r2.layout === "thumbnails-bottom" ? ctx_r2.moveRight() : ctx_r2.moveBottom()); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r2 = i0.ɵɵnextContext();
    i0.ɵɵproperty("prev-disabled", ctx_r2.layout === "thumbnails-top" || ctx_r2.layout === "thumbnails-bottom" ? !ctx_r2.canMoveLeft : !ctx_r2.canMoveTop)("next-disabled", ctx_r2.layout === "thumbnails-top" || ctx_r2.layout === "thumbnails-bottom" ? !ctx_r2.canMoveRight : !ctx_r2.canMoveBottom)("arrow-prev-icon", ctx_r2.arrowPrevIcon)("arrow-next-icon", ctx_r2.arrowNextIcon)("layout", ctx_r2.layout);
} }
class GalleryThumbnailsComponent {
    set images(val) {
        this._imagesArray = val;
    }
    get images() {
        this._images = this._imagesArray;
        if (this.remainingCount) {
            this._images = this._imagesArray.slice(0, this.rows * this.columns);
        }
        else if (this.lazyLoading && this.order !== GalleryOrder.Row) {
            let stopIndex = 0;
            if (this.order === GalleryOrder.Column) {
                stopIndex = (this.index + this.columns + this.moveSize) * this.rows;
            }
            else if (this.order === GalleryOrder.Page) {
                stopIndex = this.index + ((this.columns * this.rows) * 2);
            }
            if (stopIndex <= this.minStopIndex) {
                stopIndex = this.minStopIndex;
            }
            else {
                this.minStopIndex = stopIndex;
            }
            this._images = this._imagesArray.slice(0, stopIndex);
        }
        return this._images;
    }
    constructor(sanitization, elementRef, helperService) {
        this.sanitization = sanitization;
        this.elementRef = elementRef;
        this.helperService = helperService;
        this.thumbnailsLeft = '0px';
        this.thumbnailsMarginLeft = '0px';
        this.minStopIndex = 0;
        this.visibleThumbnails = 0;
        this.thumbnailLayoutCount = 0;
        this._images = []; // Contains images shown in this component
        this._imagesArray = []; // Contains all images received through parameter `images`
        this.onActiveChange = new EventEmitter();
        this.index = 0;
    }
    ngOnChanges(changes) {
        if (changes.layout) {
            if (changes.layout.currentValue === 'thumbnails-top' || changes.layout.currentValue === 'thumbnails-bottom') {
                this.visibleThumbnails = this.columns;
                this.thumbnailLayoutCount = this.rows;
            }
            else {
                this.visibleThumbnails = this.rows;
                this.thumbnailLayoutCount = this.columns;
            }
        }
        if (changes.selectedIndex) {
            this.validateIndex();
        }
        if (changes.swipe) {
            this.helperService.manageSwipe(this.swipe, this.elementRef, 'thumbnails', () => this.moveRight(), () => this.moveLeft());
        }
        if (this.images) {
            this.remainingCountValue = this.images.length - (this.rows * this.columns);
        }
    }
    onMouseEnter() {
        this.mouseenter = true;
    }
    onMouseLeave() {
        this.mouseenter = false;
    }
    reset(index) {
        this.selectedIndex = index;
        this.setDefaultPosition();
        this.index = 0;
        this.validateIndex();
    }
    handleClick(event, index) {
        if (!this.hasLink(index)) {
            this.selectedIndex = index;
            this.onActiveChange.emit(index);
            event.stopPropagation();
            event.preventDefault();
        }
    }
    hasLink(index) {
        if (this.links && this.links.length && this.links[index]) {
            return true;
        }
        return false;
    }
    moveRight() {
        if (this.canMoveRight) {
            this.index += this.moveSize;
            const maxIndex = this.getMaxIndex() - this.columns;
            if (this.index > maxIndex) {
                this.index = maxIndex;
            }
            this.setThumbnailsPosition();
        }
    }
    moveBottom() {
        if (this.canMoveBottom) {
            this.index += this.moveSize;
            const maxIndex = this.getMaxIndex() - this.rows;
            if (this.index > maxIndex) {
                this.index = maxIndex;
            }
            this.setThumbnailsPosition();
        }
    }
    moveLeft() {
        if (this.canMoveLeft) {
            this.index -= this.moveSize;
            if (this.index < 0) {
                this.index = 0;
            }
            this.setThumbnailsPosition();
        }
    }
    moveTop() {
        if (this.canMoveTop) {
            this.index -= this.moveSize;
            if (this.index < 0) {
                this.index = 0;
            }
            this.setThumbnailsPosition();
        }
    }
    get canMoveRight() {
        return this.index + this.columns < this.getMaxIndex();
    }
    get canMoveBottom() {
        return this.index + this.rows < this.getMaxIndex();
    }
    get canMoveLeft() {
        return this.index !== 0;
    }
    get canMoveTop() {
        return this.index !== 0;
    }
    getThumbnailLeft(index) {
        return this.hasHorizontalDirection() ? this.calculateIndexHorizontal(index, this.rows) : this.calculateIndexVertical(index, this.columns);
    }
    getThumbnailTop(index) {
        return this.hasHorizontalDirection() ? this.calculateIndexVertical(index, this.rows) : this.calculateIndexHorizontal(index, this.columns);
    }
    calculateIndexVertical(index, numThumbnailLayout) {
        let calculatedIndex;
        if (this.order === GalleryOrder.Column) {
            calculatedIndex = index % numThumbnailLayout;
        }
        else if (this.order === GalleryOrder.Page) {
            calculatedIndex = Math.floor(index / this.visibleThumbnails) - (Math.floor(index / (this.rows * this.columns)) * numThumbnailLayout);
        }
        else if (this.order === GalleryOrder.Row && this.remainingCount) {
            calculatedIndex = Math.floor(index / this.visibleThumbnails);
        }
        else {
            calculatedIndex = Math.floor(index / Math.ceil(this.images.length / numThumbnailLayout));
        }
        return this.getThumbnailPosition(calculatedIndex, this.visibleThumbnails);
    }
    calculateIndexHorizontal(index, numThumbnailLayout) {
        let calculatedIndex;
        if (this.order === GalleryOrder.Column) {
            calculatedIndex = Math.floor(index / numThumbnailLayout);
        }
        else if (this.order === GalleryOrder.Page) {
            calculatedIndex = (index % this.visibleThumbnails) + (Math.floor(index / (this.rows * this.columns)) * this.visibleThumbnails);
        }
        else if (this.order === GalleryOrder.Row && this.remainingCount) {
            calculatedIndex = index % this.visibleThumbnails;
        }
        else {
            calculatedIndex = index % Math.ceil(this.images.length / numThumbnailLayout);
        }
        return this.getThumbnailPosition(calculatedIndex, this.visibleThumbnails);
    }
    /* if layout is right or left, get proportion about rows else about columns*/
    get thumbnailWidth() {
        return this.getThumbnailDimension(this.hasHorizontalDirection() ? this.visibleThumbnails : 1);
    }
    get thumbnailHeight() {
        return this.getThumbnailDimension(this.hasHorizontalDirection() ? 1 : this.visibleThumbnails);
    }
    hasHorizontalDirection() {
        return (GalleryLayout.ThumbnailsBottom === this.layout || GalleryLayout.ThumbnailsTop === this.layout);
    }
    setThumbnailsPosition() {
        this.thumbnailsLeft = -((100 / this.visibleThumbnails) * this.index) + '%';
        this.thumbnailsMarginLeft = -((this.margin - (((this.visibleThumbnails - 1) * this.margin) / this.visibleThumbnails)) * this.index) + 'px';
    }
    setDefaultPosition() {
        this.thumbnailsLeft = '0px';
        this.thumbnailsMarginLeft = '0px';
    }
    get canShowArrows() {
        if (this.remainingCount) {
            return false;
        }
        else if (this.arrows && this.images && this.images.length > this.getVisibleCount()
            && (!this.arrowsAutoHide || this.mouseenter)) {
            return true;
        }
        else {
            return false;
        }
    }
    validateIndex() {
        if (this.images) {
            let newIndex;
            if (this.order === GalleryOrder.Column) {
                newIndex = Math.floor(this.selectedIndex / this.visibleThumbnails);
            }
            else {
                newIndex = this.selectedIndex % Math.ceil(this.images.length / this.visibleThumbnails);
            }
            if (this.remainingCount) {
                newIndex = 0;
            }
            if (newIndex < this.index || newIndex >= this.index + this.visibleThumbnails) {
                const maxIndex = this.getMaxIndex() - this.visibleThumbnails;
                this.index = newIndex > maxIndex ? maxIndex : newIndex;
                this.setThumbnailsPosition();
            }
        }
    }
    getFileType(fileSource) {
        return this.helperService.getFileType(fileSource);
    }
    getThumbnailPosition(index, count) {
        return this.getSafeStyle('calc(' + ((100 / count) * index) + '% + '
            + ((this.margin - (((count - 1) * this.margin) / count)) * index) + 'px)');
    }
    getThumbnailDimension(count) {
        if (this.margin !== 0) {
            return this.getSafeStyle('calc(' + (100 / count) + '% - '
                + (((count - 1) * this.margin) / count) + 'px)');
        }
        else {
            return this.getSafeStyle('calc(' + (100 / count) + '% + 1px)');
        }
    }
    getMaxIndex() {
        if (this.order === GalleryOrder.Page) {
            let maxIndex = (Math.floor(this.images.length / this.getVisibleCount()) * this.visibleThumbnails);
            if (this.images.length % this.getVisibleCount() > this.visibleThumbnails) {
                maxIndex += this.visibleThumbnails;
            }
            else {
                maxIndex += this.images.length % this.getVisibleCount();
            }
            return maxIndex;
        }
        else {
            return Math.ceil(this.images.length / this.thumbnailLayoutCount);
        }
    }
    getVisibleCount() {
        return this.columns * this.rows;
    }
    getSafeStyle(value) {
        return this.sanitization.bypassSecurityTrustStyle(value);
    }
    static { this.ɵfac = function GalleryThumbnailsComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || GalleryThumbnailsComponent)(i0.ɵɵdirectiveInject(i1.DomSanitizer), i0.ɵɵdirectiveInject(i0.ElementRef), i0.ɵɵdirectiveInject(GalleryHelperService)); }; }
    static { this.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: GalleryThumbnailsComponent, selectors: [["o-gallery-thumbnails"]], hostBindings: function GalleryThumbnailsComponent_HostBindings(rf, ctx) { if (rf & 1) {
            i0.ɵɵlistener("mouseenter", function GalleryThumbnailsComponent_mouseenter_HostBindingHandler() { return ctx.onMouseEnter(); })("mouseleave", function GalleryThumbnailsComponent_mouseleave_HostBindingHandler() { return ctx.onMouseLeave(); });
        } }, inputs: { images: "images", links: "links", labels: "labels", linkTarget: [0, "link-target", "linkTarget"], columns: "columns", rows: "rows", arrows: "arrows", arrowsAutoHide: [0, "arrows-auto-hide", "arrowsAutoHide"], margin: "margin", selectedIndex: [0, "selected-index", "selectedIndex"], clickable: "clickable", swipe: "swipe", size: "size", arrowPrevIcon: [0, "arrow-prev-icon", "arrowPrevIcon"], arrowNextIcon: [0, "arrow-next-icon", "arrowNextIcon"], moveSize: [0, "move-size", "moveSize"], order: "order", remainingCount: [0, "remaining-count", "remainingCount"], lazyLoading: [0, "lazy-loading", "lazyLoading"], actions: "actions", layout: "layout" }, outputs: { onActiveChange: "onActiveChange" }, standalone: true, features: [i0.ɵɵNgOnChangesFeature, i0.ɵɵStandaloneFeature], decls: 4, vars: 11, consts: [[1, "o-gallery-thumbnails"], [4, "ngFor", "ngForOf"], [3, "prev-disabled", "next-disabled", "arrow-prev-icon", "arrow-next-icon", "layout", "onPrevClick", "onNextClick", 4, "ngIf"], [1, "o-gallery-thumbnail", 3, "click", "href", "target", "ngClass"], ["class", "o-gallery-thumbnail", "style", "width: 100%; height: 100%; position:absolute;", 3, "oGalleryBackgroundImg", "ngClass", 4, "ngIf"], ["class", "o-gallery-thumbnail", "style", "width: 100%; height: 100%; position:absolute;", 3, "ngClass", 4, "ngIf"], [1, "o-gallery-icons-wrapper"], [3, "icon", "disabled", "titleText", "onClick", 4, "ngFor", "ngForOf"], ["class", "o-gallery-remaining-count-overlay", 4, "ngIf"], [1, "o-gallery-thumbnail", 2, "width", "100%", "height", "100%", "position", "absolute", 3, "oGalleryBackgroundImg", "ngClass"], [1, "o-gallery-thumbnail", 2, "width", "100%", "height", "100%", "position", "absolute", 3, "ngClass"], [3, "src"], [3, "onClick", "icon", "disabled", "titleText"], [1, "o-gallery-remaining-count-overlay"], [1, "o-gallery-remaining-count"], [3, "onPrevClick", "onNextClick", "prev-disabled", "next-disabled", "arrow-prev-icon", "arrow-next-icon", "layout"]], template: function GalleryThumbnailsComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div")(1, "div", 0);
            i0.ɵɵtemplate(2, GalleryThumbnailsComponent_div_2_Template, 7, 19, "div", 1);
            i0.ɵɵelementEnd()();
            i0.ɵɵtemplate(3, GalleryThumbnailsComponent_o_gallery_arrows_3_Template, 1, 5, "o-gallery-arrows", 2);
        } if (rf & 2) {
            i0.ɵɵclassMapInterpolate1("o-gallery-thumbnails-wrapper o-gallery-thumbnail-size-", ctx.size, "");
            i0.ɵɵadvance();
            i0.ɵɵstyleProp("transform", ctx.layout === "thumbnails-top" || ctx.layout === "thumbnails-bottom" ? "translateX(" + ctx.thumbnailsLeft + ")" : "translateY(" + ctx.thumbnailsLeft + ")")("margin-left", ctx.layout === "thumbnails-top" || ctx.layout === "thumbnails-bottom" ? ctx.thumbnailsMarginLeft : "0px")("margin-top", ctx.layout === "thumbnails-right" || ctx.layout === "thumbnails-left" ? ctx.thumbnailsMarginLeft : "0px");
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngForOf", ctx.images);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.canShowArrows);
        } }, dependencies: [CommonModule, i3.NgClass, i3.NgForOf, i3.NgIf, GalleryActionComponent, GalleryArrowsComponent, GalleryImageDirective], styles: ["[_nghost-%COMP%]{width:100%;display:inline-block;position:relative}.o-gallery-thumbnails-wrapper[_ngcontent-%COMP%]{width:100%;height:100%;position:absolute;overflow:hidden}.o-gallery-thumbnails[_ngcontent-%COMP%]{height:100%;width:100%;position:absolute;left:0;transform:translate(0);transition:transform .5s ease-in-out;will-change:transform}.o-gallery-thumbnails[_ngcontent-%COMP%]   .o-gallery-thumbnail[_ngcontent-%COMP%]{position:absolute;height:100%;background-position:center;background-repeat:no-repeat;text-decoration:none}.o-gallery-thumbnail-size-cover[_ngcontent-%COMP%]   .o-gallery-thumbnails[_ngcontent-%COMP%]   .o-gallery-thumbnail[_ngcontent-%COMP%]{background-size:cover}.o-gallery-thumbnail-size-contain[_ngcontent-%COMP%]   .o-gallery-thumbnails[_ngcontent-%COMP%]   .o-gallery-thumbnail[_ngcontent-%COMP%]{background-size:contain}.o-gallery-remaining-count-overlay[_ngcontent-%COMP%]{width:100%;height:100%;position:absolute;left:0;top:0;background-color:#0006}.o-gallery-remaining-count[_ngcontent-%COMP%]{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);color:#fff;font-size:30px}"] }); }
}
__decorate([
    BooleanInputConverter(),
    __metadata("design:type", Boolean)
], GalleryThumbnailsComponent.prototype, "arrows", void 0);
__decorate([
    BooleanInputConverter(),
    __metadata("design:type", Boolean)
], GalleryThumbnailsComponent.prototype, "arrowsAutoHide", void 0);
__decorate([
    BooleanInputConverter(),
    __metadata("design:type", Boolean)
], GalleryThumbnailsComponent.prototype, "clickable", void 0);
__decorate([
    BooleanInputConverter(),
    __metadata("design:type", Boolean)
], GalleryThumbnailsComponent.prototype, "swipe", void 0);
__decorate([
    BooleanInputConverter(),
    __metadata("design:type", Boolean)
], GalleryThumbnailsComponent.prototype, "remainingCount", void 0);
__decorate([
    BooleanInputConverter(),
    __metadata("design:type", Boolean)
], GalleryThumbnailsComponent.prototype, "lazyLoading", void 0);
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(GalleryThumbnailsComponent, [{
        type: Component,
        args: [{ selector: 'o-gallery-thumbnails', standalone: true, imports: [CommonModule, GalleryActionComponent, GalleryArrowsComponent, GalleryImageDirective], inputs: [
                    'images',
                    'links',
                    'labels',
                    'linkTarget : link-target',
                    'columns',
                    'rows',
                    'arrows',
                    'arrowsAutoHide : arrows-auto-hide',
                    'margin',
                    'selectedIndex : selected-index',
                    'clickable',
                    'swipe',
                    'size',
                    'arrowPrevIcon : arrow-prev-icon',
                    'arrowNextIcon : arrow-next-icon',
                    'moveSize : move-size',
                    'order',
                    'remainingCount : remaining-count',
                    'lazyLoading : lazy-loading',
                    'actions',
                    'layout'
                ], outputs: [
                    'onActiveChange'
                ], template: "<div class=\"o-gallery-thumbnails-wrapper o-gallery-thumbnail-size-{{size}}\">\r\n  <div class=\"o-gallery-thumbnails\"\r\n    [style.transform]=\"(layout === 'thumbnails-top' || layout === 'thumbnails-bottom')?'translateX('+ thumbnailsLeft + ')':'translateY(' + thumbnailsLeft + ')'\"\r\n    [style.marginLeft]=\"(layout === 'thumbnails-top' || layout === 'thumbnails-bottom')?thumbnailsMarginLeft : '0px'\"\r\n    [style.marginTop]=\"(layout === 'thumbnails-right' || layout === 'thumbnails-left')?thumbnailsMarginLeft : '0px'\">\r\n    <div *ngFor=\"let image of images; let i = index;\">\r\n      <a [href]=\"hasLink(i) ? links[i] : '#'\" [target]=\"linkTarget\" class=\"o-gallery-thumbnail\"\r\n        [style.width]=\"thumbnailWidth\"\r\n        (click)=\"handleClick($event, i)\"\r\n        [style.height]=\"thumbnailHeight\"\r\n        [style.left]=\"getThumbnailLeft(i)\" [style.top]=\"getThumbnailTop(i)\"\r\n        [ngClass]=\"{ 'o-gallery-active': i === selectedIndex, 'o-gallery-clickable': clickable }\" [attr.aria-label]=\"labels[i]\">\r\n        <div *ngIf=\"getFileType(image) === 'image'\" [oGalleryBackgroundImg]=\"image\" class=\"o-gallery-thumbnail\"\r\n          [ngClass]=\"{ 'o-gallery-active': i === selectedIndex, 'o-gallery-clickable': clickable }\"\r\n          style=\"width: 100%; height: 100%; position:absolute;\"></div>\r\n        <video *ngIf=\"getFileType(image) === 'video'\" class=\"o-gallery-thumbnail\"\r\n          [ngClass]=\"{ 'o-gallery-active': i === selectedIndex, 'o-gallery-clickable': clickable }\"\r\n          style=\"width: 100%; height: 100%; position:absolute;\">\r\n          <source [src]=\"image\">\r\n          Your browser does not support the video tag.\r\n        </video>\r\n        <div class=\"o-gallery-icons-wrapper\">\r\n          <o-gallery-action *ngFor=\"let action of actions\" [icon]=\"action.icon\" [disabled]=\"action.disabled\" [titleText]=\"action.titleText\"\r\n            (onClick)=\"action.onClick($event, i)\"></o-gallery-action>\r\n        </div>\r\n        <div class=\"o-gallery-remaining-count-overlay\" *ngIf=\"remainingCount && remainingCountValue && (i === (rows * columns) - 1)\">\r\n          <span class=\"o-gallery-remaining-count\">+{{remainingCountValue}}</span>\r\n        </div>\r\n      </a>\r\n    </div>\r\n  </div>\r\n</div>\r\n\r\n<o-gallery-arrows *ngIf=\"canShowArrows\"\r\n  (onPrevClick)=\"(layout === 'thumbnails-top' || layout === 'thumbnails-bottom')?moveLeft():moveTop()\"\r\n  (onNextClick)=\"(layout === 'thumbnails-top' || layout === 'thumbnails-bottom')?moveRight():moveBottom()\"\r\n  [prev-disabled]=\"(layout === 'thumbnails-top' || layout === 'thumbnails-bottom')?!canMoveLeft:!canMoveTop\"\r\n  [next-disabled]=\"(layout === 'thumbnails-top' || layout === 'thumbnails-bottom')?!canMoveRight:!canMoveBottom\"\r\n  [arrow-prev-icon]=\"arrowPrevIcon\" [arrow-next-icon]=\"arrowNextIcon\" [layout]=\"layout\"></o-gallery-arrows>\r\n", styles: [":host{width:100%;display:inline-block;position:relative}.o-gallery-thumbnails-wrapper{width:100%;height:100%;position:absolute;overflow:hidden}.o-gallery-thumbnails{height:100%;width:100%;position:absolute;left:0;transform:translate(0);transition:transform .5s ease-in-out;will-change:transform}.o-gallery-thumbnails .o-gallery-thumbnail{position:absolute;height:100%;background-position:center;background-repeat:no-repeat;text-decoration:none}.o-gallery-thumbnail-size-cover .o-gallery-thumbnails .o-gallery-thumbnail{background-size:cover}.o-gallery-thumbnail-size-contain .o-gallery-thumbnails .o-gallery-thumbnail{background-size:contain}.o-gallery-remaining-count-overlay{width:100%;height:100%;position:absolute;left:0;top:0;background-color:#0006}.o-gallery-remaining-count{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);color:#fff;font-size:30px}\n"] }]
    }], () => [{ type: i1.DomSanitizer }, { type: i0.ElementRef }, { type: GalleryHelperService }], { arrows: [], arrowsAutoHide: [], clickable: [], swipe: [], remainingCount: [], lazyLoading: [], onMouseEnter: [{
            type: HostListener,
            args: ['mouseenter']
        }], onMouseLeave: [{
            type: HostListener,
            args: ['mouseleave']
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(GalleryThumbnailsComponent, { className: "GalleryThumbnailsComponent", filePath: "lib\\components\\gallery-thumbnails\\o-gallery-thumbnails.component.ts", lineNumber: 47 }); })();

class GalleryImageSize {
    static { this.Cover = 'cover'; }
    static { this.Contain = 'contain'; }
}

class GalleryAction {
    constructor(action) {
        this.icon = action.icon;
        this.disabled = action.disabled ? action.disabled : false;
        this.titleText = action.titleText ? action.titleText : '';
        this.onClick = action.onClick;
    }
}

class GalleryOptions {
    constructor(obj) {
        function use(source, defaultValue) {
            return obj && source !== undefined ? source : defaultValue;
        }
        this.breakpoint = use(obj.breakpoint, undefined);
        this.width = use(obj.width, '800px');
        this.height = use(obj.height, obj.aspectRatio ? undefined : '600px');
        this.fullWidth = use(obj.fullWidth, false);
        this.layout = use(obj.layout, GalleryLayout.ThumbnailsBottom);
        this.startIndex = use(obj.startIndex, 0);
        this.linkTarget = use(obj.linkTarget, '_blank');
        this.lazyLoading = use(obj.lazyLoading, true);
        this.image = use(obj.image, true);
        this.imagePercent = use(obj.imagePercent, 75);
        this.imageArrows = use(obj.imageArrows, true);
        this.imageArrowsAutoHide = use(obj.imageArrowsAutoHide, false);
        this.imageSwipe = use(obj.imageSwipe, true);
        this.imageAnimation = use(obj.imageAnimation, GalleryAnimation.Fade);
        this.imageSize = use(obj.imageSize, GalleryImageSize.Cover);
        this.imageAutoPlay = use(obj.imageAutoPlay, false);
        this.imageAutoPlayInterval = use(obj.imageAutoPlayInterval, 2000);
        this.imageAutoPlayPauseOnHover = use(obj.imageAutoPlayPauseOnHover, false);
        this.imageInfinityMove = use(obj.imageInfinityMove, false);
        if (obj && obj.imageActions && obj.imageActions.length) {
            obj.imageActions = obj.imageActions.map(action => new GalleryAction(action));
        }
        this.imageActions = use(obj.imageActions, []);
        this.imageDescription = use(obj.imageDescription, false);
        this.imageBullets = use(obj.imageBullets, false);
        this.aspectRatio = use(obj.aspectRatio, undefined);
        this.thumbnails = use(obj.thumbnails, true);
        if (obj.layout === GalleryLayout.ThumbnailsRight || obj.layout === GalleryLayout.ThumbnailsLeft) {
            this.thumbnailsColumns = use(obj.thumbnailsColumns, 1);
            this.thumbnailsRows = use(obj.thumbnailsRows, 4);
        }
        else {
            this.thumbnailsColumns = use(obj.thumbnailsColumns, 4);
            this.thumbnailsRows = use(obj.thumbnailsRows, 1);
        }
        this.thumbnailsPercent = use(obj.thumbnailsPercent, 25);
        this.thumbnailsMargin = use(obj.thumbnailsMargin, 10);
        this.thumbnailsArrows = use(obj.thumbnailsArrows, true);
        this.thumbnailsArrowsAutoHide = use(obj.thumbnailsArrowsAutoHide, false);
        this.thumbnailsSwipe = use(obj.thumbnailsSwipe, true);
        this.thumbnailsMoveSize = use(obj.thumbnailsMoveSize, 1);
        this.thumbnailsOrder = use(obj.thumbnailsOrder, GalleryOrder.Column);
        this.thumbnailsRemainingCount = use(obj.thumbnailsRemainingCount, false);
        this.thumbnailsAsLinks = use(obj.thumbnailsAsLinks, false);
        this.thumbnailsAutoHide = use(obj.thumbnailsAutoHide, false);
        this.thumbnailMargin = use(obj.thumbnailMargin, 10);
        this.thumbnailSize = use(obj.thumbnailSize, GalleryImageSize.Cover);
        if (obj && obj.thumbnailActions && obj.thumbnailActions.length) {
            obj.thumbnailActions = obj.thumbnailActions.map(action => new GalleryAction(action));
        }
        this.thumbnailActions = use(obj.thumbnailActions, []);
        this.preview = use(obj.preview, true);
        this.previewDescription = use(obj.previewDescription, false);
        this.previewArrows = use(obj.previewArrows, true);
        this.previewArrowsAutoHide = use(obj.previewArrowsAutoHide, false);
        this.previewSwipe = use(obj.previewSwipe, true);
        this.previewFullscreen = use(obj.previewFullscreen, true);
        this.previewForceFullscreen = use(obj.previewForceFullscreen, false);
        this.previewCloseOnClick = use(obj.previewCloseOnClick, true);
        this.previewCloseOnEsc = use(obj.previewCloseOnEsc, true);
        this.previewKeyboardNavigation = use(obj.previewKeyboardNavigation, true);
        this.previewAnimation = use(obj.previewAnimation, true);
        this.previewAutoPlay = use(obj.previewAutoPlay, false);
        this.previewAutoPlayInterval = use(obj.previewAutoPlayInterval, 2000);
        this.previewAutoPlayPauseOnHover = use(obj.previewAutoPlayPauseOnHover, false);
        this.previewInfinityMove = use(obj.previewInfinityMove, false);
        this.previewZoom = use(obj.previewZoom, true);
        this.previewZoomStep = use(obj.previewZoomStep, 0.1);
        this.previewZoomMax = use(obj.previewZoomMax, 2);
        this.previewZoomMin = use(obj.previewZoomMin, 0.5);
        this.previewRotate = use(obj.previewRotate, true);
        this.previewDownload = use(obj.previewDownload, true);
        this.previewCustom = use(obj.previewCustom, undefined);
        this.previewBullets = use(obj.previewBullets, false);
        this.arrowPrevIcon = use(obj.arrowPrevIcon, 'navigate_before');
        this.arrowNextIcon = use(obj.arrowNextIcon, 'navigate_next');
        this.closeIcon = use(obj.closeIcon, 'close');
        this.fullscreenIcon = use(obj.fullscreenIcon, 'fullscreen');
        this.spinnerIcon = use(obj.spinnerIcon, 'loop');
        this.zoomInIcon = use(obj.zoomInIcon, 'zoom_in');
        this.zoomOutIcon = use(obj.zoomOutIcon, 'zoom_out');
        this.rotateLeftIcon = use(obj.rotateLeftIcon, 'rotate_left');
        this.rotateRightIcon = use(obj.rotateRightIcon, 'rotate_right');
        this.downloadIcon = use(obj.downloadIcon, 'cloud_download');
        if (obj && obj.actions && obj.actions.length) {
            obj.actions = obj.actions.map(action => new GalleryAction(action));
        }
        this.actions = use(obj.actions, []);
    }
}

class GalleryOrderedImage {
    constructor(obj) {
        this.src = obj.src;
        this.type = obj.type;
        this.index = obj.index;
    }
}

const _c0 = () => [];
function GalleryComponent_o_gallery_image_1_Template(rf, ctx) { if (rf & 1) {
    const _r1 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "o-gallery-image", 3);
    i0.ɵɵlistener("onClick", function GalleryComponent_o_gallery_image_1_Template_o_gallery_image_onClick_0_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.openPreview($event)); })("onActiveChange", function GalleryComponent_o_gallery_image_1_Template_o_gallery_image_onActiveChange_0_listener($event) { i0.ɵɵrestoreView(_r1); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.selectFromImage($event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵstyleProp("height", ctx_r1.imageHeight)("width", (ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.thumbnails) && ((ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.layout) === "thumbnails-left" || (ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.layout) === "thumbnails-right") ? ctx_r1.currentOptions.imagePercent + "%" : "100%")("aspect-ratio", ctx_r1.aspectRatio ? ctx_r1.aspectRatio : undefined);
    i0.ɵɵproperty("images", ctx_r1.mediumImages)("clickable", ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.preview)("selected-index", ctx_r1.selectedIndex)("arrows", ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.imageArrows)("arrows-auto-hide", ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.imageArrowsAutoHide)("arrow-prev-icon", ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.arrowPrevIcon)("arrow-next-icon", ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.arrowNextIcon)("swipe", ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.imageSwipe)("animation", ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.imageAnimation)("size", ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.imageSize)("auto-play", ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.imageAutoPlay)("auto-play-interval", ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.imageAutoPlayInterval)("auto-play-pause-on-hover", ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.imageAutoPlayPauseOnHover)("infinity-move", ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.imageInfinityMove)("lazy-loading", ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.lazyLoading)("actions", ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.imageActions)("descriptions", ctx_r1.descriptions)("show-description", ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.imageDescription)("bullets", ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.imageBullets);
} }
function GalleryComponent_o_gallery_thumbnails_2_Template(rf, ctx) { if (rf & 1) {
    const _r3 = i0.ɵɵgetCurrentView();
    i0.ɵɵelementStart(0, "o-gallery-thumbnails", 4, 0);
    i0.ɵɵlistener("onActiveChange", function GalleryComponent_o_gallery_thumbnails_2_Template_o_gallery_thumbnails_onActiveChange_0_listener($event) { i0.ɵɵrestoreView(_r3); const ctx_r1 = i0.ɵɵnextContext(); return i0.ɵɵresetView(ctx_r1.selectFromThumbnails($event)); });
    i0.ɵɵelementEnd();
} if (rf & 2) {
    const ctx_r1 = i0.ɵɵnextContext();
    i0.ɵɵstyleProp("margin-top", (ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.layout) === "thumbnails-bottom" ? (ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.thumbnailsMargin) + "px" : "0px")("margin-bottom", (ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.layout) === "thumbnails-top" ? (ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.thumbnailsMargin) + "px" : "0px")("margin-right", (ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.layout) === "thumbnails-left" ? (ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.thumbnailsMargin) + "px" : "0px")("margin-left", (ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.layout) === "thumbnails-right" ? (ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.thumbnailsMargin) + "px" : "0px")("height", ctx_r1.thumbnailHeight)("width", (ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.image) && ((ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.layout) === "thumbnails-left" || (ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.layout) === "thumbnails-right") ? "calc(" + (ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.thumbnailsPercent) + "% - " + (ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.thumbnailsMargin) + "px)" : "100%");
    i0.ɵɵproperty("images", ctx_r1.smallImages)("links", (ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.thumbnailsAsLinks) ? ctx_r1.links : i0.ɵɵpureFunction0(33, _c0))("labels", ctx_r1.labels)("link-target", ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.linkTarget)("selected-index", ctx_r1.selectedIndex)("columns", ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.thumbnailsColumns)("rows", ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.thumbnailsRows)("margin", ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.thumbnailMargin)("arrows", ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.thumbnailsArrows)("arrows-auto-hide", ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.thumbnailsArrowsAutoHide)("arrow-prev-icon", ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.arrowPrevIcon)("arrow-next-icon", ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.arrowNextIcon)("clickable", (ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.image) || (ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.preview))("swipe", ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.thumbnailsSwipe)("size", ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.thumbnailSize)("move-size", ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.thumbnailsMoveSize)("order", ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.thumbnailsOrder)("remaining-count", ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.thumbnailsRemainingCount)("lazy-loading", ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.lazyLoading)("actions", ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.thumbnailActions)("layout", ctx_r1.currentOptions == null ? null : ctx_r1.currentOptions.layout);
} }
const DEFAULT_OUTPUTS_O_GALLERY = [
    'onImagesReady',
    'onChange',
    'onPreviewOpen',
    'onPreviewClose',
    'onPreviewChange'
];
const DEFAULT_INPUTS_O_GALLERY = [
    'options: gallery-options',
    'images: gallery-images'
];
class GalleryComponent {
    set options(val) {
        let options = val.map(option => new GalleryOptions(option));
        // sort options
        options = [
            ...options.filter(o => o.breakpoint === undefined),
            ...options
                .filter(o => o.breakpoint !== undefined)
                .sort((a, b) => b.breakpoint - a.breakpoint)
        ];
        this._options = options;
        this.setBreakpoint();
        this.setOptions();
        this.checkFullWidth();
        if (this.currentOptions) {
            this.selectedIndex = this.currentOptions.startIndex;
        }
    }
    get options() {
        return this._options;
    }
    set images(val) {
        this._images = val;
        const smallImages = [];
        const mediumImages = [];
        const bigImages = [];
        const descriptions = [];
        const links = [];
        const labels = [];
        this._images.forEach((img, i) => {
            img.type = this.helperService.getFileType(img.url || img.big || img.medium || img.small || '');
            smallImages.push(img.small || img.medium);
            mediumImages.push(new GalleryOrderedImage({ src: img.medium, type: img.type, index: i }));
            bigImages.push(img.big || img.medium);
            descriptions.push(img.description);
            links.push(img.url);
            labels.push(img.label);
        });
        this.smallImages = smallImages;
        this.mediumImages = mediumImages;
        this.bigImages = bigImages;
        this.descriptions = descriptions;
        this.links = links;
        this.labels = labels;
        if (this.images && this.images.length) {
            this.onImagesReady.emit();
        }
    }
    get images() {
        return this._images;
    }
    constructor(viewContainerRef, myElement, injector) {
        this.viewContainerRef = viewContainerRef;
        this.myElement = myElement;
        this.injector = injector;
        this.subscription = new Subscription();
        this.onImagesReady = new EventEmitter();
        this.onChange = new EventEmitter();
        this.onPreviewOpen = new EventEmitter();
        this.onPreviewClose = new EventEmitter();
        this.onPreviewChange = new EventEmitter();
        this.selectedIndex = 0;
        this.currentOptions = new GalleryOptions({});
        this.breakpoint = undefined;
        this.prevBreakpoint = undefined;
        this.sanitization = this.injector.get(DomSanitizer);
        this.scrollStrategy = this.injector.get(ScrollStrategyOptions);
        this.overlay = this.injector.get(Overlay);
        this.helperService = this.injector.get(GalleryHelperService);
        this.ngZone = this.injector.get(NgZone);
    }
    ngAfterViewInit() {
        if (this.galleryMainImage) {
            this.galleryMainImage.reset(this.currentOptions.startIndex);
        }
        if (this.currentOptions.thumbnailsAutoHide && this.currentOptions.thumbnails && this.images.length <= 1) {
            this.currentOptions.thumbnails = false;
            this.currentOptions.imageArrows = false;
        }
        this.checkFullWidth();
    }
    onResize() {
        this.setBreakpoint();
        if (this.prevBreakpoint !== this.breakpoint) {
            this.setOptions();
            this.resetThumbnails();
        }
        if (this.currentOptions && this.currentOptions.fullWidth) {
            if (this.fullWidthTimeout) {
                clearTimeout(this.fullWidthTimeout);
            }
            this.fullWidthTimeout = setTimeout(() => {
                this.checkFullWidth();
            }, 200);
        }
    }
    openPreview(index) {
        this.previewEnabled = true;
        this.openGalleryPreview(index);
    }
    previewOpened() {
        this.onPreviewOpen.emit();
        if (this.galleryMainImage && this.galleryMainImage.autoPlay) {
            this.galleryMainImage.stopAutoPlay();
        }
    }
    previewClosed() {
        this.previewEnabled = false;
        this.onPreviewClose.emit();
        if (this.galleryMainImage && this.galleryMainImage.autoPlay) {
            this.galleryMainImage.startAutoPlay();
        }
        if (this.galleryOverlayRef && this.galleryOverlayRef.hasAttached()) {
            this.galleryOverlayRef.detach();
            this.galleryOverlayRef.dispose();
            this.galleryOverlayRef = null;
        }
        if (this.previewComponentPortal && this.previewComponentPortal.isAttached) {
            this.previewComponentPortal.detach();
        }
    }
    selectFromImage(index) {
        this.select(index);
    }
    selectFromThumbnails(index) {
        this.select(index);
        if (this.currentOptions && this.currentOptions.thumbnails && this.currentOptions.preview
            && (!this.currentOptions.image || this.currentOptions.thumbnailsRemainingCount)) {
            this.openPreview(this.selectedIndex);
        }
    }
    show(index) {
        this.select(index);
    }
    showNext() {
        this.galleryMainImage.showNext();
    }
    showPrev() {
        this.galleryMainImage.showPrev();
    }
    canShowNext() {
        if (this.images && this.currentOptions) {
            return (this.currentOptions.imageInfinityMove || this.selectedIndex < this.images.length - 1)
                ? true : false;
        }
        else {
            return false;
        }
    }
    canShowPrev() {
        if (this.images && this.currentOptions) {
            return (this.currentOptions.imageInfinityMove || this.selectedIndex > 0) ? true : false;
        }
        else {
            return false;
        }
    }
    previewSelect(index) {
        this.onPreviewChange.emit({ index, image: this.images[index] });
    }
    moveThumbnailsRight() {
        this.thubmnails.moveRight();
    }
    moveThumbnailsLeft() {
        this.thubmnails.moveLeft();
    }
    moveThumbnailsTop() {
        this.thubmnails.moveTop();
    }
    moveThumbnailsBottom() {
        this.thubmnails.moveBottom();
    }
    canMoveThumbnailsRight() {
        return this.thubmnails.canMoveRight;
    }
    canMoveThumbnailsLeft() {
        return this.thubmnails.canMoveLeft;
    }
    canMoveThumbnailsTop() {
        return this.thubmnails.canMoveTop;
    }
    canMoveThumbnailsBottom() {
        return this.thubmnails.canMoveBottom;
    }
    changeWidth(newWidth) {
        this.changeOptionsProp('width', newWidth);
    }
    changeHeight(newHeight) {
        this.changeOptionsProp('height', newHeight);
    }
    changeAspectRatio(newRatio) {
        this.changeOptionsProp('aspectRatio', newRatio);
    }
    changeThumbnailsColumns(columns) {
        this.changeOptionsProp('thumbnailsColumns', columns);
    }
    changeThumbnailsRows(rows) {
        this.changeOptionsProp('thumbnailsRows', rows);
    }
    changeThumbPosition(layout) {
        this.options = this.options.map(o => {
            switch (layout) {
                case GalleryLayout.ThumbnailsBottom:
                    o.layout = GalleryLayout.ThumbnailsBottom;
                    break;
                case GalleryLayout.ThumbnailsTop:
                    o.layout = GalleryLayout.ThumbnailsTop;
                    break;
                case GalleryLayout.ThumbnailsLeft:
                    o.layout = GalleryLayout.ThumbnailsLeft;
                    break;
                case GalleryLayout.ThumbnailsRight:
                    o.layout = GalleryLayout.ThumbnailsRight;
            }
            return o;
        });
    }
    get aspectRatio() {
        if (Util$1.isDefined(this.currentOptions.aspectRatio) && this.currentOptions.aspectRatio.indexOf(':') > -1) {
            const ratioParts = this.currentOptions.aspectRatio.split(':');
            return ratioParts[0] + '/' + parseFloat(ratioParts[1]);
        }
        return undefined;
    }
    get imageHeight() {
        if (Util$1.isDefined(this.currentOptions.aspectRatio)) {
            return undefined;
        }
        else if (this.currentOptions.thumbnails &&
            (this.currentOptions.layout === 'thumbnails-bottom' || this.currentOptions.layout === 'thumbnails-top')) {
            return this.currentOptions.imagePercent + '%';
        }
        else {
            return '100%';
        }
    }
    get thumbnailHeight() {
        let height = undefined;
        if (this.currentOptions.aspectRatio?.indexOf(':') > -1) {
            if (Util$1.isDefined(this.thubmnails) && this.currentOptions.layout && (this.currentOptions.layout === 'thumbnails-bottom' || this.currentOptions.layout === 'thumbnails-top')) {
                const thumbnailHref = this.thubmnails.elementRef.nativeElement.querySelector('a');
                if (Util$1.isDefined(thumbnailHref)) {
                    const widthThumbnail = this.getWidthThumbnail(thumbnailHref);
                    const ratioPercent = this.getRatioPercentage();
                    height = widthThumbnail * ratioPercent + 'px';
                }
            }
        }
        else if (this.currentOptions.image &&
            (this.currentOptions.layout !== 'thumbnails-left' && this.currentOptions.layout !== 'thumbnails-right')) {
            height = 'calc(' + this.currentOptions.thumbnailsPercent + '% - ' + this.currentOptions.thumbnailsMargin + 'px)';
        }
        else {
            height = '100%';
        }
        return height;
    }
    getRatioPercentage() {
        const ratioParts = this.currentOptions.aspectRatio.split(':').map(x => parseInt(x));
        return !isNaN(ratioParts[0]) && !isNaN(ratioParts[1]) ? ratioParts[1] / ratioParts[0] : 1;
    }
    getWidthThumbnail(thumbnailHref) {
        return thumbnailHref ? thumbnailHref.offsetWidth : 0;
    }
    changeImageSize() {
        this.options = this.options.map(o => {
            o.imageSize = o.imageSize === GalleryImageSize.Cover ? GalleryImageSize.Contain : GalleryImageSize.Cover;
            return o;
        });
    }
    changeThumbnailSize() {
        this.options = this.options.map(o => {
            o.thumbnailSize = o.thumbnailSize === GalleryImageSize.Cover ? GalleryImageSize.Contain : GalleryImageSize.Cover;
            return o;
        });
    }
    changeImage() {
        this.toggleOptionsProp('image');
    }
    changeThumbnails() {
        this.toggleOptionsProp('thumbnails');
    }
    changePreview() {
        this.toggleOptionsProp('preview');
    }
    changeImageArrows() {
        this.toggleOptionsProp('imageArrows');
    }
    changePreviewArrows() {
        this.toggleOptionsProp('previewArrows');
    }
    changePreviewAutoPlay() {
        this.toggleOptionsProp('previewAutoPlay');
    }
    changePreviewDescription() {
        this.toggleOptionsProp('previewDescription');
    }
    changePreviewFullscreen() {
        this.toggleOptionsProp('previewFullscreen');
    }
    changePreviewCloseonClick() {
        this.toggleOptionsProp('previewCloseOnClick');
    }
    changePreviewCloseonEsc() {
        this.toggleOptionsProp('previewCloseOnEsc');
    }
    changePreviewKeyboardNavigation() {
        this.toggleOptionsProp('previewKeyboardNavigation');
    }
    changePreviewZoom() {
        this.toggleOptionsProp('previewZoom');
    }
    changePreviewRotate() {
        this.toggleOptionsProp('previewRotate');
    }
    changePreviewDownload() {
        this.toggleOptionsProp('previewDownload');
    }
    changeImageSwipe() {
        this.toggleOptionsProp('imageSwipe');
    }
    changeThumbnailsSwipe() {
        this.toggleOptionsProp('thumbnailsSwipe');
    }
    changePreviewSwipe() {
        this.toggleOptionsProp('previewSwipe');
    }
    resetThumbnails() {
        if (this.thubmnails) {
            this.thubmnails.reset(this.currentOptions.startIndex);
        }
    }
    select(index) {
        this.selectedIndex = index;
        this.onChange.emit({
            index,
            image: this.images[index]
        });
    }
    checkFullWidth() {
        if (this.currentOptions && this.currentOptions.fullWidth) {
            this.width = document.body.clientWidth + 'px';
            this.left = (-(document.body.clientWidth -
                this.myElement.nativeElement.parentNode.innerWidth) / 2) + 'px';
        }
    }
    setBreakpoint() {
        this.prevBreakpoint = this.breakpoint;
        let breakpoints;
        if (typeof window !== 'undefined') {
            breakpoints = this.options.filter((opt) => opt.breakpoint >= window.innerWidth)
                .map((opt) => opt.breakpoint);
        }
        if (breakpoints && breakpoints.length) {
            this.breakpoint = breakpoints.pop();
        }
        else {
            this.breakpoint = undefined;
        }
    }
    setOptions() {
        this.currentOptions = new GalleryOptions({});
        this.options
            .filter((opt) => opt.breakpoint === undefined || opt.breakpoint >= this.breakpoint)
            .forEach((opt) => this.combineOptions(this.currentOptions, opt));
        this.width = this.currentOptions.width;
        if (!Util$1.isDefined(this.currentOptions.aspectRatio)) {
            this.height = this.currentOptions.height;
        }
    }
    combineOptions(first, second) {
        Object.keys(second).forEach((val) => first[val] = second[val] !== undefined ? second[val] : first[val]);
    }
    changeOptionsProp(prop, newValue) {
        this.options = this.options.map(o => {
            o[prop] = newValue;
            return o;
        });
    }
    toggleOptionsProp(prop) {
        this.options = this.options.map(o => {
            o[prop] = !o[prop];
            return o;
        });
    }
    openGalleryPreview(index) {
        if (!this.previewComponentPortal) {
            this.previewComponentPortal = new ComponentPortal(GalleryPreviewComponent, this.viewContainerRef);
        }
        if (!this.galleryOverlayRef) {
            this.createGalleryOverlay(index);
        }
        if (!this.galleryOverlayRef.hasAttached()) {
            this.galleryOverlayRef.attach(this.previewComponentPortal);
            // Update the position once the calendar has rendered.
            this.ngZone.onStable.asObservable().pipe(take(1)).subscribe(() => {
                this.galleryOverlayRef.updatePosition();
            });
        }
    }
    /** Create the popup. */
    createGalleryOverlay(index) {
        const overlayConfig = new OverlayConfig({
            hasBackdrop: true,
            backdropClass: 'mat-overlay-transparent-backdrop',
            panelClass: 'gallery-preview-popup',
            scrollStrategy: this.scrollStrategy.close(),
            height: '100%',
            width: '100%'
        });
        this.galleryOverlayRef = this.overlay.create(overlayConfig);
        this.attachGalleryPreview(this.galleryOverlayRef, index);
        merge(this.galleryOverlayRef.backdropClick(), this.galleryOverlayRef.detachments(), this.galleryOverlayRef.keydownEvents().pipe(filter(event => {
            return event.code === 'Escape' ||
                (this.myElement && event.altKey && event.code === 'ArrowUp');
        }))).subscribe(() => this.previewClosed());
    }
    attachGalleryPreview(overlay, index) {
        const galleryPreviewContent = overlay.attach(new ComponentPortal(GalleryPreviewComponent));
        galleryPreviewContent.instance.images = this.bigImages;
        galleryPreviewContent.instance.descriptions = this.descriptions;
        galleryPreviewContent.instance.showDescription = this.currentOptions.previewDescription;
        galleryPreviewContent.instance.arrowPrevIcon = this.currentOptions.arrowPrevIcon;
        galleryPreviewContent.instance.arrowNextIcon = this.currentOptions.arrowNextIcon;
        galleryPreviewContent.instance.closeIcon = this.currentOptions.closeIcon;
        galleryPreviewContent.instance.fullscreenIcon = this.currentOptions.fullscreenIcon;
        galleryPreviewContent.instance.spinnerIcon = this.currentOptions.spinnerIcon;
        galleryPreviewContent.instance.arrows = this.currentOptions.previewArrows;
        galleryPreviewContent.instance.arrowsAutoHide = this.currentOptions.previewArrowsAutoHide;
        galleryPreviewContent.instance.swipe = this.currentOptions.previewSwipe;
        galleryPreviewContent.instance.fullscreen = this.currentOptions.previewFullscreen;
        galleryPreviewContent.instance.forceFullscreen = this.currentOptions.previewForceFullscreen;
        galleryPreviewContent.instance.closeOnClick = this.currentOptions.previewCloseOnClick;
        galleryPreviewContent.instance.closeOnEsc = this.currentOptions.previewCloseOnEsc;
        galleryPreviewContent.instance.keyboardNavigation = this.currentOptions.previewKeyboardNavigation;
        galleryPreviewContent.instance.animation = this.currentOptions.previewAnimation;
        galleryPreviewContent.instance.autoPlay = this.currentOptions.imageAutoPlay;
        galleryPreviewContent.instance.autoPlayInterval = this.currentOptions.imageAutoPlayInterval;
        galleryPreviewContent.instance.autoPlayPauseOnHover = this.currentOptions.imageAutoPlayPauseOnHover;
        galleryPreviewContent.instance.infinityMove = this.currentOptions.previewInfinityMove;
        galleryPreviewContent.instance.zoom = this.currentOptions.previewZoom;
        galleryPreviewContent.instance.zoomStep = this.currentOptions.previewZoomStep;
        galleryPreviewContent.instance.zoomMax = this.currentOptions.previewZoomMax;
        galleryPreviewContent.instance.zoomMin = this.currentOptions.previewZoomMin;
        galleryPreviewContent.instance.zoomInIcon = this.currentOptions.zoomInIcon;
        galleryPreviewContent.instance.zoomOutIcon = this.currentOptions.zoomOutIcon;
        galleryPreviewContent.instance.actions = this.currentOptions.actions;
        galleryPreviewContent.instance.rotate = this.currentOptions.previewRotate;
        galleryPreviewContent.instance.rotateLeftIcon = this.currentOptions.rotateLeftIcon;
        galleryPreviewContent.instance.rotateRightIcon = this.currentOptions.rotateRightIcon;
        galleryPreviewContent.instance.download = this.currentOptions.previewDownload;
        galleryPreviewContent.instance.downloadIcon = this.currentOptions.downloadIcon;
        galleryPreviewContent.instance.previewEnabled = this.previewEnabled;
        galleryPreviewContent.instance.aspectRatio = this.aspectRatio;
        this.subscription.add(galleryPreviewContent.instance.onClose.subscribe(() => this.previewClosed()));
        this.subscription.add(galleryPreviewContent.instance.onOpen.subscribe(() => this.previewOpened()));
        this.subscription.add(galleryPreviewContent.instance.onActiveChange.subscribe((arg) => this.previewSelect(arg)));
        galleryPreviewContent.instance.open(index || 0);
    }
    static { this.ɵfac = function GalleryComponent_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || GalleryComponent)(i0.ɵɵdirectiveInject(i0.ViewContainerRef), i0.ɵɵdirectiveInject(i0.ElementRef), i0.ɵɵdirectiveInject(i0.Injector)); }; }
    static { this.ɵcmp = /*@__PURE__*/ i0.ɵɵdefineComponent({ type: GalleryComponent, selectors: [["o-gallery"]], viewQuery: function GalleryComponent_Query(rf, ctx) { if (rf & 1) {
            i0.ɵɵviewQuery(GalleryImageComponent, 5);
            i0.ɵɵviewQuery(GalleryThumbnailsComponent, 5);
        } if (rf & 2) {
            let _t;
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.galleryMainImage = _t.first);
            i0.ɵɵqueryRefresh(_t = i0.ɵɵloadQuery()) && (ctx.thubmnails = _t.first);
        } }, hostVars: 6, hostBindings: function GalleryComponent_HostBindings(rf, ctx) { if (rf & 1) {
            i0.ɵɵlistener("resize", function GalleryComponent_resize_HostBindingHandler() { return ctx.onResize(); }, false, i0.ɵɵresolveWindow);
        } if (rf & 2) {
            i0.ɵɵstyleProp("width", ctx.width)("height", ctx.height)("left", ctx.left);
        } }, inputs: { options: [0, "gallery-options", "options"], images: [0, "gallery-images", "images"] }, outputs: { onImagesReady: "onImagesReady", onChange: "onChange", onPreviewOpen: "onPreviewOpen", onPreviewClose: "onPreviewClose", onPreviewChange: "onPreviewChange" }, standalone: true, features: [i0.ɵɵProvidersFeature([GalleryHelperService]), i0.ɵɵStandaloneFeature], decls: 3, vars: 5, consts: [["thumbnails", ""], [3, "height", "width", "images", "aspectRatio", "clickable", "selected-index", "arrows", "arrows-auto-hide", "arrow-prev-icon", "arrow-next-icon", "swipe", "animation", "size", "auto-play", "auto-play-interval", "auto-play-pause-on-hover", "infinity-move", "lazy-loading", "actions", "descriptions", "show-description", "bullets", "onClick", "onActiveChange", 4, "ngIf"], [3, "marginTop", "marginBottom", "marginRight", "marginLeft", "height", "width", "images", "links", "labels", "link-target", "selected-index", "columns", "rows", "margin", "arrows", "arrows-auto-hide", "arrow-prev-icon", "arrow-next-icon", "clickable", "swipe", "size", "move-size", "order", "remaining-count", "lazy-loading", "actions", "layout", "onActiveChange", 4, "ngIf"], [3, "onClick", "onActiveChange", "images", "clickable", "selected-index", "arrows", "arrows-auto-hide", "arrow-prev-icon", "arrow-next-icon", "swipe", "animation", "size", "auto-play", "auto-play-interval", "auto-play-pause-on-hover", "infinity-move", "lazy-loading", "actions", "descriptions", "show-description", "bullets"], [3, "onActiveChange", "images", "links", "labels", "link-target", "selected-index", "columns", "rows", "margin", "arrows", "arrows-auto-hide", "arrow-prev-icon", "arrow-next-icon", "clickable", "swipe", "size", "move-size", "order", "remaining-count", "lazy-loading", "actions", "layout"]], template: function GalleryComponent_Template(rf, ctx) { if (rf & 1) {
            i0.ɵɵelementStart(0, "div");
            i0.ɵɵtemplate(1, GalleryComponent_o_gallery_image_1_Template, 1, 25, "o-gallery-image", 1)(2, GalleryComponent_o_gallery_thumbnails_2_Template, 2, 34, "o-gallery-thumbnails", 2);
            i0.ɵɵelementEnd();
        } if (rf & 2) {
            i0.ɵɵclassMapInterpolate1("o-gallery-layout ", ctx.currentOptions == null ? null : ctx.currentOptions.layout, "");
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.currentOptions == null ? null : ctx.currentOptions.image);
            i0.ɵɵadvance();
            i0.ɵɵproperty("ngIf", ctx.currentOptions == null ? null : ctx.currentOptions.thumbnails);
        } }, dependencies: [CommonModule, i3.NgIf, GalleryImageComponent, GalleryThumbnailsComponent], styles: ["[_nghost-%COMP%]{display:inline-block;z-index:0}[_nghost-%COMP%] > *[_ngcontent-%COMP%]{float:left}[_nghost-%COMP%]     *{box-sizing:border-box}[_nghost-%COMP%]     .o-gallery-icon{font-family:Material Icons,sans-serif;position:absolute;z-index:2000;display:inline-block}[_nghost-%COMP%]     .o-gallery-icon .o-gallery-icon-content{border-radius:50%;display:block}[_nghost-%COMP%]     .o-gallery-clickable{cursor:pointer}[_nghost-%COMP%]     .o-gallery-icons-wrapper .o-gallery-icon{position:relative;margin-right:5px;margin-top:5px;font-size:20px;cursor:pointer}[_nghost-%COMP%]     .o-gallery-icons-wrapper{float:right}[_nghost-%COMP%]   .o-gallery-layout[_ngcontent-%COMP%]{width:100%;height:100%;display:flex;flex-direction:column}[_nghost-%COMP%]   .o-gallery-layout.thumbnails-left[_ngcontent-%COMP%]{flex-direction:row-reverse;justify-content:space-between}[_nghost-%COMP%]   .o-gallery-layout.thumbnails-right[_ngcontent-%COMP%]{flex-direction:row;justify-content:space-between}[_nghost-%COMP%]   .o-gallery-layout.thumbnails-top[_ngcontent-%COMP%]   o-gallery-image[_ngcontent-%COMP%]{order:2}[_nghost-%COMP%]   .o-gallery-layout.thumbnails-top[_ngcontent-%COMP%]   o-gallery-thumbnails[_ngcontent-%COMP%]{order:1}[_nghost-%COMP%]   .o-gallery-layout.thumbnails-bottom[_ngcontent-%COMP%]   o-gallery-image[_ngcontent-%COMP%]{order:1}[_nghost-%COMP%]   .o-gallery-layout.thumbnails-bottom[_ngcontent-%COMP%]   o-gallery-thumbnails[_ngcontent-%COMP%]{order:2}"] }); }
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(GalleryComponent, [{
        type: Component,
        args: [{ selector: 'o-gallery', standalone: true, imports: [CommonModule, GalleryImageComponent, GalleryThumbnailsComponent], providers: [GalleryHelperService], inputs: DEFAULT_INPUTS_O_GALLERY, outputs: DEFAULT_OUTPUTS_O_GALLERY, template: "<div class=\"o-gallery-layout {{currentOptions?.layout}}\">\r\n  <o-gallery-image *ngIf=\"currentOptions?.image\"\r\n    [style.height]=\"imageHeight\"\r\n    [style.width]=\"(currentOptions?.thumbnails && (currentOptions?.layout === 'thumbnails-left' || currentOptions?.layout === 'thumbnails-right')) ? currentOptions.imagePercent + '%' : '100%'\"\r\n    [images]=\"mediumImages\" [style.aspectRatio]=\"aspectRatio?aspectRatio:undefined\" [clickable]=\"currentOptions?.preview\"\r\n    [selected-index]=\"selectedIndex\" [arrows]=\"currentOptions?.imageArrows\" [arrows-auto-hide]=\"currentOptions?.imageArrowsAutoHide\"\r\n    [arrow-prev-icon]=\"currentOptions?.arrowPrevIcon\" [arrow-next-icon]=\"currentOptions?.arrowNextIcon\" [swipe]=\"currentOptions?.imageSwipe\"\r\n    [animation]=\"currentOptions?.imageAnimation\" [size]=\"currentOptions?.imageSize\" [auto-play]=\"currentOptions?.imageAutoPlay\"\r\n    [auto-play-interval]=\"currentOptions?.imageAutoPlayInterval\" [auto-play-pause-on-hover]=\"currentOptions?.imageAutoPlayPauseOnHover\"\r\n    [infinity-move]=\"currentOptions?.imageInfinityMove\" [lazy-loading]=\"currentOptions?.lazyLoading\" [actions]=\"currentOptions?.imageActions\"\r\n    [descriptions]=\"descriptions\" [show-description]=\"currentOptions?.imageDescription\" [bullets]=\"currentOptions?.imageBullets\"\r\n    (onClick)=\"openPreview($event)\" (onActiveChange)=\"selectFromImage($event)\"></o-gallery-image>\r\n  <o-gallery-thumbnails #thumbnails *ngIf=\"currentOptions?.thumbnails\"\r\n    [style.marginTop]=\"(currentOptions?.layout === 'thumbnails-bottom') ? currentOptions?.thumbnailsMargin + 'px' : '0px'\"\r\n    [style.marginBottom]=\"(currentOptions?.layout === 'thumbnails-top') ? currentOptions?.thumbnailsMargin + 'px' : '0px'\"\r\n    [style.marginRight]=\"(currentOptions?.layout === 'thumbnails-left'? currentOptions?.thumbnailsMargin + 'px' : '0px')\"\r\n    [style.marginLeft]=\"(currentOptions?.layout === 'thumbnails-right'? currentOptions?.thumbnailsMargin + 'px' : '0px')\"\r\n    [style.height]=\"thumbnailHeight\"\r\n    [style.width]=\"(currentOptions?.image && (currentOptions?.layout === 'thumbnails-left' || currentOptions?.layout === 'thumbnails-right') ) ? 'calc(' + currentOptions?.thumbnailsPercent + '% - ' + currentOptions?.thumbnailsMargin + 'px)' : '100%'\"\r\n    [images]=\"smallImages\" [links]=\"currentOptions?.thumbnailsAsLinks ? links : []\" [labels]=\"labels\" [link-target]=\"currentOptions?.linkTarget\"\r\n    [selected-index]=\"selectedIndex\" [columns]=\"currentOptions?.thumbnailsColumns\" [rows]=\"currentOptions?.thumbnailsRows\"\r\n    [margin]=\"currentOptions?.thumbnailMargin\" [arrows]=\"currentOptions?.thumbnailsArrows\"\r\n    [arrows-auto-hide]=\"currentOptions?.thumbnailsArrowsAutoHide\" [arrow-prev-icon]=\"currentOptions?.arrowPrevIcon\"\r\n    [arrow-next-icon]=\"currentOptions?.arrowNextIcon\" [clickable]=\"currentOptions?.image || currentOptions?.preview\"\r\n    [swipe]=\"currentOptions?.thumbnailsSwipe\" [size]=\"currentOptions?.thumbnailSize\" [move-size]=\"currentOptions?.thumbnailsMoveSize\"\r\n    [order]=\"currentOptions?.thumbnailsOrder\" [remaining-count]=\"currentOptions?.thumbnailsRemainingCount\"\r\n    [lazy-loading]=\"currentOptions?.lazyLoading\" [actions]=\"currentOptions?.thumbnailActions\" (onActiveChange)=\"selectFromThumbnails($event)\"\r\n    [layout]=\"currentOptions?.layout\">\r\n  </o-gallery-thumbnails>\r\n</div>\r\n", styles: [":host{display:inline-block;z-index:0}:host>*{float:left}:host ::ng-deep *{box-sizing:border-box}:host ::ng-deep .o-gallery-icon{font-family:Material Icons,sans-serif;position:absolute;z-index:2000;display:inline-block}:host ::ng-deep .o-gallery-icon .o-gallery-icon-content{border-radius:50%;display:block}:host ::ng-deep .o-gallery-clickable{cursor:pointer}:host ::ng-deep .o-gallery-icons-wrapper .o-gallery-icon{position:relative;margin-right:5px;margin-top:5px;font-size:20px;cursor:pointer}:host ::ng-deep .o-gallery-icons-wrapper{float:right}:host .o-gallery-layout{width:100%;height:100%;display:flex;flex-direction:column}:host .o-gallery-layout.thumbnails-left{flex-direction:row-reverse;justify-content:space-between}:host .o-gallery-layout.thumbnails-right{flex-direction:row;justify-content:space-between}:host .o-gallery-layout.thumbnails-top o-gallery-image{order:2}:host .o-gallery-layout.thumbnails-top o-gallery-thumbnails{order:1}:host .o-gallery-layout.thumbnails-bottom o-gallery-image{order:1}:host .o-gallery-layout.thumbnails-bottom o-gallery-thumbnails{order:2}\n"] }]
    }], () => [{ type: i0.ViewContainerRef }, { type: i0.ElementRef }, { type: i0.Injector }], { galleryMainImage: [{
            type: ViewChild,
            args: [GalleryImageComponent]
        }], thubmnails: [{
            type: ViewChild,
            args: [GalleryThumbnailsComponent]
        }], width: [{
            type: HostBinding,
            args: ['style.width']
        }], height: [{
            type: HostBinding,
            args: ['style.height']
        }], left: [{
            type: HostBinding,
            args: ['style.left']
        }], onResize: [{
            type: HostListener,
            args: ['window:resize']
        }] }); })();
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassDebugInfo(GalleryComponent, { className: "GalleryComponent", filePath: "lib\\components\\gallery\\o-gallery.component.ts", lineNumber: 55 }); })();

const OGALLERY_DIRECTIVES = [
    GalleryActionComponent,
    GalleryArrowsComponent,
    GalleryBulletsComponent,
    GalleryImageComponent,
    GalleryImageDirective,
    GalleryThumbnailsComponent,
    GalleryPreviewComponent,
    GalleryComponent
];

class GalleryImage {
    constructor(obj) {
        this.small = obj.small;
        this.medium = obj.medium;
        this.big = obj.big;
        this.description = obj.description;
        this.url = obj.url;
        this.type = obj.type;
        this.label = obj.label;
    }
}

class CustomHammerConfig extends HammerGestureConfig {
    constructor() {
        super(...arguments);
        this.overrides = {
            'pinch': { enable: false },
            'rotate': { enable: false }
        };
    }
    static { this.ɵfac = /*@__PURE__*/ (() => { let ɵCustomHammerConfig_BaseFactory; return function CustomHammerConfig_Factory(__ngFactoryType__) { return (ɵCustomHammerConfig_BaseFactory || (ɵCustomHammerConfig_BaseFactory = i0.ɵɵgetInheritedFactory(CustomHammerConfig)))(__ngFactoryType__ || CustomHammerConfig); }; })(); }
    static { this.ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: CustomHammerConfig, factory: CustomHammerConfig.ɵfac }); }
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(CustomHammerConfig, [{
        type: Injectable
    }], null, null); })();
class OGalleryModule {
    static { this.ɵfac = function OGalleryModule_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || OGalleryModule)(); }; }
    static { this.ɵmod = /*@__PURE__*/ i0.ɵɵdefineNgModule({ type: OGalleryModule }); }
    static { this.ɵinj = /*@__PURE__*/ i0.ɵɵdefineInjector({ providers: [{ provide: HAMMER_GESTURE_CONFIG, useClass: CustomHammerConfig }], imports: [GalleryArrowsComponent, GalleryBulletsComponent, GalleryImageComponent, GalleryThumbnailsComponent, GalleryPreviewComponent, GalleryComponent] }); }
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(OGalleryModule, [{
        type: NgModule,
        args: [{
                imports: [OGALLERY_DIRECTIVES],
                exports: [OGALLERY_DIRECTIVES],
                providers: [{ provide: HAMMER_GESTURE_CONFIG, useClass: CustomHammerConfig }]
            }]
    }], null, null); })();
(function () { (typeof ngJitMode === "undefined" || ngJitMode) && i0.ɵɵsetNgModuleScope(OGalleryModule, { imports: [GalleryActionComponent, GalleryArrowsComponent, GalleryBulletsComponent, GalleryImageComponent, GalleryImageDirective, GalleryThumbnailsComponent, GalleryPreviewComponent, GalleryComponent], exports: [GalleryActionComponent, GalleryArrowsComponent, GalleryBulletsComponent, GalleryImageComponent, GalleryImageDirective, GalleryThumbnailsComponent, GalleryPreviewComponent, GalleryComponent] }); })();

/*
 * Public API Surface of ontimize-web-ngx-gallery
 */

/**
 * Generated bundle index. Do not edit.
 */

export { CustomHammerConfig, DEFAULT_INPUTS_O_GALLERY, DEFAULT_OUTPUTS_O_GALLERY, GalleryAction, GalleryActionComponent, GalleryAnimation, GalleryArrowsComponent, GalleryBulletsComponent, GalleryComponent, GalleryHelperService, GalleryImage, GalleryImageComponent, GalleryImageDirective, GalleryImageSize, GalleryLayout, GalleryOptions, GalleryOrder, GalleryOrderedImage, GalleryPreviewComponent, GalleryThumbnailsComponent, OGALLERY_DIRECTIVES, OGalleryModule };
//# sourceMappingURL=ontimize-web-ngx-gallery.mjs.map
