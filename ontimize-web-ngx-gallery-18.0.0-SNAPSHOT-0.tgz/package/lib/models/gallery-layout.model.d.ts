export declare class GalleryLayout {
    static ThumbnailsTop: string;
    static ThumbnailsBottom: string;
    static ThumbnailsLeft: string;
    static ThumbnailsRight: string;
}
export type GalleryLayouts = 'thumbnails-top' | 'thumbnails-bottom' | 'thumbnails-left' | 'thumbnails-right';
//# sourceMappingURL=gallery-layout.model.d.ts.map