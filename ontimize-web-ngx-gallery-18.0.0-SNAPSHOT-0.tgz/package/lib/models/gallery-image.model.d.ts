import { SafeResourceUrl } from '@angular/platform-browser';
import { IGalleryImage } from '../interfaces/IGalleryImage';
export declare class GalleryImage implements IGalleryImage {
    small?: string | SafeResourceUrl;
    medium: string | SafeResourceUrl;
    big?: string | SafeResourceUrl;
    description?: string;
    url?: string;
    type?: string;
    label?: string;
    constructor(obj: IGalleryImage);
}
//# sourceMappingURL=gallery-image.model.d.ts.map