export declare class GalleryAnimation {
    static Fade: string;
    static Slide: string;
    static Rotate: string;
    static Zoom: string;
}
//# sourceMappingURL=gallery-animation.model.d.ts.map