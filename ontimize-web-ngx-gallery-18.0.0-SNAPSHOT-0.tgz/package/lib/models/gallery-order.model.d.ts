export declare class GalleryOrder {
    static Column: number;
    static Row: number;
    static Page: number;
}
//# sourceMappingURL=gallery-order.model.d.ts.map