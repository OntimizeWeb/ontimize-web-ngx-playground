import { SafeResourceUrl } from '@angular/platform-browser';
import { IGalleryOrderedImage } from '../interfaces/IGalleryOrderedImage';
export declare class GalleryOrderedImage implements IGalleryOrderedImage {
    src: string | SafeResourceUrl;
    type: string;
    index: number;
    constructor(obj: IGalleryOrderedImage);
}
//# sourceMappingURL=gallery-ordered-image.model.d.ts.map