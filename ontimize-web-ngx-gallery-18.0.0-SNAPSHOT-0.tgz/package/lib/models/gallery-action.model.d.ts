import { IGalleryAction } from '../interfaces/IGalleryAction';
export declare class GalleryAction implements IGalleryAction {
    icon: string;
    disabled?: boolean;
    titleText?: string;
    onClick: (event: Event, index: number) => void;
    constructor(action: IGalleryAction);
}
//# sourceMappingURL=gallery-action.model.d.ts.map