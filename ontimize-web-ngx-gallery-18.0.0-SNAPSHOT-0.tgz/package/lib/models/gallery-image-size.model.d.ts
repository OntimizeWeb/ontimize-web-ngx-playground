export declare class GalleryImageSize {
    static Cover: string;
    static Contain: string;
}
//# sourceMappingURL=gallery-image-size.model.d.ts.map