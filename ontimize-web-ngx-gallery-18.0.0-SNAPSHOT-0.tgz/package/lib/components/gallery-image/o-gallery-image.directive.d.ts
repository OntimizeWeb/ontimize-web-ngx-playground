import { DomSanitizer, SafeResourceUrl, SafeStyle } from '@angular/platform-browser';
import { GalleryHelperService } from '../../services';
import * as i0 from "@angular/core";
export declare class GalleryImageDirective {
    sanitization: DomSanitizer;
    private helperService;
    set image(val: string | SafeResourceUrl);
    get imgage(): string | SafeResourceUrl;
    private _image;
    src: SafeStyle;
    constructor(sanitization: DomSanitizer, helperService: GalleryHelperService);
    static ɵfac: i0.ɵɵFactoryDeclaration<GalleryImageDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<GalleryImageDirective, "[oGalleryBackgroundImg]", never, { "image": { "alias": "oGalleryBackgroundImg"; "required": false; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=o-gallery-image.directive.d.ts.map