import { EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
export declare class GalleryBulletsComponent {
    count: number;
    active: number;
    onChange: EventEmitter<any>;
    handleChange(_event: Event, index: number): void;
    getBullets(): number[];
    static ɵfac: i0.ɵɵFactoryDeclaration<GalleryBulletsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GalleryBulletsComponent, "o-gallery-bullets", never, { "count": { "alias": "count"; "required": false; }; "active": { "alias": "active"; "required": false; }; }, { "onChange": "onChange"; }, never, never, true, never>;
}
//# sourceMappingURL=o-gallery-bullets.component.d.ts.map