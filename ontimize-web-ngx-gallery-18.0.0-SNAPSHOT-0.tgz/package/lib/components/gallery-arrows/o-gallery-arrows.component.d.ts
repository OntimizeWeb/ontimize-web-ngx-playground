import { EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import * as i0 from "@angular/core";
export declare class GalleryArrowsComponent implements OnChanges {
    prevDisabled: boolean;
    nextDisabled: boolean;
    arrowPrevIcon: string;
    arrowNextIcon: string;
    layout: string;
    position: string;
    onPrevClick: EventEmitter<any>;
    onNextClick: EventEmitter<any>;
    constructor();
    ngOnChanges(changes: SimpleChanges): void;
    updatePosition(): void;
    handlePrevClick(): void;
    handleNextClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<GalleryArrowsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<GalleryArrowsComponent, "o-gallery-arrows", never, { "prevDisabled": { "alias": "prev-disabled"; "required": false; }; "nextDisabled": { "alias": "next-disabled"; "required": false; }; "arrowPrevIcon": { "alias": "arrow-prev-icon"; "required": false; }; "arrowNextIcon": { "alias": "arrow-next-icon"; "required": false; }; "layout": { "alias": "layout"; "required": false; }; }, { "onPrevClick": "onPrevClick"; "onNextClick": "onNextClick"; }, never, never, true, never>;
}
//# sourceMappingURL=o-gallery-arrows.component.d.ts.map