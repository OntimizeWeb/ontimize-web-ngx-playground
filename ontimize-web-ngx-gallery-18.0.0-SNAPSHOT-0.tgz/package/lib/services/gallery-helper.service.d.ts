import { ElementRef, Renderer2 } from '@angular/core';
import * as i0 from "@angular/core";
export declare class GalleryHelperService {
    private renderer;
    private swipeHandlers;
    constructor(renderer: Renderer2);
    manageSwipe(status: boolean, element: ElementRef, id: string, nextHandler: Function, prevHandler: Function): void;
    validateUrl(url: string): string;
    getBackgroundUrl(image: string): string;
    private getSwipeHandlers;
    private removeSwipeHandlers;
    getFileType(fileSource: string): string;
    /**
     * Gets file type by mime
     * @param fileSource
     * @returns file type by mime
     */
    getFileTypeByMime(fileSource: string): string;
    /**
     * Gets file type by URL
     * @param url
     * @returns file type by URL
     */
    getFileTypeByURL(url: URL): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<GalleryHelperService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<GalleryHelperService>;
}
//# sourceMappingURL=gallery-helper.service.d.ts.map