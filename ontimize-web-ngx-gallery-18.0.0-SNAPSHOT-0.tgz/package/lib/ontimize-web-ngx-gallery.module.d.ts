import { HammerGestureConfig } from '@angular/platform-browser';
import * as i0 from "@angular/core";
import * as i1 from "./components/gallery-action/o-gallery-action.component";
import * as i2 from "./components/gallery-arrows/o-gallery-arrows.component";
import * as i3 from "./components/gallery-bullets/o-gallery-bullets.component";
import * as i4 from "./components/gallery-image/o-gallery-image.component";
import * as i5 from "./components/gallery-image/o-gallery-image.directive";
import * as i6 from "./components/gallery-thumbnails/o-gallery-thumbnails.component";
import * as i7 from "./components/gallery-preview/o-gallery-preview.component";
import * as i8 from "./components/gallery/o-gallery.component";
export * from './interfaces';
export * from './services';
export * from './models';
export * from './components';
export declare class CustomHammerConfig extends HammerGestureConfig {
    overrides: any;
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomHammerConfig, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CustomHammerConfig>;
}
export declare class OGalleryModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OGalleryModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OGalleryModule, never, [typeof i1.GalleryActionComponent, typeof i2.GalleryArrowsComponent, typeof i3.GalleryBulletsComponent, typeof i4.GalleryImageComponent, typeof i5.GalleryImageDirective, typeof i6.GalleryThumbnailsComponent, typeof i7.GalleryPreviewComponent, typeof i8.GalleryComponent], [typeof i1.GalleryActionComponent, typeof i2.GalleryArrowsComponent, typeof i3.GalleryBulletsComponent, typeof i4.GalleryImageComponent, typeof i5.GalleryImageDirective, typeof i6.GalleryThumbnailsComponent, typeof i7.GalleryPreviewComponent, typeof i8.GalleryComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OGalleryModule>;
}
//# sourceMappingURL=ontimize-web-ngx-gallery.module.d.ts.map