export declare class Util {
    static isUrl(fileSource: string): boolean;
    /**
    * Determines whether url absolute is
    * @param url
    * @returns
    */
    static isUrlAbsolute(url: string): boolean;
    static getMimeType(fileSource: string): string;
}
//# sourceMappingURL=util.d.ts.map