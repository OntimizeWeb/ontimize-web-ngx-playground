export * from './components/gallery-action/o-gallery-action.component';
export * from './components/gallery-arrows/o-gallery-arrows.component';
export * from './components/gallery-bullets/o-gallery-bullets.component';
export * from './components/gallery-image/o-gallery-image.component';
export * from './components/gallery-preview/o-gallery-preview.component';
export * from './components/gallery-thumbnails/o-gallery-thumbnails.component';
export * from './components/gallery/o-gallery.component';
export declare const OGALLERY_DIRECTIVES: any[];
//# sourceMappingURL=components.d.ts.map