export * from './lib/ontimize-web-ngx-gallery.module';
export * from './lib/components/gallery-image/index';
//# sourceMappingURL=public-api.d.ts.map