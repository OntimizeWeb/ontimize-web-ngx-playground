/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="ontimize-web-ngx-gallery" />
export * from './public-api';
//# sourceMappingURL=ontimize-web-ngx-gallery.d.ts.map