import { ElementRef, EventEmitter, Renderer2 } from '@angular/core';
import type { OGridComponent } from '../o-grid.component';
import * as i0 from "@angular/core";
export declare class OGridItemDirective {
    _el: ElementRef;
    private renderer;
    mdClick: EventEmitter<any>;
    mdDoubleClick: EventEmitter<any>;
    modelData: object;
    protected grid: OGridComponent;
    onMouseEnter(): void;
    constructor(_el: ElementRef, renderer: Renderer2);
    onClick(onNext: (item: OGridItemDirective) => void): object;
    onDoubleClick(onNext: (item: OGridItemDirective) => void): object;
    onItemClicked(e?: Event): void;
    onItemDoubleClicked(e?: Event): void;
    setItemData(data: object): void;
    getItemData(): object;
    setGridComponent(grid: OGridComponent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OGridItemDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<OGridItemDirective, "mat-grid-tile[o-grid-item]", never, {}, {}, never, never, true, never>;
}
//# sourceMappingURL=o-grid-item.directive.d.ts.map