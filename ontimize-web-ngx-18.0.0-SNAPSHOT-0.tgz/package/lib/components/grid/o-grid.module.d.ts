import * as i0 from "@angular/core";
import * as i1 from "./o-grid.component";
import * as i2 from "./grid-item/o-grid-item.directive";
import * as i3 from "./grid-item/o-grid-item.component";
import * as i4 from "./skeketon/o-grid-skeleton.component";
export declare class OGridModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OGridModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OGridModule, never, [typeof i1.OGridComponent, typeof i2.OGridItemDirective, typeof i3.OGridItemComponent, typeof i4.OGridSkeletonComponent], [typeof i1.OGridComponent, typeof i3.OGridItemComponent, typeof i2.OGridItemDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OGridModule>;
}
//# sourceMappingURL=o-grid.module.d.ts.map