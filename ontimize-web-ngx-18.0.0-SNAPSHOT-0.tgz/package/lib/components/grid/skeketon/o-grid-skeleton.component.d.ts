import { ORepeatableSkeletonComponent } from '../../o-repeatable-skeleton.component';
import * as i0 from "@angular/core";
export declare class OGridSkeletonComponent extends ORepeatableSkeletonComponent {
    getParentElement(): HTMLElement;
    getSkeletonItemElement(parentElement: HTMLElement): HTMLElement;
    static ɵfac: i0.ɵɵFactoryDeclaration<OGridSkeletonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OGridSkeletonComponent, "o-grid-skeleton", never, {}, {}, never, never, true, never>;
}
//# sourceMappingURL=o-grid-skeleton.component.d.ts.map