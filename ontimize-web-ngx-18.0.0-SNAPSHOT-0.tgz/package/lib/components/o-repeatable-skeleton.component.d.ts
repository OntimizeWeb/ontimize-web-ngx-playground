import { OSkeletonComponent } from './o-skeleton.component';
import * as i0 from "@angular/core";
export declare abstract class ORepeatableSkeletonComponent extends OSkeletonComponent {
    abstract getParentElement(): HTMLElement;
    abstract getSkeletonItemElement(parentElement: HTMLElement): HTMLElement;
    getRows(): number[];
    static ɵfac: i0.ɵɵFactoryDeclaration<ORepeatableSkeletonComponent, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ORepeatableSkeletonComponent, never, never, {}, {}, never, never, true, never>;
}
//# sourceMappingURL=o-repeatable-skeleton.component.d.ts.map