import * as i0 from "@angular/core";
import * as i1 from "./o-currency-input.component";
export declare class OCurrencyInputModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OCurrencyInputModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OCurrencyInputModule, never, [typeof i1.OCurrencyInputComponent], [typeof i1.OCurrencyInputComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OCurrencyInputModule>;
}
//# sourceMappingURL=o-currency-input.module.d.ts.map