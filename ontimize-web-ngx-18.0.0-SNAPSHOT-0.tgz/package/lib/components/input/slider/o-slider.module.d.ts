import * as i0 from "@angular/core";
import * as i1 from "./o-slider.component";
export declare class OSliderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OSliderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OSliderModule, never, [typeof i1.OSliderComponent], [typeof i1.OSliderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OSliderModule>;
}
//# sourceMappingURL=o-slider.module.d.ts.map