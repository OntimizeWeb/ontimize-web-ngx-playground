import { ChangeDetectorRef, ElementRef, EventEmitter, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import moment from 'moment';
import * as i0 from "@angular/core";
export declare enum SideEnum {
    left = "left",
    right = "right"
}
export declare class DaterangepickerComponent implements OnInit {
    private _ref;
    private _old;
    chosenLabel: string;
    calendarVariables: {
        left: any;
        right: any;
    };
    timepickerVariables: {
        left: any;
        right: any;
    };
    daterangepicker: {
        start: FormControl;
        end: FormControl;
    };
    applyBtn: {
        disabled: boolean;
    };
    startDate: moment.Moment;
    endDate: moment.Moment;
    dateLimit: number;
    sideEnum: typeof SideEnum;
    minDate: moment.Moment;
    maxDate: moment.Moment;
    autoApply: boolean;
    singleDatePicker: boolean;
    showDropdowns: boolean;
    showWeekNumbers: boolean;
    showISOWeekNumbers: boolean;
    linkedCalendars: boolean;
    autoUpdateInput: boolean;
    alwaysShowCalendars: boolean;
    maxSpan: boolean;
    timePicker: boolean;
    timePicker24Hour: boolean;
    timePickerIncrement: number;
    timePickerSeconds: boolean;
    showClearButton: boolean;
    firstMonthDayClass: string;
    lastMonthDayClass: string;
    emptyWeekRowClass: string;
    firstDayOfNextMonthClass: string;
    lastDayOfPreviousMonthClass: string;
    locale: any;
    _ranges: any;
    set ranges(value: any);
    get ranges(): any;
    showCustomRangeLabel: boolean;
    showCancel: boolean;
    keepCalendarOpeningWithRange: boolean;
    showRangeLabelOnInput: boolean;
    chosenRange: string;
    rangesArray: Array<any>;
    pickingDate: boolean;
    isShown: boolean;
    inline: boolean;
    leftCalendar: any;
    rightCalendar: any;
    showCalInRanges: boolean;
    adjustedDaysOfWeek: any[];
    options: any;
    drops: string;
    opens: string;
    choosedDate: EventEmitter<object>;
    rangeClicked: EventEmitter<object>;
    datesUpdated: EventEmitter<object>;
    pickerContainer: ElementRef;
    constructor(_ref: ChangeDetectorRef);
    ngOnInit(): void;
    renderRanges(): void;
    renderTimePicker(side: SideEnum): void;
    renderCalendar(side: SideEnum): void;
    setStartDate(startDate: any): void;
    setEndDate(endDate: any): void;
    isInvalidDate(date: any): boolean;
    isCustomDate(date: any): boolean;
    updateView(): void;
    updateMonthsInView(): void;
    updateCalendars(): void;
    updateElement(): void;
    remove(): void;
    calculateChosenLabel(): void;
    clickApply(e?: any): void;
    clickCancel(e: any): void;
    monthChanged(monthEvent: any, side: SideEnum): void;
    yearChanged(yearEvent: any, side: SideEnum): void;
    timeChanged(timeEvent: any, side: SideEnum): void;
    monthOrYearChanged(month: number, year: number, side: SideEnum): void;
    clickPrev(side: SideEnum): void;
    clickNext(side: SideEnum): void;
    clickDate(e: any, side: SideEnum, row: number, col: number): void;
    clickRange(e: any, label: any): void;
    show(e?: any): void;
    hide(e?: any): void;
    handleInternalClick(e: any): void;
    updateLocale(locale: any): void;
    clear(): void;
    disableRange(range: any): any;
    private _getDateWithTime;
    private _buildLocale;
    private _buildCells;
    hasCurrentMonthDays(currentMonth: any, row: any): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<DaterangepickerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DaterangepickerComponent, "o-daterange-picker", never, { "dateLimit": { "alias": "dateLimit"; "required": false; }; "minDate": { "alias": "minDate"; "required": false; }; "maxDate": { "alias": "maxDate"; "required": false; }; "autoApply": { "alias": "autoApply"; "required": false; }; "singleDatePicker": { "alias": "singleDatePicker"; "required": false; }; "showDropdowns": { "alias": "showDropdowns"; "required": false; }; "showISOWeekNumbers": { "alias": "showISOWeekNumbers"; "required": false; }; "linkedCalendars": { "alias": "linkedCalendars"; "required": false; }; "autoUpdateInput": { "alias": "autoUpdateInput"; "required": false; }; "alwaysShowCalendars": { "alias": "alwaysShowCalendars"; "required": false; }; "maxSpan": { "alias": "maxSpan"; "required": false; }; "timePicker": { "alias": "timePicker"; "required": false; }; "timePicker24Hour": { "alias": "timePicker24Hour"; "required": false; }; "timePickerIncrement": { "alias": "timePickerIncrement"; "required": false; }; "timePickerSeconds": { "alias": "timePickerSeconds"; "required": false; }; "showClearButton": { "alias": "showClearButton"; "required": false; }; "firstMonthDayClass": { "alias": "firstMonthDayClass"; "required": false; }; "lastMonthDayClass": { "alias": "lastMonthDayClass"; "required": false; }; "emptyWeekRowClass": { "alias": "emptyWeekRowClass"; "required": false; }; "firstDayOfNextMonthClass": { "alias": "firstDayOfNextMonthClass"; "required": false; }; "lastDayOfPreviousMonthClass": { "alias": "lastDayOfPreviousMonthClass"; "required": false; }; "locale": { "alias": "locale"; "required": false; }; "ranges": { "alias": "ranges"; "required": false; }; "showCustomRangeLabel": { "alias": "showCustomRangeLabel"; "required": false; }; "showCancel": { "alias": "showCancel"; "required": false; }; "keepCalendarOpeningWithRange": { "alias": "keepCalendarOpeningWithRange"; "required": false; }; "showRangeLabelOnInput": { "alias": "showRangeLabelOnInput"; "required": false; }; "drops": { "alias": "drops"; "required": false; }; "opens": { "alias": "opens"; "required": false; }; "isInvalidDate": { "alias": "isInvalidDate"; "required": false; }; "isCustomDate": { "alias": "isCustomDate"; "required": false; }; }, { "choosedDate": "choosedDate"; "rangeClicked": "rangeClicked"; "datesUpdated": "datesUpdated"; }, never, never, true, never>;
}
//# sourceMappingURL=o-daterange-picker.component.d.ts.map