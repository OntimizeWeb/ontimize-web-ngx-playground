import * as i0 from "@angular/core";
import * as i1 from "./o-daterange-picker.component";
import * as i2 from "./o-daterange-input.component";
import * as i3 from "./o-daterange-input.directive";
export declare class ODateRangeLegacyInputModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ODateRangeLegacyInputModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ODateRangeLegacyInputModule, never, [typeof i1.DaterangepickerComponent, typeof i2.ODateRangeLegacyInputComponent, typeof i3.ODaterangepickerDirective], [typeof i2.ODateRangeLegacyInputComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ODateRangeLegacyInputModule>;
}
//# sourceMappingURL=o-daterange-input.module.d.ts.map