import { Injector, OnInit, PipeTransform, TemplateRef } from '@angular/core';
import { OListPickerComponent } from '../o-list-picker.component';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_LISTPICKER_RENDERER: any[];
export declare class OListPickerCustomRenderer implements OnInit {
    protected injector: Injector;
    templateref: TemplateRef<any>;
    listpickerComponent: OListPickerComponent;
    protected pipeArguments: any;
    protected componentPipe: PipeTransform;
    constructor(injector: Injector);
    ngOnInit(): void;
    initialize(): void;
    ngAfterContentInit(): void;
    registerRenderer(): void;
    getListPickerValue(record: any): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<OListPickerCustomRenderer, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<OListPickerCustomRenderer, never, never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=o-list-picker-renderer.class.d.ts.map