import { OListPickerRendererCurrencyComponent } from './currency/o-list-picker-renderer-currency.component';
import { OListPickerRendererDateComponent } from './date/o-list-picker-renderer-date.component';
import { OListPickerRendererIntegerComponent } from './integer/o-list-picker-renderer-integer.component';
import { OListPickerRendererPercentageComponent } from './percentage/o-list-picker-renderer-percentage.component';
import { OListPickerRendererRealComponent } from './real/o-list-picker-renderer-real.component';
export declare const O_LISTPICKER_RENDERERS: (typeof OListPickerRendererIntegerComponent | typeof OListPickerRendererCurrencyComponent | typeof OListPickerRendererDateComponent)[];
export declare const O_LISTPICKER_RENDERERS_INPUTS: any[];
export declare const O_LISTPICKER_RENDERERS_OUTPUTS: any[];
export declare const renderersMapping: {
    integer: typeof OListPickerRendererIntegerComponent;
    real: typeof OListPickerRendererRealComponent;
    currency: typeof OListPickerRendererCurrencyComponent;
    date: typeof OListPickerRendererDateComponent;
    percentage: typeof OListPickerRendererPercentageComponent;
};
//# sourceMappingURL=listpicker-renderer.d.ts.map