import { AfterViewInit, Injector } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { OSearchInputComponent } from '../../input/search-input/o-search-input.component';
import { OListPickerCustomRenderer } from './listpicker-renderer/o-list-picker-renderer.class';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_LIST_PICKER_DIALOG: string[];
export declare class OListPickerDialogComponent implements AfterViewInit {
    dialogRef: MatDialogRef<OListPickerDialogComponent>;
    protected injector: Injector;
    filter: boolean;
    visibleData: any;
    searchVal: string;
    itemSize: number;
    renderer: OListPickerCustomRenderer;
    searchInput: OSearchInputComponent;
    protected data: any[];
    menuColumns: string;
    protected visibleColsArray: string[];
    constructor(dialogRef: MatDialogRef<OListPickerDialogComponent>, injector: Injector, data: any);
    ngAfterViewInit(): void;
    onClickListItem(e: any, value: any): void;
    trackByFn(index: number, item: any): number;
    onFilterList(searchVal: any): void;
    isEmptyData(): boolean;
    private transform;
    private _isBlank;
    static ɵfac: i0.ɵɵFactoryDeclaration<OListPickerDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OListPickerDialogComponent, "o-list-picker-dialog", never, { "data": { "alias": "data"; "required": false; }; "visibleColumns": { "alias": "visible-columns"; "required": false; }; "filter": { "alias": "filter"; "required": false; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=o-list-picker-dialog.component.d.ts.map