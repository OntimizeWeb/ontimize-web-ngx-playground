import * as i0 from "@angular/core";
import * as i1 from "./o-list-picker-dialog.component";
import * as i2 from "./o-list-picker.component";
import * as i3 from "./listpicker-renderer/integer/o-list-picker-renderer-integer.component";
import * as i4 from "./listpicker-renderer/real/o-list-picker-renderer-real.component";
import * as i5 from "./listpicker-renderer/currency/o-list-picker-renderer-currency.component";
import * as i6 from "./listpicker-renderer/date/o-list-picker-renderer-date.component";
import * as i7 from "./listpicker-renderer/percentage/o-list-picker-renderer-percentage.component";
export declare class OListPickerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OListPickerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OListPickerModule, never, [typeof i1.OListPickerDialogComponent, typeof i2.OListPickerComponent, typeof i3.OListPickerRendererIntegerComponent, typeof i4.OListPickerRendererRealComponent, typeof i5.OListPickerRendererCurrencyComponent, typeof i6.OListPickerRendererDateComponent, typeof i7.OListPickerRendererPercentageComponent], [typeof i2.OListPickerComponent, typeof i3.OListPickerRendererIntegerComponent, typeof i4.OListPickerRendererRealComponent, typeof i5.OListPickerRendererCurrencyComponent, typeof i6.OListPickerRendererDateComponent, typeof i7.OListPickerRendererPercentageComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OListPickerModule>;
}
//# sourceMappingURL=o-list-picker.module.d.ts.map