import * as i0 from "@angular/core";
import * as i1 from "./o-real-input.component";
export declare class ORealInputModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ORealInputModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ORealInputModule, never, [typeof i1.ORealInputComponent], [typeof i1.ORealInputComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ORealInputModule>;
}
//# sourceMappingURL=o-real-input.module.d.ts.map