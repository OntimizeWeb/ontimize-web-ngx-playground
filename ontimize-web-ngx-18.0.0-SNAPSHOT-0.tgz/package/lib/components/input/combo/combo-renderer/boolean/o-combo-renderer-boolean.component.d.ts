import { Injector, OnInit, TemplateRef } from '@angular/core';
import { OTranslateService } from '../../../../../services/translate/o-translate.service';
import { OComboCustomRenderer } from '../o-combo-renderer.class';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_COMBO_RENDERER_BOOLEAN: string[];
export declare class OComboRendererBooleanComponent extends OComboCustomRenderer implements OnInit {
    protected injector: Injector;
    trueValue: any;
    falseValue: any;
    protected _renderTrueValue: any;
    protected _renderFalseValue: any;
    protected _renderType: string;
    protected _booleanType: string;
    protected translateService: OTranslateService;
    templateref: TemplateRef<any>;
    constructor(injector: Injector);
    initialize(): void;
    protected parseInputs(): void;
    protected parseStringInputs(): void;
    protected parseNumberInputs(): void;
    hasComboTrueValue(record: any): boolean;
    get booleanType(): string;
    set booleanType(arg: string);
    get renderType(): string;
    set renderType(arg: string);
    get renderTrueValue(): string;
    set renderTrueValue(arg: string);
    get renderFalseValue(): string;
    set renderFalseValue(arg: string);
    static ɵfac: i0.ɵɵFactoryDeclaration<OComboRendererBooleanComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OComboRendererBooleanComponent, "o-combo-renderer-boolean", never, { "trueValue": { "alias": "true-value"; "required": false; }; "falseValue": { "alias": "false-value"; "required": false; }; "booleanType": { "alias": "boolean-type"; "required": false; }; "renderTrueValue": { "alias": "render-true-value"; "required": false; }; "renderFalseValue": { "alias": "render-false-value"; "required": false; }; "renderType": { "alias": "render-type"; "required": false; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=o-combo-renderer-boolean.component.d.ts.map