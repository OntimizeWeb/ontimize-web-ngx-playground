import { AfterContentInit, Injector, OnInit, TemplateRef } from '@angular/core';
import { IIntegerPipeArgument, OIntegerPipe } from '../../../../../pipes/o-integer.pipe';
import { OComboCustomRenderer } from '../o-combo-renderer.class';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_COMBO_RENDERER_INTEGER: string[];
export declare class OComboRendererIntegerComponent extends OComboCustomRenderer implements AfterContentInit, OnInit {
    protected injector: Injector;
    protected grouping: boolean;
    protected thousandSeparator: string;
    protected componentPipe: OIntegerPipe;
    protected pipeArguments: IIntegerPipeArgument;
    templateref: TemplateRef<any>;
    constructor(injector: Injector);
    setComponentPipe(): void;
    initialize(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OComboRendererIntegerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OComboRendererIntegerComponent, "o-combo-renderer-integer", never, { "grouping": { "alias": "grouping"; "required": false; }; "thousandSeparator": { "alias": "thousand-separator"; "required": false; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=o-combo-renderer-integer.component.d.ts.map