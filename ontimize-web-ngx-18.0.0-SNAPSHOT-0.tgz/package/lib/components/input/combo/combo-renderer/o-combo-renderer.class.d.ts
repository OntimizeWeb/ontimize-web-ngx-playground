import { Injector, OnInit, PipeTransform, TemplateRef } from '@angular/core';
import { OComboComponent } from '../o-combo.component';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_COMBO_RENDERER: any[];
export declare class OComboCustomRenderer implements OnInit {
    protected injector: Injector;
    templateref: TemplateRef<any>;
    comboComponent: OComboComponent;
    protected pipeArguments: any;
    protected componentPipe: PipeTransform;
    constructor(injector: Injector);
    ngOnInit(): void;
    initialize(): void;
    ngAfterContentInit(): void;
    registerRenderer(): void;
    getComboData(record: any): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<OComboCustomRenderer, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<OComboCustomRenderer, never, never, {}, {}, never, never, false, never>;
}
//# sourceMappingURL=o-combo-renderer.class.d.ts.map