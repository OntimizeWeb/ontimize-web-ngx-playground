import * as i0 from "@angular/core";
import * as i1 from "./o-percent-input.component";
export declare class OPercentInputModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OPercentInputModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OPercentInputModule, never, [typeof i1.OPercentInputComponent], [typeof i1.OPercentInputComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OPercentInputModule>;
}
//# sourceMappingURL=o-percent-input.module.d.ts.map