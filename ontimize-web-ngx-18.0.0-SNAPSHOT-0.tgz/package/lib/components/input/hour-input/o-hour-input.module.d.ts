import * as i0 from "@angular/core";
import * as i1 from "./o-hour-input.component";
import * as i2 from "./o-hour-input.directive";
export declare class OHourInputModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OHourInputModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OHourInputModule, never, [typeof i1.OHourInputComponent, typeof i2.OHourTimepickerDirective], [typeof i1.OHourInputComponent, typeof i2.OHourTimepickerDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OHourInputModule>;
}
//# sourceMappingURL=o-hour-input.module.d.ts.map