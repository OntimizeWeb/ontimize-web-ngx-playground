import * as i0 from "@angular/core";
import * as i1 from "./o-date-input.component";
export declare class ODateInputModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ODateInputModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ODateInputModule, never, [typeof i1.ODateInputComponent], [typeof i1.ODateInputComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ODateInputModule>;
}
//# sourceMappingURL=o-date-input.module.d.ts.map