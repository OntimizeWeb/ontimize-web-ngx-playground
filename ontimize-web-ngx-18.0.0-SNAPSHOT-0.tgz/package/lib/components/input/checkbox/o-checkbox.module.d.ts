import * as i0 from "@angular/core";
import * as i1 from "./o-checkbox.component";
export declare class OCheckboxModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OCheckboxModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OCheckboxModule, never, [typeof i1.OCheckboxComponent], [typeof i1.OCheckboxComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OCheckboxModule>;
}
//# sourceMappingURL=o-checkbox.module.d.ts.map