import * as i0 from "@angular/core";
import * as i1 from "./o-daterange-input.component";
export declare class ODateRangeInputModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ODateRangeInputModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ODateRangeInputModule, never, [typeof i1.ODateRangeInputComponent], [typeof i1.ODateRangeInputComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ODateRangeInputModule>;
}
//# sourceMappingURL=o-daterange-input.module.d.ts.map