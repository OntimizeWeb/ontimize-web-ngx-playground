import * as i0 from "@angular/core";
import * as i1 from "./o-integer-input.component";
export declare class OIntegerInputModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OIntegerInputModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OIntegerInputModule, never, [typeof i1.OIntegerInputComponent], [typeof i1.OIntegerInputComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OIntegerInputModule>;
}
//# sourceMappingURL=o-integer-input.module.d.ts.map