import * as i0 from "@angular/core";
import * as i1 from "./o-form.component";
import * as i2 from "./toolbar/o-form-toolbar.module";
export declare class OFormModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OFormModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OFormModule, never, [typeof i1.OFormComponent, typeof i2.OFormToolbarModule], [typeof i1.OFormComponent, typeof i2.OFormToolbarModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OFormModule>;
}
//# sourceMappingURL=o-form.module.d.ts.map