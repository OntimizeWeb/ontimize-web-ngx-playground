import { ActivatedRouteSnapshot, CanDeactivate, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import { OFormConfirmExitService } from '../navigation/o-form-confirm-exit.service';
import { OFormComponent } from '../o-form.component';
import * as i0 from "@angular/core";
export interface CanComponentDeactivate {
    canDeactivate: () => Observable<boolean> | Promise<boolean> | boolean;
}
export declare class CanDeactivateFormGuard implements CanDeactivate<CanComponentDeactivate> {
    protected oFormConfirmExitService: OFormConfirmExitService;
    static CLASSNAME: string;
    protected oForms: {
        [key: string]: OFormComponent;
    };
    constructor(oFormConfirmExitService: OFormConfirmExitService);
    canDeactivate(component: CanComponentDeactivate, curr: ActivatedRouteSnapshot, state: RouterStateSnapshot, future: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean;
    addForm(form: OFormComponent): void;
    removeForm(form: OFormComponent): void;
    isFormsCacheEmpty(): boolean;
    private getFormKey;
    static ɵfac: i0.ɵɵFactoryDeclaration<CanDeactivateFormGuard, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<CanDeactivateFormGuard>;
}
//# sourceMappingURL=o-form-can-deactivate.guard.d.ts.map