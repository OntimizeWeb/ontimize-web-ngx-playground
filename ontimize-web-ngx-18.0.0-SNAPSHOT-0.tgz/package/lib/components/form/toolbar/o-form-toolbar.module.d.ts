import * as i0 from "@angular/core";
import * as i1 from "../navigation/o-form-navigation.component";
import * as i2 from "./o-form-toolbar.component";
export declare class OFormToolbarModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OFormToolbarModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OFormToolbarModule, never, [typeof i1.OFormNavigationComponent, typeof i2.OFormToolbarComponent], [typeof i1.OFormNavigationComponent, typeof i2.OFormToolbarComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OFormToolbarModule>;
}
//# sourceMappingURL=o-form-toolbar.module.d.ts.map