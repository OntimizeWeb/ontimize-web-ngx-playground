import * as i0 from "@angular/core";
import * as i1 from "./o-form-container.component";
export declare class OFormContainerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OFormContainerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OFormContainerModule, never, [typeof i1.OFormContainerComponent], [typeof i1.OFormContainerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OFormContainerModule>;
}
//# sourceMappingURL=o-form-container.module.d.ts.map