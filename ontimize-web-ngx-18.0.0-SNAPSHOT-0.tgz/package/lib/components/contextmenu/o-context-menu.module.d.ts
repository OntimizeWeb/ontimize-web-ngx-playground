import * as i0 from "@angular/core";
import * as i1 from "./o-context-menu.directive";
import * as i2 from "./o-context-menu.component";
import * as i3 from "./context-menu-item/o-context-menu-item.component";
import * as i4 from "./context-menu-group/o-context-menu-group.component";
import * as i5 from "./context-menu-separator/o-context-menu-separator.component";
export declare class OContextMenuModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OContextMenuModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OContextMenuModule, never, [typeof i1.OContextMenuDirective, typeof i2.OContextMenuComponent, typeof i3.OContextMenuItemComponent, typeof i4.OContextMenuGroupComponent, typeof i5.OContextMenuSeparatorComponent], [typeof i1.OContextMenuDirective, typeof i2.OContextMenuComponent, typeof i3.OContextMenuItemComponent, typeof i4.OContextMenuGroupComponent, typeof i5.OContextMenuSeparatorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OContextMenuModule>;
}
//# sourceMappingURL=o-context-menu.module.d.ts.map