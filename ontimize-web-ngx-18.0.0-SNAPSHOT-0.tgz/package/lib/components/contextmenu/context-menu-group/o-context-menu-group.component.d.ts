import { AfterContentInit, OnDestroy, QueryList } from '@angular/core';
import { Subscription } from 'rxjs';
import { OComponentMenuBaseItem } from '../o-content-menu-base-item.class';
import * as i0 from "@angular/core";
export declare class OContextMenuGroupComponent extends OComponentMenuBaseItem implements AfterContentInit, OnDestroy {
    type: string;
    children: OComponentMenuBaseItem[];
    oContextMenuItems: QueryList<OComponentMenuBaseItem>;
    protected subscription: Subscription;
    ngOnDestroy(): void;
    ngAfterContentInit(): void;
    protected updateChildren(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OContextMenuGroupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OContextMenuGroupComponent, "o-context-menu-group", never, {}, {}, ["oContextMenuItems"], never, true, never>;
}
//# sourceMappingURL=o-context-menu-group.component.d.ts.map