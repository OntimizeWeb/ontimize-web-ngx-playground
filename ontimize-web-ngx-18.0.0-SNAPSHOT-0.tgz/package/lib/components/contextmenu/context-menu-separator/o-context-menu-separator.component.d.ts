import { OComponentMenuBaseItem } from '../o-content-menu-base-item.class';
import * as i0 from "@angular/core";
export declare const DEFAULT_CONTEXT_MENU_ITEM_INPUTS: string[];
export declare class OContextMenuSeparatorComponent extends OComponentMenuBaseItem {
    type: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<OContextMenuSeparatorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OContextMenuSeparatorComponent, "o-context-menu-separator", never, { "attr": { "alias": "attr"; "required": false; }; "ovisible": { "alias": "visible"; "required": false; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=o-context-menu-separator.component.d.ts.map