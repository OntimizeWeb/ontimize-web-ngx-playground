import { OverlayRef } from '@angular/cdk/overlay';
import * as i0 from "@angular/core";
export declare class OContextMenuOverlayService {
    protected overlays: OverlayRef[];
    addOverlay(value: OverlayRef): void;
    destroyOverlays(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OContextMenuOverlayService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OContextMenuOverlayService>;
}
//# sourceMappingURL=o-context-menu-overlay.service.d.ts.map