import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_CONTEXT_MENU_ITEMS: string[];
export declare class OComponentMenuBaseItem {
    static TYPE_ITEM_MENU: string;
    static TYPE_GROUP_MENU: string;
    static TYPE_SEPARATOR_MENU: string;
    ovisible: boolean | ((item: any) => boolean);
    attr: any;
    type: string;
    icon: string;
    data: any;
    label: string;
    enabled: boolean | ((item: any) => boolean);
    svgIcon: string;
    get disabled(): boolean;
    get isVisible(): boolean;
    set oenabled(value: (boolean | ((item: any) => boolean)));
    protected parseInput(value: any, defaultValue?: boolean): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<OComponentMenuBaseItem, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<OComponentMenuBaseItem, never, never, { "attr": { "alias": "attr"; "required": false; }; "ovisible": { "alias": "visible"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "data": { "alias": "data"; "required": false; }; "label": { "alias": "label"; "required": false; }; "oenabled": { "alias": "enabled"; "required": false; }; "svgIcon": { "alias": "svg-icon"; "required": false; }; }, {}, never, never, false, never>;
}
//# sourceMappingURL=o-content-menu-base-item.class.d.ts.map