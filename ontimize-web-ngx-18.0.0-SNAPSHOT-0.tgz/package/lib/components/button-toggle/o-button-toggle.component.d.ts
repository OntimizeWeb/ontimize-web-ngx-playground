import { EventEmitter } from '@angular/core';
import { MatButtonToggle, MatButtonToggleChange } from '@angular/material/button-toggle';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_BUTTON_TOGGLE: string[];
export declare const DEFAULT_OUTPUTS_O_BUTTON_TOGGLE: string[];
export declare class OButtonToggleComponent {
    DEFAULT_INPUTS_O_BUTTON_TOGGLE: string[];
    DEFAULT_OUTPUTS_O_BUTTON_TOGGLE: string[];
    oattr: string;
    label: string;
    icon: string;
    iconPosition: 'before' | 'after';
    name: string;
    onChange: EventEmitter<MatButtonToggleChange>;
    _innerButtonToggle: MatButtonToggle;
    _checked: boolean;
    _enabled: boolean;
    _value: any;
    get checked(): boolean;
    set checked(val: boolean);
    get enabled(): boolean;
    set enabled(val: boolean);
    get value(): any;
    set value(val: any);
    static ɵfac: i0.ɵɵFactoryDeclaration<OButtonToggleComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OButtonToggleComponent, "o-button-toggle", never, { "oattr": { "alias": "attr"; "required": false; }; "label": { "alias": "label"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "iconPosition": { "alias": "icon-position"; "required": false; }; "checked": { "alias": "checked"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "value": { "alias": "value"; "required": false; }; "name": { "alias": "name"; "required": false; }; }, { "onChange": "onChange"; }, never, never, true, never>;
}
//# sourceMappingURL=o-button-toggle.component.d.ts.map