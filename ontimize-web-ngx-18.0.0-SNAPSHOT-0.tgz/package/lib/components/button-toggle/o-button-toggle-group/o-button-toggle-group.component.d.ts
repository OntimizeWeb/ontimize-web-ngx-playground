import { AfterViewInit, EventEmitter, OnInit, QueryList, ViewContainerRef } from '@angular/core';
import { MatButtonToggleChange, MatButtonToggleGroup } from '@angular/material/button-toggle';
import { OButtonToggleComponent } from '../o-button-toggle.component';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_BUTTON_TOGGLE_GROUP: string[];
export declare const DEFAULT_OUTPUTS_O_BUTTON_TOGGLE_GROUP: string[];
export declare class OButtonToggleGroupComponent implements AfterViewInit, OnInit {
    DEFAULT_INPUTS_O_BUTTON_TOGGLE_GROUP: string[];
    DEFAULT_OUTPUTS_O_BUTTON_TOGGLE_GROUP: string[];
    protected oattr: string;
    name: string;
    get enabled(): boolean;
    set enabled(val: boolean);
    protected _enabled: boolean;
    layout: 'row' | 'column';
    multiple: boolean;
    value: any;
    onChange: EventEmitter<MatButtonToggleChange>;
    protected _innerButtonToggleGroup: MatButtonToggleGroup;
    protected _viewContainerRef: ViewContainerRef;
    protected _children: QueryList<OButtonToggleComponent>;
    ngOnInit(): void;
    ngAfterViewInit(): void;
    protected buildChildren(): void;
    getValue(): any;
    setValue(val: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OButtonToggleGroupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OButtonToggleGroupComponent, "o-button-toggle-group", never, { "oattr": { "alias": "attr"; "required": false; }; "name": { "alias": "name"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "layout": { "alias": "layout"; "required": false; }; "multiple": { "alias": "multiple"; "required": false; }; "value": { "alias": "value"; "required": false; }; }, { "onChange": "onChange"; }, ["_children"], never, true, never>;
}
//# sourceMappingURL=o-button-toggle-group.component.d.ts.map