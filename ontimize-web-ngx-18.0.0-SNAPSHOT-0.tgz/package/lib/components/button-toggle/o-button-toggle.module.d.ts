import * as i0 from "@angular/core";
import * as i1 from "./o-button-toggle.component";
import * as i2 from "./o-button-toggle-group/o-button-toggle-group.component";
export declare class OButtonToggleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OButtonToggleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OButtonToggleModule, never, [typeof i1.OButtonToggleComponent, typeof i2.OButtonToggleGroupComponent], [typeof i1.OButtonToggleComponent, typeof i2.OButtonToggleGroupComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OButtonToggleModule>;
}
//# sourceMappingURL=o-button-toggle.module.d.ts.map