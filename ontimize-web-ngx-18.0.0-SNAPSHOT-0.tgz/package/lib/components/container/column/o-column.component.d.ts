import { ElementRef, Injector } from '@angular/core';
import { OContainerComponent } from '../o-container-component.class';
import * as i0 from "@angular/core";
export declare class OColumnComponent extends OContainerComponent {
    protected elRef: ElementRef;
    protected injector: Injector;
    protected matFormDefaultOption: any;
    constructor(elRef: ElementRef, injector: Injector, matFormDefaultOption: any);
    static ɵfac: i0.ɵɵFactoryDeclaration<OColumnComponent, [null, null, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OColumnComponent, "o-column", never, {}, {}, never, ["*"], true, never>;
}
//# sourceMappingURL=o-column.component.d.ts.map