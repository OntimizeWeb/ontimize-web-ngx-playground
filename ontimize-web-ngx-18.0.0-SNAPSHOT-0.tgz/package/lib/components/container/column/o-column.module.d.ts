import * as i0 from "@angular/core";
import * as i1 from "./o-column.component";
export declare class OColumnModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OColumnModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OColumnModule, never, [typeof i1.OColumnComponent], [typeof i1.OColumnComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OColumnModule>;
}
//# sourceMappingURL=o-column.module.d.ts.map