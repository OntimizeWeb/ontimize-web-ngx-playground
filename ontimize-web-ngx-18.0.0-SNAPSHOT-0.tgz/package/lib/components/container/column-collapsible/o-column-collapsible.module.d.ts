import * as i0 from "@angular/core";
import * as i1 from "./o-column-collapsible.component";
export declare class OColumnCollapsibleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OColumnCollapsibleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OColumnCollapsibleModule, never, [typeof i1.OColumnCollapsibleComponent], [typeof i1.OColumnCollapsibleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OColumnCollapsibleModule>;
}
//# sourceMappingURL=o-column-collapsible.module.d.ts.map