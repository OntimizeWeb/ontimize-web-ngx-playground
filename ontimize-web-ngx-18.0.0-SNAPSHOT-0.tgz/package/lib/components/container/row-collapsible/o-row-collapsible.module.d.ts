import * as i0 from "@angular/core";
import * as i1 from "./o-row-collapsible.component";
export declare class ORowCollapsibleModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ORowCollapsibleModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ORowCollapsibleModule, never, [typeof i1.ORowCollapsibleComponent], [typeof i1.ORowCollapsibleComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ORowCollapsibleModule>;
}
//# sourceMappingURL=o-row-collapsible.module.d.ts.map