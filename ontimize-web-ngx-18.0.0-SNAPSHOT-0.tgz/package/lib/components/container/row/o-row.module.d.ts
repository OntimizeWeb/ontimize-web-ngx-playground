import * as i0 from "@angular/core";
import * as i1 from "./o-row.component";
export declare class ORowModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<ORowModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<ORowModule, never, [typeof i1.ORowComponent], [typeof i1.ORowComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<ORowModule>;
}
//# sourceMappingURL=o-row.module.d.ts.map