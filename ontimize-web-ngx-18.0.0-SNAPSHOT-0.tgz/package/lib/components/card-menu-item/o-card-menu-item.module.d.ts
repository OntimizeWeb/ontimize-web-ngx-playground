import * as i0 from "@angular/core";
import * as i1 from "./o-card-menu-item.component";
export declare class OCardMenuItemModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OCardMenuItemModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OCardMenuItemModule, never, [typeof i1.OCardMenuItemComponent], [typeof i1.OCardMenuItemComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OCardMenuItemModule>;
}
//# sourceMappingURL=o-card-menu-item.module.d.ts.map