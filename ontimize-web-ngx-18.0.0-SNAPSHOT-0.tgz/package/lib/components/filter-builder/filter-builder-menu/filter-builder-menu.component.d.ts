import { Injector } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { DialogService } from '../../../services/dialog.service';
import { OFilterBuilderComponent } from '../o-filter-builder.component';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_FILTER_BUILDER_MENU: string[];
export declare class OFilterBuilderMenuComponent {
    protected injector: Injector;
    protected dialog: MatDialog;
    protected dialogService: DialogService;
    protected _filterBuilder: OFilterBuilderComponent;
    showFilterOption: boolean;
    showClearFilterOption: boolean;
    icon: string;
    svgIcon: string;
    defaultIcon: string;
    constructor(injector: Injector);
    onStoreFilterClicked(): void;
    onLoadFilterClicked(): void;
    onClearFilterClicked(): void;
    onFilterClicked(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OFilterBuilderMenuComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OFilterBuilderMenuComponent, "o-filter-builder-menu", never, { "_filterBuilder": { "alias": "oFilterBuilder"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "svgIcon": { "alias": "svg-icon"; "required": false; }; "showClearFilterOption": { "alias": "show-clear-filter-option"; "required": false; }; "showFilterOption": { "alias": "show-filter-option"; "required": false; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=filter-builder-menu.component.d.ts.map