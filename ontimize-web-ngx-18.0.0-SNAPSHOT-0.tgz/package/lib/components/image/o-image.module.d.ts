import * as i0 from "@angular/core";
import * as i1 from "./o-image.component";
import * as i2 from "./fullscreen/fullscreen-dialog.component";
export declare class OImageModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OImageModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OImageModule, never, [typeof i1.OImageComponent, typeof i2.OFullScreenDialogComponent], [typeof i1.OImageComponent, typeof i2.OFullScreenDialogComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OImageModule>;
}
//# sourceMappingURL=o-image.module.d.ts.map