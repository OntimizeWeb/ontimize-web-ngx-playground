import { MatDialogRef } from '@angular/material/dialog';
import * as i0 from "@angular/core";
export declare class OFullScreenDialogComponent {
    dialogRef: MatDialogRef<OFullScreenDialogComponent>;
    data: any;
    imageSrc: any;
    constructor(dialogRef: MatDialogRef<OFullScreenDialogComponent>, data: any);
    static ɵfac: i0.ɵɵFactoryDeclaration<OFullScreenDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OFullScreenDialogComponent, "o-fullscreen-dialog", never, {}, {}, never, never, true, never>;
}
//# sourceMappingURL=fullscreen-dialog.component.d.ts.map