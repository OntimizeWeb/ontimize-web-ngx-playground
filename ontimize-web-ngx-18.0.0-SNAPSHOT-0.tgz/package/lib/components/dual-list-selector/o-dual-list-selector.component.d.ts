import { CdkDragDrop } from '@angular/cdk/drag-drop';
import { MatSelectionList } from '@angular/material/list';
import { OGroupedColumnTypes } from '../../types/o-grouped-column-types.type';
import * as i0 from "@angular/core";
export declare const DEFAULT_DUAL_LIST_SELECTOR: string[];
export declare class ODualListSelectorComponent {
    dataSource: Array<any>;
    dataDestination: Array<any>;
    titleListDataSource: string;
    titleListDataDestination: string;
    description: string;
    key: string;
    display: string;
    groupedColumnTypes: OGroupedColumnTypes[];
    drop(event: CdkDragDrop<string[]>): void;
    addToGroupedColumns(columnsToGrouped: MatSelectionList): void;
    removeGroupedColumns(groupedColumns: MatSelectionList): void;
    onRemoveGroupColumn(column: any): void;
    isAllSelected(list: MatSelectionList): boolean;
    masterToggle(list: MatSelectionList): void;
    hasValue(list: MatSelectionList): boolean;
    isDisabledSortAsc(list: MatSelectionList): boolean;
    isDisabledSortDesc(list: MatSelectionList): boolean;
    sortAscSelectedItems(list: MatSelectionList): void;
    sortDescSelectedItems(list: MatSelectionList): void;
    getCheckboxLabel(list: MatSelectionList): string;
    getSelectedItems(): Array<any>;
    setSelectedItems(items: Array<any>): void;
    getGroupedColumnTypes(): OGroupedColumnTypes[];
    get groupedDateColumns(): OGroupedColumnTypes[];
    static ɵfac: i0.ɵɵFactoryDeclaration<ODualListSelectorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ODualListSelectorComponent, "o-dual-list-selector", never, { "key": { "alias": "key"; "required": false; }; "display": { "alias": "display"; "required": false; }; "dataSource": { "alias": "data-source"; "required": false; }; "dataDestination": { "alias": "data-destination"; "required": false; }; "titleListDataSource": { "alias": "title-list-data-source"; "required": false; }; "titleListDataDestination": { "alias": "title-list-data-destination"; "required": false; }; "groupedColumnTypes": { "alias": "grouped-column-types"; "required": false; }; "description": { "alias": "description"; "required": false; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=o-dual-list-selector.component.d.ts.map