import * as i0 from "@angular/core";
import * as i1 from "./o-breadcrumb.component";
export declare class OBreadcrumbModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OBreadcrumbModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OBreadcrumbModule, never, [typeof i1.OBreadcrumbComponent], [typeof i1.OBreadcrumbComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OBreadcrumbModule>;
}
//# sourceMappingURL=o-breadcrumb.module.d.ts.map