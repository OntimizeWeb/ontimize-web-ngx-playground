import * as i0 from "@angular/core";
import * as i1 from "./o-list.component";
import * as i2 from "./list-item/o-list-item.component";
import * as i3 from "./skeleton/o-list-skeleton.component";
import * as i4 from "./renderers/avatar/o-list-item-avatar.component";
import * as i5 from "./renderers/card-image/o-list-item-card-image.component";
import * as i6 from "./renderers/card/o-list-item-card.component";
import * as i7 from "./renderers/text/o-list-item-text.component";
export declare class OListModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OListModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OListModule, never, [typeof i1.OListComponent, typeof i2.OListItemComponent, typeof i3.OListSkeletonComponent, typeof i4.OListItemAvatarComponent, typeof i5.OListItemCardImageComponent, typeof i6.OListItemCardComponent, typeof i7.OListItemTextComponent], [typeof i1.OListComponent, typeof i2.OListItemComponent, typeof i4.OListItemAvatarComponent, typeof i5.OListItemCardImageComponent, typeof i6.OListItemCardComponent, typeof i7.OListItemTextComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OListModule>;
}
//# sourceMappingURL=o-list.module.d.ts.map