import { ORepeatableSkeletonComponent } from '../../o-repeatable-skeleton.component';
import * as i0 from "@angular/core";
export declare class OListSkeletonComponent extends ORepeatableSkeletonComponent {
    getParentElement(): HTMLElement;
    getSkeletonItemElement(parentElement: HTMLElement): HTMLElement;
    static ɵfac: i0.ɵɵFactoryDeclaration<OListSkeletonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OListSkeletonComponent, "o-list-skeleton", never, {}, {}, never, never, true, never>;
}
//# sourceMappingURL=o-list-skeleton.component.d.ts.map