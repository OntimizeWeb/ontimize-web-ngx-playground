import { EventEmitter } from '@angular/core';
import { MatSort, MatSortable } from '@angular/material/sort';
import { SQLOrder } from '../../../../types/sql-order.type';
import * as i0 from "@angular/core";
export type OMatSortGroupedData = {
    key: any;
    values: any[];
};
export declare class OMatSort extends MatSort {
    activeArray: Array<MatSortable>;
    directionById: any;
    protected multipleSort: boolean;
    protected activeSortColumn: string;
    protected activeSortDirection: string;
    readonly oSortChange: EventEmitter<any>;
    set oMatSortColumns(value: SQLOrder[]);
    setMultipleSort(val: boolean): void;
    getSortColumns(): any[];
    setSortColumns(sortColArray: SQLOrder[]): void;
    private restart;
    protected setTableInfo(sortColArray: Array<SQLOrder>): void;
    addSortColumn(sortable: MatSortable): void;
    protected deleteSortColumn(id: string): void;
    isActive(sortable: MatSortable): boolean;
    hasDirection(id: any): boolean;
    getSortedDataBySQLOrder(data: any[], sqlOrderArray: SQLOrder[]): any[];
    getSortedData(data: any[]): any[];
    protected sortByColumns(data: any[], sortColumns: any[]): any[];
    protected getDataGrouped(data: any, sortColumns: any[], index: number): OMatSortGroupedData[];
    protected sortGroupedData(groupedData: OMatSortGroupedData[]): any[];
    sortFunction(a: any, b: any): number;
    static ɵfac: i0.ɵɵFactoryDeclaration<OMatSort, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<OMatSort, "[oMatSort]", ["oMatSort"], { "disabled": { "alias": "oMatSortDisabled"; "required": false; }; "oMatSortColumns": { "alias": "oMatSortColumns"; "required": false; }; }, { "oSortChange": "matSortChange"; }, never, never, true, never>;
}
//# sourceMappingURL=o-mat-sort.d.ts.map