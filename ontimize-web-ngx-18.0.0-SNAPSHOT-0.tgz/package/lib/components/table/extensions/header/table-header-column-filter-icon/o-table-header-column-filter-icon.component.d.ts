import { ChangeDetectorRef, OnDestroy, OnInit } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { OColumnValueFilter } from '../../../../../types/table/o-column-value-filter.type';
import type { OColumn } from '../../../column/o-column.class';
import { OTableBase } from '../../../o-table-base.class';
import { MatDialog } from '@angular/material/dialog';
import { DialogService } from '../../../../../services/dialog.service';
import { OTranslateService } from '../../../../../services/translate/o-translate.service';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_TABLE_COLUMN_FILTER_ICON: string[];
export declare type STATEVIEW = 'HINT' | 'ACTIVE' | 'INACTIVE';
export declare class OTableHeaderColumnFilterIconComponent implements OnInit, OnDestroy {
    table: OTableBase;
    protected dialog: MatDialog;
    protected dialogService: DialogService;
    protected translateService: OTranslateService;
    protected cd: ChangeDetectorRef;
    column: OColumn;
    set columnFilters(filters: OColumnValueFilter[]);
    get columnFilters(): OColumnValueFilter[];
    private _columnFilters;
    isColumnFilterActive: BehaviorSubject<boolean>;
    filterIconHintVisible: BehaviorSubject<boolean>;
    indicatorNumber: BehaviorSubject<string>;
    private subscription;
    filterIconStateView: BehaviorSubject<STATEVIEW>;
    constructor(table: OTableBase, dialog: MatDialog, dialogService: DialogService, translateService: OTranslateService, cd: ChangeDetectorRef);
    ngOnInit(): void;
    updateStateColumnFilter(): void;
    private updateFilterIndicatorNumber;
    protected getColumnValueFilterByAttr(): OColumnValueFilter;
    openColumnFilterDialog(event: Event): void;
    getFilterIndicatorNumbered(): string;
    setFilterIconHintVisible(visible: boolean): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableHeaderColumnFilterIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OTableHeaderColumnFilterIconComponent, "o-table-header-column-filter-icon", never, { "column": { "alias": "column"; "required": false; }; "columnFilters": { "alias": "column-filters"; "required": false; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=o-table-header-column-filter-icon.component.d.ts.map