import { ElementRef, EventEmitter, Injector, OnInit } from '@angular/core';
import { OTableButton } from '../../../../../interfaces/o-table-button.interface';
import { OTableBase } from '../../../o-table-base.class';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_TABLE_BUTTON: string[];
export declare const DEFAULT_OUTPUTS_O_TABLE_BUTTON: string[];
export declare class OTableButtonComponent implements OTableButton, OnInit {
    protected injector: Injector;
    elRef: ElementRef;
    protected _table: OTableBase;
    onClick: EventEmitter<object>;
    oattr: string;
    enabled: boolean;
    icon: string;
    svgIcon: string;
    olabel: string;
    iconPosition: string;
    constructor(injector: Injector, elRef: ElementRef, _table: OTableBase);
    ngOnInit(): void;
    innerOnClick(event: any): void;
    isReadOnly(): boolean;
    isIconPositionLeft(): boolean;
    get table(): OTableBase;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OTableButtonComponent, "o-table-button", never, { "oattr": { "alias": "attr"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "svgIcon": { "alias": "svg-icon"; "required": false; }; "iconPosition": { "alias": "icon-position"; "required": false; }; "olabel": { "alias": "label"; "required": false; }; }, { "onClick": "onClick"; }, never, never, true, never>;
}
//# sourceMappingURL=o-table-button.component.d.ts.map