import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_TABLE_COLUMN_SELECTALL: string[];
export declare class OTableColumnSelectAllDirective {
    title: string;
    minWidth: string;
    maxWidth: string;
    width: string;
    resizable: boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableColumnSelectAllDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<OTableColumnSelectAllDirective, "o-table-column-select-all", never, { "width": { "alias": "width"; "required": false; }; "minWidth": { "alias": "min-width"; "required": false; }; "maxWidth": { "alias": "max-width"; "required": false; }; "title": { "alias": "title"; "required": false; }; "resizable": { "alias": "resizable"; "required": false; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=o-table-column-select-all.directive.d.ts.map