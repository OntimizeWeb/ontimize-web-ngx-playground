import { OTableComponent } from '../o-table.component';
import { DefaultOTableDataSource } from './default-o-table.datasource';
import * as i0 from "@angular/core";
export declare class OTableDataSourceService {
    constructor();
    getInstance(table: OTableComponent): DefaultOTableDataSource;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableDataSourceService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OTableDataSourceService>;
}
//# sourceMappingURL=o-table-datasource.service.d.ts.map