import { EventEmitter, Injector } from '@angular/core';
import { OTableExportButtonService } from './o-table-export-button.service';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_TABLE_EXPORT_BUTTON: string[];
export declare const DEFAULT_OUTPUTS_O_TABLE_EXPORT_BUTTON: string[];
export declare class OTableExportButtonComponent {
    private readonly injector;
    icon: string;
    svgIcon: string;
    olabel: string;
    onClick: EventEmitter<any>;
    exportFunction: () => void;
    protected exportType: string;
    protected oTableExportButtonService: OTableExportButtonService;
    constructor(injector: Injector);
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableExportButtonComponent, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<OTableExportButtonComponent, "o-table-export-button", never, { "icon": { "alias": "icon"; "required": false; }; "svgIcon": { "alias": "svg-icon"; "required": false; }; "olabel": { "alias": "label"; "required": false; }; "exportType": { "alias": "export-type"; "required": false; }; "exportFunction": { "alias": "export-function"; "required": false; }; }, { "onClick": "onClick"; }, never, never, true, never>;
}
//# sourceMappingURL=o-table-export-button.component.d.ts.map