import { Injector, TemplateRef } from '@angular/core';
import { OBaseTableCellEditor } from '../o-base-table-cell-editor.class';
import * as i0 from "@angular/core";
export declare class OTableCellEditorEmailComponent extends OBaseTableCellEditor {
    protected injector: Injector;
    templateref: TemplateRef<any>;
    constructor(injector: Injector);
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableCellEditorEmailComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OTableCellEditorEmailComponent, "o-table-cell-editor-email", never, {}, {}, never, never, true, never>;
}
//# sourceMappingURL=o-table-cell-editor-email.component.d.ts.map