export declare const O_TABLE_CELL_EDITORS_INPUTS: string[];
export declare const O_TABLE_CELL_EDITORS_OUTPUTS: string[];
//# sourceMappingURL=cell-editor-inputs.d.ts.map