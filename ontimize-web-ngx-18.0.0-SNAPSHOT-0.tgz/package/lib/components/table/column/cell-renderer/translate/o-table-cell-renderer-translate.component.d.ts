import { Injector, TemplateRef } from '@angular/core';
import { ITranslatePipeArgument, OTranslatePipe } from '../../../../../pipes/o-translate.pipe';
import { OBaseTableCellRenderer } from '../o-base-table-cell-renderer.class';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_TABLE_CELL_RENDERER_TRANSLATE: string[];
export declare class OTableCellRendererTranslateComponent extends OBaseTableCellRenderer {
    protected injector: Injector;
    templateref: TemplateRef<any>;
    translateArgsFn: (rowData: any) => any[];
    protected componentPipe: OTranslatePipe;
    protected pipeArguments: ITranslatePipeArgument;
    constructor(injector: Injector);
    setComponentPipe(): void;
    getCellData(cellvalue: any, rowvalue?: any): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableCellRendererTranslateComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OTableCellRendererTranslateComponent, "o-table-cell-renderer-translate", never, { "translateArgsFn": { "alias": "translate-params"; "required": false; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=o-table-cell-renderer-translate.component.d.ts.map