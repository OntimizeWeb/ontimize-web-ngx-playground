import { Injector, OnInit, TemplateRef } from '@angular/core';
import { ICurrencyPipeArgument, OCurrencyPipe } from '../../../../../pipes/o-currency.pipe';
import { CurrencyService } from '../../../../../services/currency.service';
import { OTableCellRendererRealComponent } from '../real/o-table-cell-renderer-real.component';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_TABLE_CELL_RENDERER_CURRENCY: string[];
export declare class OTableCellRendererCurrencyComponent extends OTableCellRendererRealComponent implements OnInit {
    protected injector: Injector;
    minDecimalDigits: number;
    maxDecimalDigits: number;
    protected currencySymbol: string;
    protected currencySymbolPosition: string;
    protected decimalSeparator: string;
    protected currencySymbolColumn: string;
    protected grouping: boolean;
    protected thousandSeparator: string;
    protected currencyService: CurrencyService;
    protected componentPipe: OCurrencyPipe;
    protected pipeArguments: ICurrencyPipeArgument;
    templateref: TemplateRef<any>;
    constructor(injector: Injector);
    setComponentPipe(): void;
    initialize(): void;
    getCellData(cellValue: any, rowValue?: any): string;
    private getNestedProperty;
    static ɵfac: i0.ɵɵFactoryDeclaration<OTableCellRendererCurrencyComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OTableCellRendererCurrencyComponent, "o-table-cell-renderer-currency", never, { "currencySymbol": { "alias": "currency-symbol"; "required": false; }; "currencySymbolPosition": { "alias": "currency-symbol-position"; "required": false; }; "currencySymbolColumn": { "alias": "currency-symbol-column"; "required": false; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=o-table-cell-renderer-currency.component.d.ts.map