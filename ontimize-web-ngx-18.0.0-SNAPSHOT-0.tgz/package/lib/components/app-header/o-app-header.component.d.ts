import { EventEmitter, Injector } from '@angular/core';
import { ThemePalette } from '@angular/material/core';
import { Observable } from 'rxjs';
import { AuthService } from '../../services';
import { DialogService } from '../../services/dialog.service';
import { OModulesInfoService } from '../../services/o-modules-info.service';
import { OUserInfoBase } from '../user-info/o-user-info-base.class';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_APP_HEADER: string[];
export declare const DEFAULT_OUTPUTS_O_APP_HEADER: string[];
export declare class OAppHeaderComponent {
    protected injector: Injector;
    protected dialogService: DialogService;
    protected modulesInfoService: OModulesInfoService;
    protected authService: AuthService;
    showTitle: boolean;
    showStaticTitle: boolean;
    staticTitle: string;
    headerTitle$: Observable<string>;
    userInfo: OUserInfoBase;
    showUserInfo: boolean;
    showLanguageSelector: boolean;
    useFlagIcons: boolean;
    onSidenavToggle: EventEmitter<void>;
    protected _headerHeight: string;
    set headerHeight(value: string);
    get headerHeight(): string;
    private _color;
    constructor(injector: Injector);
    ngOnInit(): void;
    onLogoutClick(): void;
    set color(newValue: ThemePalette);
    get color(): ThemePalette;
    static ɵfac: i0.ɵɵFactoryDeclaration<OAppHeaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OAppHeaderComponent, "o-app-header", never, { "showUserInfo": { "alias": "show-user-info"; "required": false; }; "showLanguageSelector": { "alias": "show-language-selector"; "required": false; }; "useFlagIcons": { "alias": "use-flag-icons"; "required": false; }; "color": { "alias": "color"; "required": false; }; "headerHeight": { "alias": "header-height"; "required": false; }; "showTitle": { "alias": "show-title"; "required": false; }; "staticTitle": { "alias": "static-title"; "required": false; }; "showStaticTitle": { "alias": "show-static-title"; "required": false; }; }, { "onSidenavToggle": "onSidenavToggle"; }, never, ["*", "o-app-layout-header-projection-start", "o-app-layout-header-projection-end"], true, never>;
}
//# sourceMappingURL=o-app-header.component.d.ts.map