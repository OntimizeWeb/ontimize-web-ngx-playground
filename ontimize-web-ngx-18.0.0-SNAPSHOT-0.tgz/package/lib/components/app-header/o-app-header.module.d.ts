import * as i0 from "@angular/core";
import * as i1 from "./o-app-header.component";
export declare class OAppHeaderModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OAppHeaderModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OAppHeaderModule, never, [typeof i1.OAppHeaderComponent], [typeof i1.OAppHeaderComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OAppHeaderModule>;
}
//# sourceMappingURL=o-app-header.module.d.ts.map