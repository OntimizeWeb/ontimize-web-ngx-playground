import { EventEmitter } from "@angular/core";
import { MatSidenav } from "@angular/material/sidenav";
export declare abstract class OAppSidenavBase {
    abstract onSidenavOpenedChange: EventEmitter<boolean>;
    abstract sidenav: MatSidenav;
    abstract onSidenavClosedStart: EventEmitter<void>;
    abstract onSidenavOpenedStart: EventEmitter<void>;
}
//# sourceMappingURL=o-app-sidenav-base.class.d.ts.map