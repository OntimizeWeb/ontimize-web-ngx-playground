import * as i0 from "@angular/core";
import * as i1 from "./o-app-sidenav.component";
export declare class OAppSidenavModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OAppSidenavModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OAppSidenavModule, never, [typeof i1.OAppSidenavComponent], [typeof i1.OAppSidenavComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OAppSidenavModule>;
}
//# sourceMappingURL=o-app-sidenav.module.d.ts.map