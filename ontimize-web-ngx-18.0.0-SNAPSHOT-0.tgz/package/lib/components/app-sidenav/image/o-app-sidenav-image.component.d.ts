import { ChangeDetectorRef, Injector, OnChanges, OnDestroy, OnInit, SimpleChanges } from '@angular/core';
import { Subscription } from 'rxjs';
import { OAppSidenavBase } from '../o-app-sidenav-base.class';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_APP_SIDENAV_IMAGE: string[];
export declare const DEFAULT_OUTPUTS_O_APP_SIDENAV_IMAGE: any[];
export declare class OAppSidenavImageComponent implements OnInit, OnDestroy, OnChanges {
    protected injector: Injector;
    protected cd: ChangeDetectorRef;
    protected sidenav: OAppSidenavBase;
    openedSrc: string;
    closedSrc: string;
    private _src;
    protected subscription: Subscription;
    constructor(injector: Injector, cd: ChangeDetectorRef);
    ngOnInit(): void;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    updateImage(): void;
    set src(val: string);
    get src(): string;
    setOpenedImg(): void;
    setClosedImg(): void;
    get showImage(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<OAppSidenavImageComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OAppSidenavImageComponent, "o-app-sidenav-image", never, { "openedSrc": { "alias": "opened-src"; "required": false; }; "closedSrc": { "alias": "closed-src"; "required": false; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=o-app-sidenav-image.component.d.ts.map