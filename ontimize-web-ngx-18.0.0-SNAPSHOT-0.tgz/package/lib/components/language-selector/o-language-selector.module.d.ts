import * as i0 from "@angular/core";
import * as i1 from "./o-language-selector.component";
export declare class OLanguageSelectorModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OLanguageSelectorModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OLanguageSelectorModule, never, [typeof i1.OLanguageSelectorComponent], [typeof i1.OLanguageSelectorComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OLanguageSelectorModule>;
}
//# sourceMappingURL=o-language-selector.module.d.ts.map