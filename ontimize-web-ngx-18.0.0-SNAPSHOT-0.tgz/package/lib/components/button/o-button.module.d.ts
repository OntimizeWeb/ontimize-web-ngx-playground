import * as i0 from "@angular/core";
import * as i1 from "./o-button.component";
export declare class OButtonModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OButtonModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OButtonModule, never, [typeof i1.OButtonComponent], [typeof i1.OButtonComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OButtonModule>;
}
//# sourceMappingURL=o-button.module.d.ts.map