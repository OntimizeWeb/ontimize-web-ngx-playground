import * as i0 from "@angular/core";
import * as i1 from "./o-expandable-container.component";
export declare class OExpandableContainerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OExpandableContainerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OExpandableContainerModule, never, [typeof i1.OExpandableContainerComponent], [typeof i1.OExpandableContainerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OExpandableContainerModule>;
}
//# sourceMappingURL=o-expandable-container.module.d.ts.map