import { ElementRef, Injector, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { PermissionsService } from '../../services/permissions/permissions.service';
import { OTranslateService } from '../../services/translate/o-translate.service';
import { MenuRootItem } from '../../types/menu-root-item.type';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_BAR_MENU: string[];
export declare class OBarMenuComponent implements OnInit {
    protected elRef: ElementRef;
    protected injector: Injector;
    protected permissionsService: PermissionsService;
    protected translateService: OTranslateService;
    private appMenuService;
    private menuRoots;
    protected _menuTitle: string;
    protected _tooltip: string;
    protected _id: string;
    protected subscription: Subscription;
    constructor(elRef: ElementRef, injector: Injector);
    ngOnInit(): void;
    setDOMTitle(): void;
    collapseAll(): void;
    getPermissionsService(): PermissionsService;
    get menuTitle(): string;
    set menuTitle(val: string);
    get tooltip(): string;
    set tooltip(val: string);
    get id(): string;
    set id(val: string);
    get menuItems(): MenuRootItem[];
    refreshMenuRoots(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OBarMenuComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OBarMenuComponent, "o-bar-menu", never, { "menuTitle": { "alias": "title"; "required": false; }; "tooltip": { "alias": "tooltip"; "required": false; }; }, {}, never, ["*"], true, never>;
}
//# sourceMappingURL=o-bar-menu.component.d.ts.map