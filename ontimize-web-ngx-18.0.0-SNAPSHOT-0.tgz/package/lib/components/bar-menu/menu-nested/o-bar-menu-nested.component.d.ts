import { Injector } from '@angular/core';
import { AppMenuService } from '../../../services/app-menu.service';
import { MenuRootItem } from '../../../types/menu-root-item.type';
import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_BAR_MENU_NESTED: string[];
export declare class OBarMenuNestedComponent {
    protected injector: Injector;
    appMenuService: AppMenuService;
    items: MenuRootItem[];
    constructor(injector: Injector);
    static ɵfac: i0.ɵɵFactoryDeclaration<OBarMenuNestedComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OBarMenuNestedComponent, "o-bar-menu-nested", never, { "items": { "alias": "items"; "required": false; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=o-bar-menu-nested.component.d.ts.map