import * as i0 from "@angular/core";
import * as i1 from "./o-bar-menu.component";
import * as i2 from "./menu-item/o-bar-menu-item.component";
import * as i3 from "./menu-group/o-bar-menu-group.component";
import * as i4 from "./locale-menu-item/o-locale-bar-menu-item.component";
import * as i5 from "./menu-separator/o-bar-menu-separator.component";
import * as i6 from "./menu-nested/o-bar-menu-nested.component";
export declare class OBarMenuModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OBarMenuModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OBarMenuModule, never, [typeof i1.OBarMenuComponent, typeof i2.OBarMenuItemComponent, typeof i3.OBarMenuGroupComponent, typeof i4.OLocaleBarMenuItemComponent, typeof i5.OBarMenuSeparatorComponent, typeof i6.OBarMenuNestedComponent], [typeof i1.OBarMenuComponent, typeof i2.OBarMenuItemComponent, typeof i3.OBarMenuGroupComponent, typeof i4.OLocaleBarMenuItemComponent, typeof i5.OBarMenuSeparatorComponent, typeof i6.OBarMenuNestedComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OBarMenuModule>;
}
//# sourceMappingURL=o-bar-menu.module.d.ts.map