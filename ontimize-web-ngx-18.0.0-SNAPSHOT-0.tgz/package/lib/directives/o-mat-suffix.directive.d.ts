import * as i0 from "@angular/core";
export declare class OMatSuffix {
    static ɵfac: i0.ɵɵFactoryDeclaration<OMatSuffix, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<OMatSuffix, "[oMatSuffix]", never, {}, {}, never, never, true, never>;
}
//# sourceMappingURL=o-mat-suffix.directive.d.ts.map