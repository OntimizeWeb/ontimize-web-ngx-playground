export type ODateValueType = 'string' | 'date' | 'timestamp' | 'iso-8601';
//# sourceMappingURL=o-date-value.type.d.ts.map