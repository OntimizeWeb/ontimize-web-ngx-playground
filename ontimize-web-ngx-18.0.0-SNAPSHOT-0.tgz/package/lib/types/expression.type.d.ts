export type Expression = {
    lop: string | Expression;
    op: string;
    rop?: string | any[] | Expression;
};
//# sourceMappingURL=expression.type.d.ts.map