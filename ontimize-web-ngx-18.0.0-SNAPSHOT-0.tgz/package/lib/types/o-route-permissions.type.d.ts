import { OComponentPermissions } from './o-component-permissions.type';
export type ORoutePermissions = {
    permissionId: string;
    enabled?: boolean;
    components?: OComponentPermissions[];
};
//# sourceMappingURL=o-route-permissions.type.d.ts.map