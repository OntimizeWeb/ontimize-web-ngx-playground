export type OFormValidation = {
    valid: boolean;
    title?: string;
    messages?: Array<string>;
};
//# sourceMappingURL=error-form-validation.type.d.ts.map