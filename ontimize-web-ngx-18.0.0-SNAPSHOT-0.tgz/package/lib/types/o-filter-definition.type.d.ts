export type OFilterDefinition = {
    name: string;
    description?: string;
};
//# sourceMappingURL=o-filter-definition.type.d.ts.map