import { OComponentPermissions } from "./o-component-permissions.type";
export type OComponentPermissionsByRoute = {
    route?: OComponentPermissions;
    component?: OComponentPermissions;
};
//# sourceMappingURL=o-component-permissions-by-route.type.d.ts.map