import { BehaviorSubject } from "rxjs";
export type FormLayoutInnerFormInfo = {
    modified: boolean;
    confirmOnExit: boolean;
};
export type FormLayoutDetailComponentData = {
    params: any;
    queryParams: any;
    urlSegments: any;
    id: string;
    component: any;
    label: string;
    innerFormsInfo: {
        [formAttr: string]: FormLayoutInnerFormInfo;
    };
    url: string;
    rendered?: boolean;
    insertionMode?: boolean;
    formDataByLabelColumns?: any;
    rendererSubject: BehaviorSubject<boolean>;
};
export type FormLayoutCloseDetailOptions = {
    exitWithoutConfirmation?: boolean;
};
//# sourceMappingURL=form-layout-detail-component-data.type.d.ts.map