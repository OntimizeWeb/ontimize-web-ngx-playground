export type OFormInitializationOptions = {
    entity?: string;
    service?: string;
    columns?: string;
    visibleColumns?: string;
    keys?: string;
    sortColumns?: string;
    editableColumns?: string;
    parentKeys?: string;
};
//# sourceMappingURL=o-form-initialization-options.type.d.ts.map