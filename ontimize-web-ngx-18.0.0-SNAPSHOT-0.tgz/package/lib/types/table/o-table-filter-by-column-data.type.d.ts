export type TableFilterByColumnData = {
    value: any;
    selected: boolean;
    rowValue: any;
    renderedValue?: any;
    tableIndex?: number;
};
export declare enum TableFilterByColumnDialogResult {
    ACCEPT = 0,
    CANCEL = 1,
    CLEAR = 2
}
//# sourceMappingURL=o-table-filter-by-column-data.type.d.ts.map