import { ORowHeight, OTableDetailMode, OTableEditionMode } from './../../util/codes';
export type OTableGlobalConfig = {
    autoAdjust: boolean;
    autoAlignTitles: boolean;
    filterColumnActiveByDefault: boolean;
    editionMode: OTableEditionMode;
    detailMode: OTableDetailMode;
    rowHeight: ORowHeight;
    showChartsOnDemandOption: boolean;
    showReportOnDemandOption: boolean;
    loading: {
        threshold: number;
        minVisible: number;
    };
    selectionOnRowClick?: boolean;
    horizontalScroll: boolean;
    showHeaderTooltip: boolean;
};
//# sourceMappingURL=o-table-global-config.type.d.ts.map