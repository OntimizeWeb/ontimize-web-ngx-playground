export type OColumnSearchable = {
    attr: string;
    searchable: boolean;
    searching: boolean;
};
//# sourceMappingURL=o-column-searchable.type.d.ts.map