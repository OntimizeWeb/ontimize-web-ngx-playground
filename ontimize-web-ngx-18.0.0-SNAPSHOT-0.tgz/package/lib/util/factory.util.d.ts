import { Injector } from '@angular/core';
import { ServiceType } from '../types/service-type.type';
import { OConfigureServiceArgs } from '../types/configure-service-args.type';
export declare class FactoryUtil {
    static isJsonApiService(injector: Injector): boolean;
    static isOntimizeEEService(injector: Injector): boolean;
    static isOntimizeSubclass(cls: any): boolean;
    static isOntimizeEESubclass(cls: any): boolean;
    static isJSONAPISubclass(cls: any): boolean;
    static createServiceInstanceByType(serviceType: ServiceType, injector: Injector): any;
    private static getDataServiceInstance;
    static configureService(configureServiceArgs: OConfigureServiceArgs): any;
}
//# sourceMappingURL=factory.util.d.ts.map