import { InjectionToken, Injector } from '@angular/core';
export declare function _getInjectionTokenValue<T>(token: InjectionToken<T>, injector: Injector): T;
//# sourceMappingURL=injection-token.utils.d.ts.map