import { ApplicationRef, NgModuleRef } from '@angular/core';
export declare function ontimizePostBootstrap(ref: NgModuleRef<any> | ApplicationRef): NgModuleRef<any> | ApplicationRef;
//# sourceMappingURL=MainLauncher.d.ts.map