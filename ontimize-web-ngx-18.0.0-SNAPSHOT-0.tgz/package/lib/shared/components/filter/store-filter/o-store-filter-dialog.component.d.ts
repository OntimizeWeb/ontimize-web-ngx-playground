import { Injector } from '@angular/core';
import { AbstractControl, FormGroup } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { OTableBaseDialogClass } from '../../../../components/table/extensions/dialog/o-table-base-dialog.class';
import { OFilterDefinition } from '../../../../types/o-filter-definition.type';
import * as i0 from "@angular/core";
export declare class OStoreFilterDialogComponent extends OTableBaseDialogClass {
    dialogRef: MatDialogRef<OStoreFilterDialogComponent>;
    protected injector: Injector;
    filterNames: Array<string>;
    formGroup: FormGroup;
    constructor(dialogRef: MatDialogRef<OStoreFilterDialogComponent>, injector: Injector, data: Array<string>);
    loadFilterNames(filterNames: any): void;
    getFilterAttributes(): OFilterDefinition;
    protected filterNameValidator(control: AbstractControl): {
        filterNameAlreadyExists: boolean;
    } | {
        filterNameAlreadyExists?: undefined;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<OStoreFilterDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OStoreFilterDialogComponent, "o-store-filter-dialog", never, {}, {}, never, never, true, never>;
}
//# sourceMappingURL=o-store-filter-dialog.component.d.ts.map