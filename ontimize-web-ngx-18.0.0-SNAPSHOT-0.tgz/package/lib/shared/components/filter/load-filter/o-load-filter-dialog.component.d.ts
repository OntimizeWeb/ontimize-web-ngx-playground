import { ChangeDetectorRef, EventEmitter, Injector, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { MatSelectionList } from '@angular/material/list';
import { DialogService } from '../../../../services/dialog.service';
import { OTableFiltersStatus } from '../../../../types/table/o-table-filter-status.type';
import * as i0 from "@angular/core";
export declare class OLoadFilterDialogComponent implements OnInit {
    dialogRef: MatDialogRef<OLoadFilterDialogComponent>;
    protected injector: Injector;
    filterList: MatSelectionList;
    filters: OTableFiltersStatus[];
    onDelete: EventEmitter<string>;
    protected dialogService: DialogService;
    protected cd: ChangeDetectorRef;
    constructor(dialogRef: MatDialogRef<OLoadFilterDialogComponent>, data: OTableFiltersStatus[], injector: Injector);
    ngOnInit(): void;
    loadFilters(filters: OTableFiltersStatus[]): void;
    getSelectedFilterName(): string;
    removeFilter(filterName: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OLoadFilterDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OLoadFilterDialogComponent, "o-load-filter-dialog", never, {}, {}, never, never, true, never>;
}
//# sourceMappingURL=o-load-filter-dialog.component.d.ts.map