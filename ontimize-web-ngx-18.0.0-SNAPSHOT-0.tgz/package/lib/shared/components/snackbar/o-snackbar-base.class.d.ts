import type { OSnackBarConfig } from "./o-snackbar.component";
import * as i0 from "@angular/core";
export declare abstract class OSnackBarBase {
    abstract open(message: string, config?: OSnackBarConfig): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OSnackBarBase, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OSnackBarBase>;
}
//# sourceMappingURL=o-snackbar-base.class.d.ts.map