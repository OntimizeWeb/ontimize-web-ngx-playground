import type { ODialogConfig } from "./o-dialog.config";
export declare abstract class ODialogBase {
    abstract alert(title: string, message: string, config?: ODialogConfig): any;
    abstract info(title: string, message: string, config?: ODialogConfig): any;
    abstract warn(title: string, message: string, config?: ODialogConfig): any;
    abstract error(title: string, message: string, config?: ODialogConfig): any;
    abstract confirm(title: string, message: string, config?: ODialogConfig): any;
}
//# sourceMappingURL=o-dialog-base.class.d.ts.map