import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { ODialogBase } from '../shared/components/dialog/o-dialog-base.class';
import type { ODialogConfig } from '../shared/components/dialog/o-dialog.config';
import * as i0 from "@angular/core";
export declare class DialogService {
    protected ng2Dialog: MatDialog;
    dialogRef: MatDialogRef<ODialogBase>;
    get dialog(): ODialogBase;
    alert(title: string, message: string, config?: ODialogConfig): Promise<any>;
    info(title: string, message: string, config?: ODialogConfig): Promise<any>;
    warn(title: string, message: string, config?: ODialogConfig): Promise<any>;
    error(title: string, message: string, config?: ODialogConfig): Promise<any>;
    confirm(title: string, message: string, config?: ODialogConfig): Promise<any>;
    protected openDialog(observer: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DialogService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<DialogService>;
}
//# sourceMappingURL=dialog.service.d.ts.map