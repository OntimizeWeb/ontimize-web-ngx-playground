import { AbstractComponentStateService } from './o-component-state.service';
import { OFilterBuilderComponentStateClass } from './o-filter-builder-component-state.class';
import { OFilterBuilderBase } from '../../components/filter-builder/o-filter-builder-base.class';
import { OFilterBuilderStatus } from '../../types/o-filter-builder-values.type';
import * as i0 from "@angular/core";
export declare class OFilterBuilderComponentStateService extends AbstractComponentStateService<OFilterBuilderComponentStateClass, OFilterBuilderBase> {
    initialize(component: OFilterBuilderBase): void;
    initializeState(state: OFilterBuilderComponentStateClass): void;
    storeFilter(filter: OFilterBuilderStatus): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OFilterBuilderComponentStateService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OFilterBuilderComponentStateService>;
}
//# sourceMappingURL=o-filter-builder-component-state.service.d.ts.map