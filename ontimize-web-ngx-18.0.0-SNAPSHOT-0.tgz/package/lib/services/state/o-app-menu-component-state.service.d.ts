import { OAppSidenavComponent } from '../../components/app-sidenav/o-app-sidenav.component';
import { OAppSidenavComponentStateClass } from './o-app-menu-component-state.class';
import { AbstractComponentStateService } from './o-component-state.service';
import * as i0 from "@angular/core";
export declare class OAppSidenavComponentStateService extends AbstractComponentStateService<OAppSidenavComponentStateClass, OAppSidenavComponent> {
    initialize(component: OAppSidenavComponent): void;
    initializeState(state: OAppSidenavComponentStateClass): void;
    storeMenu(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OAppSidenavComponentStateService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OAppSidenavComponentStateService>;
}
//# sourceMappingURL=o-app-menu-component-state.service.d.ts.map