import { ActivatedRouteSnapshot, CanActivate, CanActivateFn, Router, RouterStateSnapshot } from '@angular/router';
import { OUserInfoService } from '../services/o-user-info.service';
import { AuthService } from './auth.service';
import { PermissionsService } from './permissions/permissions.service';
import * as i0 from "@angular/core";
export declare class AuthGuardService implements CanActivate {
    protected router: Router;
    protected authService: AuthService;
    protected oUserInfoService: OUserInfoService;
    protected permissionsService: PermissionsService;
    canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Promise<boolean> | boolean;
    setUserInformation(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AuthGuardService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AuthGuardService>;
}
export declare const authGuard: CanActivateFn;
//# sourceMappingURL=auth-guard.service.d.ts.map