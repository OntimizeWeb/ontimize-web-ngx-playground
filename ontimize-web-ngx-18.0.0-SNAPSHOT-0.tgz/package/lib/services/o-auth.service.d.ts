import { Injector } from '@angular/core';
import { Observable } from 'rxjs';
import { IAuthService } from '../interfaces/auth-service.interface';
import { SessionInfo } from '../types/session-info.type';
import { AuthService } from './auth.service';
import * as i0 from "@angular/core";
export declare class OntimizeAuthService extends AuthService {
    protected injector: Injector;
    private _user;
    private _config;
    private router;
    private ontService;
    private loginStorageService;
    constructor(injector: Injector);
    get user(): string;
    get localStorageKey(): string;
    configureOntimizeAuthService(config: object): void;
    retrieveAuthService(): Promise<IAuthService>;
    login(user: string, password: string): Observable<any>;
    onLoginSuccess(sessionId: string | number): void;
    onLoginError(error: any): void;
    logout(): Observable<any>;
    onLogoutSuccess(sessionId: number): void;
    onLogoutError(error: any): void;
    clearSessionData(): void;
    isLoggedIn(): boolean;
    getSessionInfo(): SessionInfo;
    storeSessionInfo(info: SessionInfo): void;
    redirectLogin(sessionExpired?: boolean): void;
    restartPermission(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OntimizeAuthService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OntimizeAuthService>;
}
//# sourceMappingURL=o-auth.service.d.ts.map