import { INameConvention } from '../../interfaces/name-convention.interface';
export declare abstract class BaseNameConvention implements INameConvention {
    abstract parseToStringCase(value: string | object | string[]): any;
    abstract parseOppositeToStringCase(value: string | object | string[]): any;
    parseFilterToNameConvention(data: any): {};
    parseColumnsToNameConventionForOntimize(value: object | string): any;
    parseColumnsToNameConventionForJSONAPI(value: string): any;
    parseDataToNameConvention(data: any): any;
    parseResultToNameConvention(data: any): any;
    parseValuesDataToNameConvention(data: any): any;
    parseFilterExpresionNameConvention(data: any): any;
}
//# sourceMappingURL=base-name-convention.service.d.ts.map