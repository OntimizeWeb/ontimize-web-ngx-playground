import * as i0 from "@angular/core";
export declare class MomentService {
    static DATE_FORMATS: string[];
    static defaultFormat: string;
    private _locale;
    private _config;
    constructor();
    load(locale: string): void;
    parseDate(value: any, format?: string, locale?: string): any;
    getLocale(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<MomentService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MomentService>;
}
//# sourceMappingURL=moment.service.d.ts.map