import { SessionInfo } from '../types/session-info.type';
import * as i0 from "@angular/core";
export declare class LoginStorageService {
    private _config;
    _localStorageKey: string;
    constructor();
    getSessionInfo(): SessionInfo;
    storeSessionInfo(sessionInfo: SessionInfo): void;
    updateSessionId(id: string | number): void;
    sessionExpired(): void;
    isLoggedIn(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<LoginStorageService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<LoginStorageService>;
}
//# sourceMappingURL=login-storage.service.d.ts.map