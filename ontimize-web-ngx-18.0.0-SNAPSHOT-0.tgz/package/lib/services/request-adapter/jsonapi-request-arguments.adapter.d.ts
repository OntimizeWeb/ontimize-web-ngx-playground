import { JSONAPIQueryParameter } from '../../types/json-query-parameter.type';
import { BaseRequestArgument } from './base-request-argument.adapter';
import { IBaseRequestArgument } from './base-request-argument.interface';
import { OQueryParams } from '../../types/query-params.type';
import * as i0 from "@angular/core";
export declare class JSONAPIRequestArgumentsAdapter extends BaseRequestArgument implements IBaseRequestArgument {
    parseQueryParameters(args: OQueryParams): JSONAPIQueryParameter[];
    deCompose(expresion: any, columns: Array<string>, kv: Object): Object;
    deComposeExpresion(expresion: any, columns: Array<string>, kv: Object): any;
    getIdFromFilter(filter: any): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<JSONAPIRequestArgumentsAdapter, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<JSONAPIRequestArgumentsAdapter>;
}
//# sourceMappingURL=jsonapi-request-arguments.adapter.d.ts.map