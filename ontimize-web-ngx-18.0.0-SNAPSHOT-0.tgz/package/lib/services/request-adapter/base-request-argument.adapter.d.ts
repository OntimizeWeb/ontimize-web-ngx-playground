import { Observable } from "rxjs";
import { ServiceResponse } from "../../interfaces/service-response.interface";
import { PaginationContextService } from "../pagination-context.service";
export declare class BaseRequestArgument {
    protected paginationContextService: PaginationContextService;
    setPaginationContextService(service: PaginationContextService): void;
    request(method: string, service: any, queryArguments: any): Observable<ServiceResponse>;
    parseQueryParameters(args: any): any;
    getIdFromFilter(filter: any): any;
}
//# sourceMappingURL=base-request-argument.adapter.d.ts.map