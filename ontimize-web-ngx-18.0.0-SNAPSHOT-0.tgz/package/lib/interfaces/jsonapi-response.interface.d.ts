import { BaseResponse } from './base-response.interface';
interface JSONAPIError {
    id?: string;
    status?: string;
    code?: string;
    title?: string;
    detail?: string;
    source?: {
        pointer?: string;
        parameter?: string;
        header?: string;
    };
    links?: {
        about?: string;
        type?: string;
    };
    meta?: Record<string, any>;
}
type JsonApiLinkValue = string | JsonApiLinkObject | null;
interface JSONAPILinks {
    [linkName: string]: JsonApiLinkValue;
}
interface JsonApiLinkObject {
    href: string;
    meta?: Record<string, any>;
    rel?: string;
    type?: string;
    title?: string;
}
interface JSONAPIResource {
    type: string;
    id: string;
    attributes?: Record<string, any>;
    relationships?: Record<string, any>;
    links?: JSONAPILinks;
    meta?: Record<string, any>;
}
interface JSONAPISuccessfulResponse {
    data?: JSONAPIResource | JSONAPIResource[];
    included?: JSONAPIResource[];
    meta?: Record<string, any>;
    links?: JSONAPILinks;
}
interface JSONAPIErrorResponse {
    errors?: JSONAPIError[];
}
export interface JSONAPIResponse extends JSONAPISuccessfulResponse, JSONAPIErrorResponse, BaseResponse {
}
export {};
//# sourceMappingURL=jsonapi-response.interface.d.ts.map