import { OTableBase } from "../components/table/o-table-base.class";
export interface IChartOnDemandService {
    openChartOnDemand(table: OTableBase): any;
}
//# sourceMappingURL=chart-on-demand.interface.d.ts.map