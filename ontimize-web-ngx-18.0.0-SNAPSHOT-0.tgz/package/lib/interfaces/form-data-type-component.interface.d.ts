import { IComponent } from './component.interface';
export interface IFormDataTypeComponent extends IComponent {
    getSQLType(): number;
}
//# sourceMappingURL=form-data-type-component.interface.d.ts.map