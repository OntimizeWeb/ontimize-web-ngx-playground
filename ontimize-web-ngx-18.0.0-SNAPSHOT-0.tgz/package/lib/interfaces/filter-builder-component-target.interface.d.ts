export interface IFilterBuilderCmpTarget {
    formComponentAttr: string;
    targetAttr: string;
}
//# sourceMappingURL=filter-builder-component-target.interface.d.ts.map