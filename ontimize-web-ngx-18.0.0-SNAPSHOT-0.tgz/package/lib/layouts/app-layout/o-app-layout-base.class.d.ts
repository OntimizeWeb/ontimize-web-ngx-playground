export declare abstract class OAppLayoutBase {
    abstract useFlagIcons: boolean;
    abstract tooltipDisplayMode: string;
}
//# sourceMappingURL=o-app-layout-base.class.d.ts.map