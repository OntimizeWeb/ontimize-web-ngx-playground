import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
import * as i2 from "../../shared/shared.module";
import * as i3 from "@angular/router";
import * as i4 from "../../components/app-sidenav/o-app-sidenav.module";
import * as i5 from "../../components/app-header/o-app-header.module";
import * as i6 from "./o-app-layout.component";
import * as i7 from "./app-layout-header/o-app-layout-header.component";
import * as i8 from "./app-layout-sidenav/o-app-layout-sidenav.component";
export declare class OAppLayoutModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OAppLayoutModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OAppLayoutModule, never, [typeof i1.CommonModule, typeof i2.OSharedModule, typeof i3.RouterModule, typeof i4.OAppSidenavModule, typeof i5.OAppHeaderModule, typeof i6.OAppLayoutComponent, typeof i7.OAppLayoutHeaderComponent, typeof i8.OAppLayoutSidenavComponent], [typeof i6.OAppLayoutComponent, typeof i7.OAppLayoutHeaderComponent, typeof i8.OAppLayoutSidenavComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OAppLayoutModule>;
}
//# sourceMappingURL=o-app-layout.module.d.ts.map