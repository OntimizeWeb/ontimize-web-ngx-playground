import * as i0 from "@angular/core";
export declare const DEFAULT_INPUTS_O_APP_LAYOUT_HEADER: string[];
export declare class OAppLayoutHeaderComponent {
    position: 'start' | 'end';
    static ɵfac: i0.ɵɵFactoryDeclaration<OAppLayoutHeaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OAppLayoutHeaderComponent, "o-app-layout-header", never, {}, {}, never, ["*"], true, never>;
}
//# sourceMappingURL=o-app-layout-header.component.d.ts.map