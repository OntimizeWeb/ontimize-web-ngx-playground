import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
import * as i2 from "../../components/card-menu-item/o-card-menu-item.module";
import * as i3 from "../../shared/shared.module";
import * as i4 from "./o-card-menu-layout.component";
export declare class OCardMenuLayoutModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<OCardMenuLayoutModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<OCardMenuLayoutModule, never, [typeof i1.CommonModule, typeof i2.OCardMenuItemModule, typeof i3.OSharedModule, typeof i4.OCardMenuLayoutComponent], [typeof i4.OCardMenuLayoutComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<OCardMenuLayoutModule>;
}
//# sourceMappingURL=o-card-menu-layout.module.d.ts.map