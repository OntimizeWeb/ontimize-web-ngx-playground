import { ViewContainerRef } from '@angular/core';
import * as i0 from "@angular/core";
export declare class OFormLayoutManagerContentDirective {
    viewContainerRef: ViewContainerRef;
    index: number;
    constructor(viewContainerRef: ViewContainerRef);
    static ɵfac: i0.ɵɵFactoryDeclaration<OFormLayoutManagerContentDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<OFormLayoutManagerContentDirective, "[o-form-layout-manager-content]", never, { "index": { "alias": "index"; "required": false; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=o-form-layout-manager-content.directive.d.ts.map